﻿using Microsoft.Data.Entity;
using Microsoft.Data.Entity.Metadata.Builders;
using Opacc.Mof.Client.Service.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opacc.Mof.Client.Service.DataAccess.DataModel.ModelConfig
{
    /// <summary>
    /// Basis-Konfiguration, welhe bei allen Entitäten zum Tragen kommt.
    /// </summary>
    public class EntityBaseConfig<TEntity> where TEntity : ModelBase
    {
        /// <summary>
        /// Instanzen nur über statische Methoden erzeugen 
        /// => Implementation kann auf Minimum gehalten werden
        /// </summary>
        protected EntityBaseConfig()
        {

        }
        
        /// <summary>
        /// Model-Builder, anjand welchem die Entitäts-Modell-Konfiguration durchgeführt wird.
        /// </summary>
        protected ModelBuilder ModelBuilder { get; set; }



        ///// <summary>
        ///// Instanziert Entity-Konfiguration anhand des ModelBuilders
        ///// </summary>
        ///// <param name="modelBuilder">Entitäts-Konfiguration wird mit diesem Builder erzeugt</param>
        //protected EntityBaseConfig(ModelBuilder modelBuilder)
        //{
        //    ModelBuilder = modelBuilder;
        //}

        /// <summary>
        /// Liefert den Entitäts-Builder zurück, mit welchem die Entität konfiguriert werden kann.
        /// </summary>
        protected EntityTypeBuilder<TEntity> EntityBuilder
        {
            get { return ModelBuilder.Entity<TEntity>(); }
        }


        /// <summary>
        /// Konfiguriert die Entität: führt sowohl die Basis-Konfigurationen wie die von der Entität 
        /// zusätzlich implementieren Konfigurationen aus.
        /// Die tatsächliche Konfiguration kann (aktuell) nur die zusätzlichen Konfigurationen vornehmen, die Basis-Konfiguration
        /// wird immer ausgeführt (daher ist Configure auch nicht als 'virtual' deklariert.)
        /// </summary>
        /// <param name="modelBuilder"></param>
        protected void Configure()
        {
            ConfigureBase();
            ConfigureAdditional();
        }

        /// <summary>
        /// Keine Basis-Implementation, nur für zusätzliche Entitäts-Konfiguration gedacht 
        /// => kann von abgeleiteter Klasse einfach überschrieben werden, ohne Basis aufrufen zu müssen.
        /// </summary>
        protected virtual void ConfigureAdditional()
        {
        }

        /// <summary>
        /// Konfiguriert die Entität: führt sowohl die Basis-Konfigurationen wie die von der Entität zusätzlich implementieren
        /// Konfigurationen aus.
        /// </summary>
        /// <param name="modelBuilder"></param>
        private void ConfigureBase()
        {
            // Aktuell nur Key definieren, Required weglassen
            // => dank Einhaltung der EF7-Default-Konfigurationen wäre nicht einmal die Key-Konfiguration notwendig
            EntityBuilder.HasKey(e => e.Id);
            EntityBuilder.Property(e => e.Id).ValueGeneratedOnAdd();

        }

    }
}
