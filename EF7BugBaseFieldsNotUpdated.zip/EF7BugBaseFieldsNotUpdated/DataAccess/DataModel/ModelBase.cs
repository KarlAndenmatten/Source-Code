﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;

    /// <summary>
    /// Basis für alle Datenbank-Tabellen
    /// </summary>
    public abstract class ModelBase : INotifyPropertyChanged

    {

        #region ==================== Properties ====================
        /// <summary>
        /// Eindeutiger künstlicher Schlüssel für jede Entität, welcher in DB künstlich erzeugt wird.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Zu diesem Zeitpunkt wurde Datensatz in Client erzeugt.
        /// </summary>
        public DateTime CreatedAt { get; set; }

        /// <summary>
        /// An diesem Zeitpunkt wurde Datensatz zum letzten Mal im Client modifiziert.
        /// </summary>
        public DateTime ModifiedAt { get; set; }
        #endregion


        #region ==================== Events ====================
        /// <summary>
        /// Multicast event für property change notifications.
        /// Implementation von INotifyPropertyChanged.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion


        #region ==================== Methods ====================
        /// <summary>
        /// Setzt das Property und benachrichtigt registrierte Listeners, falls der Property-Wert wirklich geändert wurde.
        /// </summary>
        /// <typeparam name="T">Generischer Proeprty-Typ</typeparam>
        /// <param name="storage">Zu setzendes Property.</param>
        /// <param name="value">Wert, welcher dem Proerty zugewiesen werden soll.</param>
        /// <param name="propertyName">
        ///  Names des Property, welcher an die Listener weitergegeben wird. 
        ///  Dieser Name kann optional ausgefüllt werden, ist abefr nicht notwendig, weil hier automatisch der Wert des Aufrufers = Properties ausgefüllt wird.
        /// </param>
        /// <returns>
        /// True, falls der Wert wirklich geändert wurde; false, falls sich der Wert nicht existierende Proerty-Wert nicht vom neuen Wert unterscheidet.
        /// 
        /// </returns>
        protected bool SetProperty<T>(ref T storage, T value, [CallerMemberName] string propertyName = null)
        {
            bool hasChanged = false;
            if (!Equals(storage, value))
            {
                storage = value;
                hasChanged = true;
                OnPropertyChanged(propertyName);
            }
            return hasChanged;
        }

        /// <summary>
        /// Benachrichtigt Listener, dass der Wert geändert hat.
        /// </summary>
        /// <param name="propertyName">
        /// Property-Name, welcher an die Listener weitergegeben wird.  Name ist optional und wird autonmatisch ausgefüllt mit Aufrufer-Name, falls null.
        /// </param>
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            // Aufruf mit neuem non-conditional Operator (und threadsafe)
            // siehe auch https://msdn.microsoft.com/en-us/library/dn986595
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}