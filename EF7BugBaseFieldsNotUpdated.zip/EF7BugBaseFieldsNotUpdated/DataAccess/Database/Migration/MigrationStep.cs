﻿using Opacc.Mof.Client.Service.DataAccess.DataModel;
using Opacc.Mof.Client.Service.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opacc.Mof.Client.Service.DataAccess.Database.Migration
{
    /// <summary>
    /// Definiert die Migrations = Änderungen am Datenmodell. Start mit Initial-Version
    /// </summary>
    public abstract class MigrationStep
    {
        #region ==================== Construction, Destruction ====================


        #endregion
        /// <summary>
        /// Ziel-Version: die Migration erzeugt diese Version. 
        /// Die Migrations-Schritte müssen natürlich in der richtigen Reihenfolge aufgerufen werden.
        /// </summary>
        public abstract int Version { get; }

        /// <summary>
        /// Beschreibung der Version.
        /// Wird in Migrations-Tabelle abgelegt und kann in UI angezeigt werden.
        /// </summary>
        public abstract string Description { get; }


        /// <summary>
        /// Eigentliche Migrations-Aktionen: führt die DB-Transformation durch.
        /// Muss von der wirklichen Migration implementiert werden
        /// </summary>
        /// <param name="dbContext">Migration soll auf diesem Context durchgeführt werden</param>
        protected abstract void DoMigration(ClientDbContext dbContext);

        public void DoStep(ClientDbContext dbContext, int currentDbVersion)
        {
            if (Version > currentDbVersion)
            {
                DoMigration(dbContext);
                SaveStep(dbContext);
            }
        }

        private void SaveStep(ClientDbContext dbContext)
        {
            // Zur Sicherheit hier checken, ob Versions-Eintrag bereits besteht (dürfet aber nicht so sein) und allenfalls nur 
            // Update statt Insert durchführen
            var historyEntry = dbContext.DbMigrationHistories.FirstOrDefault(entry => entry.Version == Version);
            if (historyEntry == null)
            {
                historyEntry = new DbMigrationHistory();
                dbContext.Add(historyEntry);
                historyEntry.CreatedAt = DateTime.Now;
            }
            historyEntry.Version = Version;
            historyEntry.Description = Description;
            historyEntry.ModifiedAt = DateTime.Now;
            dbContext.SaveChanges();
        }


    }
}
