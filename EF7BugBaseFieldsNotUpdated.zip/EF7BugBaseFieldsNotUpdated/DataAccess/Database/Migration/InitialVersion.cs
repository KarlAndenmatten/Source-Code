﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataAccess.Database.Migration
{
    using Microsoft.Data.Entity;
    using Opacc.Mof.Client.Service.DataAccess.DataModel;

    /// <summary>
    /// Erzeugt die Initialversion der Datenbank.
    /// </summary>
    public class InitialVersion : MigrationStep
    {
        #region ==================== Properties ====================
        /// <summary>
        /// Ziel-Version: die Migration erzeugt diese Version. 
        /// Die Migrations-Schritte müssen natürlich in der richtigen Reihenfolge aufgerufen werden.
        /// </summary>
        public override int Version
        {
            get { return 1; }
        }

        /// <summary>
        /// Beschreibung der Version.
        /// Wird in Migrations-Tabelle abgelegt und kann in UI angezeigt werden.
        /// </summary>
        public override string Description
        {
            get { return "Initial-Version"; }
        }
        #endregion


        #region ==================== Methods ====================
        /// <summary>
        /// Eigentliche Migrations-Aktionen: führt die DB-Transformation durch.
        /// Muss von der wirklichen Migration implementiert werden
        /// </summary>
        /// <param name="dbContext">Migration soll auf diesem Context durchgeführt werden</param>
        protected override void DoMigration(ClientDbContext dbContext)
        {
            CreateTableDbMigrationHistory(dbContext);
            CreateTableAddress(dbContext);
        }

        private void CreateTableDbMigrationHistory(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS DbMigrationHistory (
                  Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                  CreatedAt DATETIME NOT NULL, 
                  ModifiedAt DATETIME NOT NULL, 
                  Version INTEGER NOT NULL UNIQUE, 
                  Description TEXT)
                 ");
        }

        private void CreateTableAddress(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS Address (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    IsActive BOOLEAN NOT NULL,
                    No INTEGER NOT NULL, 
                    ExternalId TEXT UNIQUE, 
                    FirstName TEXT, 
                    LastName TEXT,                 
                    AddrLine1 TEXT,
                    AddrLine2 TEXT,
                    AddrLine3 TEXT,
                    Street TEXT,
                    ZipCode TEXT,
                    City TEXT,
                    POBox TEXT,
                    POBoxZipCode TEXT,
                    POBoxCity TEXT,
                    Phone1 TEXT,
                    Phone2 TEXT,
                    Fax TEXT,
                    Email TEXT,
                    ContactPersonFirstName TEXT,
                    ContactPersonLastName TEXT,
                    ContactPersonPhone1 TEXT,
                    ContactPersonPhone2 TEXT,
                    ContactPersonEmail TEXT,
                    OriginalValues TEXT
                  )
                 ");
        }

        #endregion
    }
}