﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Opacc.Mof.Client.Service.DataAccess.Database;
using Opacc.Mof.Client.Service.DataAccess.DataModel;
using Opacc.Mof.Client.Service.DataModel;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace EF7BugBaseFieldsNotUpdated
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
	    private Address _address;
	    private int _updateCount = 0;

	    public Address CurrentAddress
	    {
		    get { return _address; }
	    }

	    public MainPage()
        {
            this.InitializeComponent();
            ClientDbContext.DatabaseName = "DemoDatabase.sqlite";
		    ShowHideButtons();
        }

		private void ShowHideButtons()
		{
			if (CurrentAddress == null)
			{

				BtnCreateAddress.Visibility = Visibility.Visible;
				BtnUpdateAddress.Visibility = Visibility.Collapsed;
			}
			else
			{
				BtnCreateAddress.Visibility = Visibility.Collapsed;
				BtnUpdateAddress.Visibility = Visibility.Visible;
			}
		}

		public void CreateAddress_OnClick(object sender, RoutedEventArgs e)
        {
            if (CreateDatabase())
	        {

				CreateAddress();
			}
		}

		public void UpdateAddress_OnClick(object sender, RoutedEventArgs e)
		{
			UpdateAddress();
		}

		private void CreateAddress()
	    {
		    try
		    {
			    using (var dbContext = ClientDbContext.CreateDefaultContext())
			    {
				    var currentDate = DateTime.Now;
                    _address = new Address()
				    {
						LastName = "Andenmatten",
						CreatedAt = currentDate, // CreatedAt and ModifiedAt 100%  same date
						ModifiedAt = currentDate
					};
				    dbContext.Addresses.Add(_address);
				    dbContext.SaveChanges();
					// To be sure we use here another dbConntext
					RetrieveAddressFromDatabase();
			    }
			    TxbOpResult.Text = @"Address successful created.";
		    }
		    catch (Exception ex)
		    {

			    TxbOpResult.Text = "!!!Exception occured when creating address !!!\r\n\r\n" + ex.Message;
			    TxbOpResult.Foreground = new SolidColorBrush(Colors.Red);
		    }
			finally
			{
				ResetUIAfterOp();
				ShowAddress();
			}

		}

		private void UpdateAddress()
		{
			try
			{
				using (var dbContext = ClientDbContext.CreateDefaultContext())
				{
					var address = dbContext.Addresses.FirstOrDefault();
					address.LastName = "Andenmatten_" + (++_updateCount).ToString(); // To show, that update for not-base-fields works
					address.ModifiedAt = DateTime.Now; // CreatedAt and ModifiedAt 100% should now differ
					dbContext.SaveChanges();
				}
				// To be sure we use here another dbConntext
				RetrieveAddressFromDatabase();
				if (CurrentAddress.CreatedAt == CurrentAddress.ModifiedAt)
				{
					TxbOpResult.Text = "!!!Address base field not updated !!!\r\n\r\n Modified-At should differ from Created-At";
                    TxbOpResult.Foreground = new SolidColorBrush(Colors.Red);
				}
				else
				{
					TxbOpResult.Text = @"Address successful updated.";
				}
			}
			catch (Exception ex)
			{

				TxbOpResult.Text = "!!!Exception occured when creating address !!!\r\n\r\n" + ex.Message;
				TxbOpResult.Foreground = new SolidColorBrush(Colors.Red);
			}
			finally
			{
				ShowAddress();
				ResetUIAfterOp();
			}
		}

		private void RetrieveAddressFromDatabase()
	    {
		    using (var dbContext = ClientDbContext.CreateDefaultContext())
		    {
			    _address = dbContext.Addresses.FirstOrDefault();
		    }
	    }

	    private void ShowAddress()
		{
		    if (CurrentAddress != null)
		    {
			    TxbAddressName.Text = CurrentAddress.LastName;
			    TxbCreatedAt.Text = CurrentAddress.CreatedAt.ToString();
				TxbModifiedAt.Text = CurrentAddress.ModifiedAt.ToString();
			}
		}

		private bool CreateDatabase()
        {
	        bool dbCreated = false;
            PrepareUIBeforeOpStart();
	        try
            {
                ClientDbContext.ClearDatabase();
                CreateMigrateDatabase();
				TxbOpResult.Text = @"Database creation successfull.";
	            dbCreated = true;
            }
            catch (Exception ex)
            {

				TxbOpResult.Text = "!!!Exception occured when trying to create database !!!\r\n\r\n" + ex.Message;
				TxbOpResult.Foreground = new SolidColorBrush(Colors.Red);
            }
	        return dbCreated;
        }

        private void ResetUIAfterOp()
        {
            ProgressRing.IsActive = false;
			BtnCreateAddress.IsEnabled = true;
			BtnUpdateAddress.IsEnabled = true;

	        ShowHideButtons();
        }

		private void PrepareUIBeforeOpStart()
        {
            ProgressRing.IsActive = true;
			BtnCreateAddress.IsEnabled = false;
			BtnUpdateAddress.IsEnabled = false;
			TxbOpResult.Text = string.Empty;
			TxbOpResult.Foreground = new SolidColorBrush(Colors.Black);
        }

        private void CreateMigrateDatabase()
        {
            // Hint: Creation of context doesn't create new empty sqlite database but the first access (DoMigration) does it.
            using (var dbContext = ClientDbContext.CreateDefaultContext())
            {
                new ServiceDatabase(dbContext).DoMigration();
            }
        }

    }
}
