﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.Entity;
using Microsoft.Data.Sqlite;
using Opacc.Mof.Client.Service.DataAccess.DataModel;
using Opacc.Mof.Client.Service.DataModel;
using Opacc.Mof.Client.Service.DataAccess.Database.Migration;

namespace Opacc.Mof.Client.Service.DataAccess.Database
{
    /// <summary>
    ///     Implementiert das Service-Datenmodell als Sqlite-Datenbank.
    /// </summary>
    public class ServiceDatabase
    {
        #region ==================== Construction, Destruction ====================

        public ServiceDatabase(ClientDbContext dbContext)
        {
            DbContext = dbContext;
        }

        #endregion


        #region ==================== Properties ====================

        private ClientDbContext DbContext { get; }

        private List<MigrationStep> AllMigrationSteps
        {
            get
            {
                // Achtung: Reihenfolge der Listeinträge muss natürlich stimmen
                return new List<MigrationStep>
                {
                    new InitialVersion()
                };
            }
        }

        #endregion

        #region ==================== Methods ====================

        /// <summary>
        ///     Führt das Datenmodell nach, falls noch nicht auf dem aktuellen Stand.
        ///     Falls überhaupt noch keine Datenbank existiert, so wird diese auch gleich erzeugt.
        /// </summary>
        public void DoMigration()
        {
            // Hinweis: Der Zugriff auf Daten erzeugt auch automatisch das Datenbank-File, falls dieses noch nicht existiert
            var dbCurrentDbVersion = EvaluateCurrentDbVersion();
            AllMigrationSteps.ForEach(step => step.DoStep(DbContext, dbCurrentDbVersion));
        }

        private int EvaluateCurrentDbVersion()
        {
            var currentVersion = -1;
            try
            {
                // Achtung: Max liefert 0, falls keine Einträge => ist aber ok, weil wir mit Version 1 (Initial-Version = 1) anfangen
                currentVersion = DbContext.DbMigrationHistories.Max(entry => entry.Version);
            }
            catch (SqliteException ex)
            {
                // Hier konservativ (vorderhand) nur Sqlite-Error-Codes (hier im Text "no such table") interpretieren. 
                // Alternative: alle Fehler als fehlende DB-Tabelle = leere DB interpretieren
                if (ex.SqliteErrorCode != (int) SqliteErrorCode.Error)
                {
                    throw;
                }
            }
            return currentVersion;
        }

        #endregion



    }
}