﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataAccess.Database.Migration
{
    using Microsoft.Data.Entity;
    using Opacc.Mof.Client.Service.DataAccess.DataModel;

    /// <summary>
    /// Erzeugt die Initialversion der Datenbank.
    /// </summary>
    public class InitialVersion : MigrationStep
    {
        #region ==================== Properties ====================
        /// <summary>
        /// Ziel-Version: die Migration erzeugt diese Version. 
        /// Die Migrations-Schritte müssen natürlich in der richtigen Reihenfolge aufgerufen werden.
        /// </summary>
        public override int Version
        {
            get { return 1; }
        }

        /// <summary>
        /// Beschreibung der Version.
        /// Wird in Migrations-Tabelle abgelegt und kann in UI angezeigt werden.
        /// </summary>
        public override string Description
        {
            get { return "Initial-Version"; }
        }
        #endregion


        #region ==================== Methods ====================
        /// <summary>
        /// Eigentliche Migrations-Aktionen: führt die DB-Transformation durch.
        /// Muss von der wirklichen Migration implementiert werden
        /// </summary>
        /// <param name="dbContext">Migration soll auf diesem Context durchgeführt werden</param>
        protected override void DoMigration(ClientDbContext dbContext)
        {
            CreateTableDbMigrationHistory(dbContext);
            CreateTableAddress(dbContext);
            CreateTableCustomer(dbContext);
            CreateTableProcessingState(dbContext);
            CreateTableServiceType(dbContext);
            CreateTableOrderType(dbContext);
            CreateTableAddressType(dbContext);
            CreateTableProject(dbContext);
            CreateTableContract(dbContext);
            CreateTableArticle(dbContext);
            CreateTableArticleCategory(dbContext);
            CreateTableArticleConnectionType(dbContext);
            CreateTableArticleConnection(dbContext);
            CreateTableArticleCategoryAssignment(dbContext);
            CreateTableArticleSparePart(dbContext);
            CreateTableServiceObject(dbContext);
            CreateTableServiceObjectAddress(dbContext);
            CreateTableServiceObjectHistory(dbContext);
            CreateTableServiceOrder(dbContext);
            CreateTableServiceOrderChangeLog(dbContext);
            CreateTableServiceOrderPart(dbContext);
            CreateTableServiceOrderPlannedItem(dbContext);
            CreateTableServiceOrderActualItem(dbContext);
            CreateTableServiceOrderText(dbContext);
            CreateTableTextTemplate(dbContext);
            CreateTableSyncObject(dbContext);
            CreateTableMsgLog(dbContext);
            CreateTableClientSetting(dbContext);

            CreateTableDocumentCategory(dbContext);
            CreateTableDocumentTemplate(dbContext);
            CreateTableDocument(dbContext);
            CreateTableDocumentFileContent(dbContext);
            CreateTableDocumentFile(dbContext);
            CreateTableDocumentLinkedServiceOrder(dbContext);
            CreateTableDocumentLinkedAddress(dbContext);
            CreateTableDocumentLinkedCustomer(dbContext);
            CreateTableDocumentLinkedArticle(dbContext);
            CreateTableDocumentLinkedServiceObject(dbContext);
            CreateTableDocumentLinkedProject(dbContext);
            CreateTableDocumentLinkedContract(dbContext);
        }

        private void CreateTableDbMigrationHistory(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS DbMigrationHistory (
                  Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                  CreatedAt DATETIME NOT NULL, 
                  ModifiedAt DATETIME NOT NULL, 
                  Version INTEGER NOT NULL UNIQUE, 
                  Description TEXT)
                 ");
        }

        private void CreateTableAddress(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS Address (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    IsActive BOOLEAN NOT NULL,
                    No INTEGER NOT NULL, 
                    ExternalId TEXT UNIQUE, 
                    FirstName TEXT, 
                    LastName TEXT,                 
                    AddrLine1 TEXT,
                    AddrLine2 TEXT,
                    AddrLine3 TEXT,
                    Street TEXT,
                    ZipCode TEXT,
                    City TEXT,
                    POBox TEXT,
                    POBoxZipCode TEXT,
                    POBoxCity TEXT,
                    Phone1 TEXT,
                    Phone2 TEXT,
                    Fax TEXT,
                    Email TEXT,
                    ContactPersonFirstName TEXT,
                    ContactPersonLastName TEXT,
                    ContactPersonPhone1 TEXT,
                    ContactPersonPhone2 TEXT,
                    ContactPersonEmail TEXT,
                    OriginalValues TEXT
                  )
                 ");
        }

        private void CreateTableCustomer(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS Customer (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE, 
                    IsActive BOOLEAN NOT NULL,
                    No INTEGER NOT NULL, 
                    Name TEXT, 
                    AddressId INTEGER REFERENCES Address (Id) ON DELETE CASCADE
                  )
                 ");
        }

        private void CreateTableProcessingState(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ProcessingState (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE, 
                    IsActive BOOLEAN NOT NULL,
                    No INTEGER NOT NULL, 
                    ShortName TEXT,
                    Name TEXT,
                    MofStateCode INTEGER NOT NULL
                  )
                 ");
        }

        private void CreateTableServiceType(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ServiceType (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE, 
                    IsActive BOOLEAN NOT NULL,
                    No INTEGER NOT NULL, 
                    ShortName TEXT,
                    Name TEXT
                  )
                 ");
        }

        private void CreateTableOrderType(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS OrderType (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL,
                    ExternalId TEXT UNIQUE, 
                    IsActive BOOLEAN NOT NULL,
                    Name TEXT,
                    OrderLevel INTEGER NOT NULL,
                    Shortcut TEXT                    
                  )
                 ");
        }

        private void CreateTableAddressType(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS AddressType (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL,
                    ExternalId TEXT UNIQUE, 
                    IsActive BOOLEAN NOT NULL,
                    No TEXT NOT NULL,
                    Name TEXT
                  )
                 ");
        }

        private void CreateTableProject(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS Project (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE, 
                    No INTEGER NOT NULL, 
                    Name TEXT,
                    Description TEXT
                  )
                 ");
        }

        private void CreateTableContract(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS Contract (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE, 
                    No INTEGER NOT NULL, 
                    Name TEXT,
                    Description TEXT
                  )
                 ");
        }

        private void CreateTableArticle(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS Article (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE,
                    IsActive BOOLEAN NOT NULL,
                    No TEXT NOT NULL, 
                    NumericNo INTEGER,
                    Name TEXT,
                    Description TEXT,
                    Price DECIMAL,
                    QuantityUnitName TEXT,
                    AssortmentNo INTEGER,
                    ResourceType INTEGER NOT NULL
                  )
                 ");
        }

        private void CreateTableArticleCategory(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ArticleCategory (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE,
                    IsActive BOOLEAN NOT NULL,
                    No INTEGER NOT NULL, 
                    Name TEXT
                  )
                 ");
        }

        private void CreateTableArticleCategoryAssignment(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ArticleCategoryAssignment (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ArticleId INTEGER NOT NULL REFERENCES Article (Id) ON DELETE CASCADE, 
                    ArticleCategoryId INTEGER NOT NULL REFERENCES ArticleCategory (Id) ON DELETE CASCADE, 
                    Rank INTEGER 
                  )
                 ");

            // Speichern identischer Artikel-Kategorie-Zuteilungen nicht zulässig
            // => Index dient auch gleich dem schnellen Zugriff Artikel => Zuteilung, von der Kategorie aus ist das 
            // eigentlich nie notwendig
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE UNIQUE INDEX ArticleCategoryAssignmentAK 
                    ON ArticleCategoryAssignment (ArticleId, ArticleCategoryId)
                 ");
        }

        private void CreateTableArticleConnectionType(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ArticleConnectionType (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE, 
                    IsActive BOOLEAN NOT NULL,
                    No INTEGER NOT NULL, 
                    ShortName TEXT,
                    Name TEXT
                  )
                 ");
        }

        private void CreateTableArticleConnection(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ArticleConnection (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ArticleId INTEGER NOT NULL REFERENCES Article (Id) ON DELETE CASCADE, 
                    ConnectedArticleId INTEGER NOT NULL REFERENCES Article (Id) ON DELETE CASCADE, 
                    ArticleConnectionTypeId INTEGER NOT NULL REFERENCES ArticleConnectionType (Id),
                    SeqNo INTEGER 
                  )
                 ");
            // Speichern identischer Artikel-Verbindungen nicht zulässig
            // => Index dient auch gleich dem schnellen Zugriff Artikel => Verbindung
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE UNIQUE INDEX ArticleConnectionAK ON ArticleConnection 
                    (ArticleId, ConnectedArticleId, ArticleConnectionTypeId)
                ");

            // Index für schnellen Zugriff Connected-Artikel => Zuteilung
            // => Obiger Index dafür nicht ausreichend, da ArticleConnectionTypeId an zweiter Stelle
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ArticleConnectionConnectedArticleIDX ON ArticleConnection 
                    (ConnectedArticleId)
                ");
        }

        private void CreateTableArticleSparePart(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ArticleSparePart (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ArticleId INTEGER NOT NULL REFERENCES Article (Id) ON DELETE CASCADE, 
                    SparePartArticleId INTEGER NOT NULL REFERENCES Article (Id) ON DELETE CASCADE, 
                    Description TEXT,
                    Quantity DECIMAL
                  )
                 ");

            // Speichern identischer Artikel-Ersatzteil-Zuteilung nicht zulässig
            // => Index dient auch gleich dem schnellen Zugriff Artikel => Ersatzteile
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE UNIQUE INDEX ArticleSparePartAK 
                    ON ArticleSparePart (ArticleId, SparePartArticleId)
                 ");
            // Index für schnellen Zugriff Ersatz-Artikel => Ersatzteile
            // => Obiger Index dafür nicht ausreichend, da ArticleConnectionTypeId an zweiter Stelle
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ArticleSparePartSparePartIDX ON ArticleSparePart 
                    (SparePartArticleId)
                ");
        }

        private void CreateTableServiceObject(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ServiceObject (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE,
                    ParentServiceObjectId INTEGER REFERENCES ServiceObject (Id) ON DELETE CASCADE, 
                    ReplacedServiceObjectId INTEGER REFERENCES ServiceObject (Id) ON DELETE SET NULL, 
                    ArticleId INTEGER REFERENCES Article (Id), 
                    AddressId INTEGER REFERENCES Address (Id),
                    Description TEXT, 
                    SubType TEXT, 
                    Remark TEXT, 
                    SyncState INTEGER NOT NULL,
                    OriginalValues TEXT 
                  )
                 ");
            // Index für schnellen Zugriff Parent-Objekt => Child-Objekte
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ServiceObjectParentServiceObjectIDX ON ServiceObject 
                    (ParentServiceObjectId)
                ");
            // Index für schnellen Zugriff Objekt => Ersatz-Objekt
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ServiceObjectReplacedServiceObjectIDX ON ServiceObject 
                    (ReplacedServiceObjectId)
                ");
        }

        private void CreateTableServiceObjectAddress(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ServiceObjectAddress (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ServiceObjectId INTEGER NOT NULL REFERENCES ServiceObject (Id) ON DELETE CASCADE, 
                    AddressId INTEGER NOT NULL REFERENCES Address (Id), 
                    AddressTypeId INTEGER NOT NULL REFERENCES AddressType (Id)
                  )
                 ");
            // Index für schnellen Zugriff Objekt => Adressen
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ServiceObjectAddressServiceObjectIDX ON ServiceObjectAddress 
                    (ServiceObjectId)
                ");
        }

        private void CreateTableServiceObjectHistory(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ServiceObjectHistory (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ServiceObjectId INTEGER NOT NULL REFERENCES ServiceObject (Id) ON DELETE CASCADE, 
                    ServiceOrderNo TEXT NOT NULL,
                    BookingDate DATETIME NOT NULL, 
                    ArticleNo TEXT NOT NULL,
                    ArticleName TEXT,
                    QtyEffective DECIMAL NOT NULL,
                    QtyChargeable DECIMAL,
                    ServiceTypeNo INTEGER NOT NULL,
                    ServiceTypeName TEXT,
                    EmplNo INTEGER,
                    EmplName TEXT,
                    InternalNote TEXT,
                    ExternalNote TEXT
                  )
                 ");
            // Index für schnellen Zugriff Objekt => History
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ServiceObjectHistoryServiceObjectIDX ON ServiceObjectHistory 
                    (ServiceObjectId)
                ");
        }

        private void CreateTableServiceOrder(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ServiceOrder (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 

                    No TEXT NOT NULL UNIQUE,
                    NumericNo INTEGER,
                    ExternalId TEXT UNIQUE,
                    ProjectId INTEGER REFERENCES Project (Id),
                    ContractId INTEGER REFERENCES Contract (Id),
                    OrderDate DATETIME NOT NULL,
                    AppointmentDate DATETIME,
                    CompletedDate DATETIME,
                    OrderTypeId INTEGER NOT NULL REFERENCES OrderType (Id),
                    ProcessingStateId INTEGER NOT NULL REFERENCES ProcessingState (Id),
                    CustomerId INTEGER NOT NULL REFERENCES Customer (Id),
                    DeliveryAddressId INTEGER REFERENCES Address (Id),
                    InvoiceAddressId INTEGER REFERENCES Address (Id),
                    IsReadOnly BOOLEAN NOT NULL,
                    Priority INTEGER NOT NULL,
                    NameOfSignee TEXT,
                    InternalNoteToOfficeWork TEXT,
                    ExternalNote TEXT,
                    InternalNoteFromOfficeWork TEXT,
                    IsMarkedAsImportant BOOLEAN NOT NULL,
                    SyncState INTEGER NOT NULL,
                    SyncErrorMsg TEXT,
                    OriginalValues TEXT
                  )
                 ");
        }

        private void CreateTableServiceOrderChangeLog(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ServiceOrderChangeLog (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 

                    ServiceOrderId INTEGER NOT NULL REFERENCES ServiceOrder (Id) ON DELETE CASCADE,
                    ModificationType INTEGER NOT NULL,
                    OldProcessingStateId INTEGER REFERENCES ProcessingState (Id) ON DELETE CASCADE,
                    NewProcessingStateId INTEGER REFERENCES ProcessingState (Id) ON DELETE CASCADE,
                    OldTextData TEXT,
                    NewTextData TEXT,
                    OldDateData DATETIME,
                    NewDateData DATETIME,
                    SyncState INTEGER NOT NULL
                  )
                 ");

            // Index für schnellen Zugriff Auftrag => Change-Log
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ServiceOrderChangeLogServiceOrderIDX ON ServiceOrderChangeLog (ServiceOrderId)");
        }

        private void CreateTableServiceOrderText(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ServiceOrderText (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ServiceOrderId INTEGER NOT NULL REFERENCES ServiceOrder (Id) ON DELETE CASCADE,
                    No INTEGER NOT NULL,
                    Title TEXT,
                    Text TEXT
                  )
                 ");

            // Index für schnellen Zugriff Auftrag => Texte
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ServiceOrderTextServiceOrderIDX ON ServiceOrderText (ServiceOrderId)");

        }

        private void CreateTableServiceOrderPart(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ServiceOrderPart (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE, 
                    ServiceOrderId INTEGER NOT NULL REFERENCES ServiceOrder (Id) ON DELETE CASCADE,
                    ServiceObjectId INTEGER REFERENCES ServiceObject (Id), 
                    NumericNo INTEGER,
                    ServiceTypeId INTEGER REFERENCES ServiceType (Id), 
                    SyncState INTEGER NOT NULL
                  )
                 ");

            // Index für schnellen Zugriff Auftrag => Zuteilungen
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ServiceOrderPartServiceOrderIDX ON ServiceOrderPart (ServiceOrderId)");

        }

        private void CreateTableServiceOrderPlannedItem(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ServiceOrderPlannedItem (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE, 
                    ServiceOrderId INTEGER NOT NULL REFERENCES ServiceOrder (Id) ON DELETE CASCADE,
                    ServiceOrderPartId INTEGER REFERENCES ServiceOrderPart (Id) ON DELETE CASCADE,
                    ArticleId INTEGER NOT NULL REFERENCES Article (Id), 
                    ServiceTypeId INTEGER NOT NULL REFERENCES ServiceType (Id), 
                    QtyEffective DECIMAL,
                    QtyChargeable DECIMAL,
                    RefereeNo INTEGER,
                    RefereeName TEXT
                  )
                 ");

            // Index für schnellen Zugriff Auftrag => Sollzeilen
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ServiceOrderPlannedItemServiceOrderIDX ON ServiceOrderPlannedItem (ServiceOrderId)");

            // Index für schnellen Zugriff Zuteilung => Sollzeilen
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ServiceOrderPlannedItemServiceOrderPartIDX ON ServiceOrderPlannedItem (ServiceOrderPartId)");

        }

        private void CreateTableServiceOrderActualItem(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ServiceOrderActualItem (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ServiceOrderId INTEGER NOT NULL REFERENCES ServiceOrder (Id) ON DELETE CASCADE,
                    ServiceOrderPartId INTEGER REFERENCES ServiceOrderPart (Id) ON DELETE CASCADE,
                    ServiceOrderPlannedItemId INTEGER REFERENCES ServiceOrderPlannedItem (Id) ON DELETE CASCADE,
                    ArticleId INTEGER NOT NULL REFERENCES Article (Id), 
                    ServiceTypeId INTEGER NOT NULL REFERENCES ServiceType (Id), 
                    ServiceObjectId INTEGER REFERENCES ServiceObject (Id),
                    BookingDate DATETIME NOT NULL, 
                    QtyEffective DECIMAL NOT NULL, 
                    QtyChargeable DECIMAL NOT NULL, 
                    Price DECIMAL NOT NULL, 
                    HasBeenCreatedAutomatically BOOLEAN NOT NULL,
                    ExternalNote TEXT,
                    InternalNote TEXT,
                    SyncState INTEGER NOT NULL
                  )
                 ");

            // Index für schnellen Zugriff Auftrag => Istzeilen
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ServiceOrderActualItemServiceOrderIDX ON ServiceOrderActualItem (ServiceOrderId)");

            // Index für schnellen Zugriff Zuteilung => Istzeilen
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ServiceOrderActualItemServiceOrderPartIDX ON ServiceOrderActualItem (ServiceOrderPartId)");

            // Index für schnellen Zugriff Sollzeile => Istzeilen
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX ServiceOrderActualItemServiceOrderPlannedItemIDX ON ServiceOrderActualItem (ServiceOrderPlannedItemId)");

        }

        private void CreateTableTextTemplate(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS TextTemplate (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE, 
                    IsActive BOOLEAN NOT NULL,
                    TemplateType INTEGER NOT NULL, 
                    ShortName TEXT,
                    Text TEXT,
                    RankNo INTEGER, 
                    Value TEXT
                  )
                 ");
        }

        private void CreateTableSyncObject(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS SyncObject (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    Key TEXT NOT NULL UNIQUE, 
                    Description TEXT,
                    SyncToken TEXT,
                    LastSyncError TEXT
                  )
                 ");
        }

        private void CreateTableClientSetting(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS ClientSetting (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    Key TEXT NOT NULL UNIQUE, 
                    Description TEXT,
                    Value TEXT
                  )
                 ");
        }

        private void CreateTableMsgLog(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS MsgLog (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    Level INTEGER NOT NULL,
                    Msg TEXT, 
                    MsgDetail TEXT
                  )
                 ");
        }

        private void CreateTableDocumentCategory(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS DocumentCategory (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE,
                    IsActive BOOLEAN NOT NULL,
                    No INTEGER NOT NULL, 
                    Name TEXT,
                    DocumentsAreEditable BOOLEAN NOT NULL
                  )
                 ");
        }

        private void CreateTableDocumentTemplate(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS DocumentTemplate (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE,
                    IsActive BOOLEAN NOT NULL,
                    No TEXT NOT NULL, 
                    Name TEXT,
                    IsVisible BOOLEAN NOT NULL
                  )
                 ");
        }

        private void CreateTableDocument(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS Document (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE,
                    IsActive BOOLEAN NOT NULL,
                    DocumentCategoryId INTEGER REFERENCES DocumentCategory (Id),
                    DocumentTemplateId INTEGER REFERENCES DocumentTemplate (Id),
                    No TEXT, 
                    Name TEXT,
                    IsVisibleInDocumentOverview BOOLEAN NOT NULL,
                    DocumentDate DATETIME
                  )
                 ");
        }

        private void CreateTableDocumentFileContent(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS DocumentFileContent (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    Content BLOB nullable                    
                  )
                 ");
        }

        private void CreateTableDocumentFile(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS DocumentFile (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    ExternalId TEXT UNIQUE,
                    DocumentId INTEGER NOT NULL REFERENCES Document (Id) ON DELETE CASCADE,
                    Name TEXT,
                    FilePath TEXT,
                    DocumentFileContentId INTEGER REFERENCES DocumentFileContent (Id) ON DELETE CASCADE,
                    SyncState INTEGER NOT NULL
                  )
                 ");

            // Index für schnellen Zugriff Dokument => Files
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX DocumentFileDocumentIDX ON DocumentFile (DocumentId)");
        }

        private void CreateTableDocumentLinkedServiceOrder(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS DocumentLinkedServiceOrder (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    DocumentId INTEGER NOT NULL REFERENCES Document (Id) ON DELETE CASCADE,
                    ServiceOrderId INTEGER NOT NULL REFERENCES ServiceOrder (Id) ON DELETE CASCADE
                  )
                 ");

            // Speichern identischer Dokument-Serviceauftrag-Zuteilungen nicht zulässig
            // => dient auch dem schnellen Zugriff Dokument => Verknüpfung
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE UNIQUE INDEX DocumentLinkedServiceOrderAK 
                    ON DocumentLinkedServiceOrder (DocumentId, ServiceOrderId)
                 ");

            // Index für schnellen Zugriff Auftrag => Verknüpfungen
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX DocumentLinkedServiceOrderServiceOrderIDX ON DocumentLinkedServiceOrder (ServiceOrderId)");

        }

        private void CreateTableDocumentLinkedAddress(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS DocumentLinkedAddress (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    DocumentId INTEGER NOT NULL REFERENCES Document (Id) ON DELETE CASCADE,
                    AddressId INTEGER NOT NULL REFERENCES Address (Id) ON DELETE CASCADE
                  )
                 ");

            // Speichern identischer Dokument-Address-Zuteilungen nicht zulässig
            // => dient auch gleich dem schnellen Zugriff Dokument => Verknüpfung
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE UNIQUE INDEX DocumentLinkedAddressAK 
                    ON DocumentLinkedAddress (DocumentId, AddressId)
                 ");

            // Index für schnellen Zugriff Adresse => Verknüpfungen
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX DocumentLinkedAddressAddressIDX ON DocumentLinkedAddress (AddressId)");

        }

        private void CreateTableDocumentLinkedCustomer(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS DocumentLinkedCustomer (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    DocumentId INTEGER NOT NULL REFERENCES Document (Id) ON DELETE CASCADE,
                    CustomerId INTEGER NOT NULL REFERENCES Customer (Id) ON DELETE CASCADE
                  )
                 ");
            // Speichern identischer Dokument-Address-Zuteilungen nicht zulässig
            // => dient auch dem schnellen Zugriff Dokument => Verknüpfung
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE UNIQUE INDEX DocumentLinkedCustomerAK 
                    ON DocumentLinkedCustomer (DocumentId, CustomerId)
                 ");

            // Index für schnellen Zugriff Adresse => Kunde
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX DocumentLinkedCustomerCustomerIDX ON DocumentLinkedCustomer (CustomerId)");
        }

        private void CreateTableDocumentLinkedArticle(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS DocumentLinkedArticle (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    DocumentId INTEGER NOT NULL REFERENCES Document (Id) ON DELETE CASCADE,
                    ArticleId INTEGER NOT NULL REFERENCES Article (Id) ON DELETE CASCADE
                  )
                 ");
            // Speichern identischer Dokument-Address-Zuteilungen nicht zulässig
            // => dient auch gleich schnellem Zugriff Dokument => Verknüpfung
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE UNIQUE INDEX DocumentLinkedArticleAK 
                    ON DocumentLinkedArticle (DocumentId, ArticleId)
                 ");

            // Index für schnellen Zugriff Artikel => Verknüpfung
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX DocumentLinkedArticleArticleIDX ON DocumentLinkedArticle (ArticleId)");

        }

        private void CreateTableDocumentLinkedServiceObject(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS DocumentLinkedServiceObject (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    DocumentId INTEGER NOT NULL REFERENCES Document (Id) ON DELETE CASCADE,
                    ServiceObjectId INTEGER NOT NULL REFERENCES ServiceObject (Id) ON DELETE CASCADE
                  )
                 ");

            // Speichern identischer Dokument-Objekt-Zuteilungen nicht zulässig
            // => dient auch gleich dem schnellen Zugriff Dokument => Verknüpfung
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE UNIQUE INDEX DocumentLinkedServiceObjectAK 
                    ON DocumentLinkedServiceObject (DocumentId, ServiceObjectId)
                 ");

            // Index für schnellen Zugriff Objekt => Verknüpfung
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX DocumentLinkedServiceServiceObjectIDX ON DocumentLinkedServiceObject (ServiceObjectId)");


        }

        private void CreateTableDocumentLinkedProject(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS DocumentLinkedProject (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    DocumentId INTEGER NOT NULL REFERENCES Document (Id) ON DELETE CASCADE,
                    ProjectId INTEGER NOT NULL REFERENCES Project (Id) ON DELETE CASCADE
                  )
                 ");

            // Speichern identischer Dokument-Projekt-Zuteilungen nicht zulässig
            // => dient auch gleich dem schnellen Zugriff Dokument => Verknüpfung
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE UNIQUE INDEX DocumentLinkedProjectAK 
                    ON DocumentLinkedProject (DocumentId, ProjectId)
                 ");

            // Index für schnellen Zugriff Projekt => Verknüpfung
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX DocumentLinkedProjectProjectIDX ON DocumentLinkedProject (ProjectId)");

        }

        private void CreateTableDocumentLinkedContract(ClientDbContext dbContext)
        {
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE TABLE IF NOT EXISTS DocumentLinkedContract (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, 
                    CreatedAt DATETIME NOT NULL, 
                    ModifiedAt DATETIME NOT NULL, 
                    DocumentId INTEGER NOT NULL REFERENCES Document (Id) ON DELETE CASCADE,
                    ContractId INTEGER NOT NULL REFERENCES Contract (Id) ON DELETE CASCADE
                  )
                 ");

            // Speichern identischer Dokument-Projekt-Zuteilungen nicht zulässig
            // => dient auch gleich dem schnellen Zugriff Dokument => Verknüpfung
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE UNIQUE INDEX DocumentLinkedContractAK 
                    ON DocumentLinkedContract (DocumentId, ContractId)
                 ");

            // Index für schnellen Zugriff Vertrag => Verknüpfung
            dbContext.Database.ExecuteSqlCommand(@"
                CREATE INDEX DocumentLinkedContractContractIDX ON DocumentLinkedContract (ContractId)");

        }
        #endregion
    }
}