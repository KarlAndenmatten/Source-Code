// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataAccess.DataModel
{
	using System.Linq;
	using Microsoft.Data.Entity;
	using Opacc.Mof.Client.Service.DataModel;

	public static class DbSetOrderTypeExtensions
	{
		#region ==================== Methods ====================
		public static OrderType FindByExternalId(this DbSet<OrderType> query, string externalId)
		{
			return query.FirstOrDefault(o => o.ExternalId.Equals(externalId));
		}
		#endregion
	}
}