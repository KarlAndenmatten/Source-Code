﻿using Opacc.Mof.Client.Service.DataModel;
using Microsoft.Data.Entity;

namespace Opacc.Mof.Client.Service.DataAccess.DataModel.ModelConfig
{
    /// <summary>
    /// Konfiguriert Klasse 'ClientSetting'
    /// Aktuell wird hier nur Basiskonfiguration vorgenommen => keine Implementation notwendig
    /// </summary>
    public class ClientSettingConfig : EntityBaseConfig<ClientSetting>
    {
        /// <summary>
        /// Konfiguriert die Entität
        /// </summary>
        /// <param name="modelBuilder">Entität wird anhand dieses ModelBuilders konfiguriert.</param>
        public static void Configure(ModelBuilder modelBuilder)
        {
            new ClientSettingConfig() { ModelBuilder = modelBuilder }.Configure();
        }
    }
}
