﻿using Opacc.Mof.Client.Service.DataModel;
using Microsoft.Data.Entity;

namespace Opacc.Mof.Client.Service.DataAccess.DataModel.ModelConfig
{
    /// <summary>
    /// Konfiguriert Klasse 'DocumentLinkedProject'
    /// Aktuell wird hier nur Basiskonfiguration vorgenommen => keine Implementation notwendig
    /// </summary>
    public class DocumentLinkedProjectConfig : EntityBaseConfig<DocumentLinkedProject>
    {
        /// <summary>
        /// Konfiguriert die Entität
        /// </summary>
        /// <param name="modelBuilder">Entität wird anhand dieses ModelBuiöders konfiguriert.</param>
        public static void Configure(ModelBuilder modelBuilder)
        {
            new DocumentLinkedProjectConfig() { ModelBuilder = modelBuilder }.Configure();
        }
    }
}
