﻿using Opacc.Mof.Client.Service.DataModel;
using Microsoft.Data.Entity;

namespace Opacc.Mof.Client.Service.DataAccess.DataModel.ModelConfig
{
    /// <summary>
    /// Konfiguriert Klasse 'DocumentLinkedArticle'
    /// </summary>
    public class DocumentLinkedArticleConfig : EntityBaseConfig<DocumentLinkedArticle>
    {
        /// <summary>
        /// Konfiguriert die Entität
        /// </summary>
        /// <param name="modelBuilder">Entität wird anhand dieses ModelBuilders konfiguriert.</param>
        public static void Configure(ModelBuilder modelBuilder)
        {
            new DocumentLinkedArticleConfig() { ModelBuilder = modelBuilder }.Configure();
        }


        protected override void ConfigureAdditional()
        {
            EntityBuilder.HasOne(l => l.Article).WithMany(a => a.ArticleLinkedDocuments);
            EntityBuilder.HasOne(l => l.Document).WithMany(d => d.DocumentLinkedArticles);
        }
    }
}
