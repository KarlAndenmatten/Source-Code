﻿using Opacc.Mof.Client.Service.DataModel;
using Microsoft.Data.Entity;

namespace Opacc.Mof.Client.Service.DataAccess.DataModel.ModelConfig
{
    /// <summary>
    /// Konfiguriert Klasse 'ArticleConnection'
    /// Aktuell wird hier nur Basiskonfiguration vorgenommen => keine Implementation notwendig
    /// </summary>
    public class ArticleConnectionConfig : EntityBaseConfig<ArticleConnection>
    {
        /// <summary>
        /// Konfiguriert die Entität
        /// </summary>
        /// <param name="modelBuilder">Entität wird anhand dieses ModelBuilders konfiguriert.</param>
        public static void Configure(ModelBuilder modelBuilder)
        {
            new ArticleConnectionConfig() { ModelBuilder = modelBuilder }.Configure();
        }

        protected override void ConfigureAdditional()
        {
			EntityBuilder.HasOne(c => c.Article).WithMany(a => a.ArticleConnections);
            EntityBuilder.HasOne(c => c.ConnectedArticle).WithMany(a => a.ArticleRelations);
            EntityBuilder.HasOne(c => c.ArticleConnectionType).WithMany(t => t.ArticleConnections);

        }

    }
}
