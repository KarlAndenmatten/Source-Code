﻿using Opacc.Mof.Client.Service.DataModel;
using Microsoft.Data.Entity;

namespace Opacc.Mof.Client.Service.DataAccess.DataModel.ModelConfig
{
    /// <summary>
    /// Konfiguriert Klasse 'ServiceOrderText'
    /// Aktuell wird hier nur Basiskonfiguration vorgenommen => keine Implementation notwendig
    /// </summary>
    public class ServiceOrderTextConfig : EntityBaseConfig<ServiceOrderText>
    {
        /// <summary>
        /// Konfiguriert die Entität
        /// </summary>
        /// <param name="modelBuilder">Entität wird anhand dieses ModelBuilders konfiguriert.</param>
        public static void Configure(ModelBuilder modelBuilder)
        {
            new ServiceOrderTextConfig() { ModelBuilder = modelBuilder }.Configure();
        }
    }
}
