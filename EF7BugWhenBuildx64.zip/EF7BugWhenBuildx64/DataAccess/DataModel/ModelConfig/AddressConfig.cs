﻿using Opacc.Mof.Client.Service.DataModel;
using Microsoft.Data.Entity;

namespace Opacc.Mof.Client.Service.DataAccess.DataModel.ModelConfig
{
    /// <summary>
    /// Konfiguriert Klasse 'Address'
    /// Aktuell wird hier nur Basiskonfiguration vorgenommen => keine Implementation notwendig
    /// </summary>
    public class AddressConfig : EntityBaseConfig<Address>
    {
        /// <summary>
        /// Konfiguriert die Entität
        /// </summary>
        /// <param name="modelBuilder">Entität wird anhand dieses ModelBuilders konfiguriert.</param>
        public static void Configure(ModelBuilder modelBuilder)
        {
            new AddressConfig() { ModelBuilder = modelBuilder }.Configure();
        }

        protected override void ConfigureAdditional()
        {
            // Hier neu dann die Kontaktdaten als komplexes Property konfigurieren, wenn dies dann 
            // in EF7 funktioniert
        }

    }
}
