﻿using Opacc.Mof.Client.Service.DataModel;
using Microsoft.Data.Entity;

namespace Opacc.Mof.Client.Service.DataAccess.DataModel.ModelConfig
{
    /// <summary>
    /// Konfiguriert Klasse 'ArticleSparePart'
    /// Aktuell wird hier nur Basiskonfiguration vorgenommen => keine Implementation notwendig
    /// </summary>
    public class ArticleSparePartConfig : EntityBaseConfig<ArticleSparePart>
    {
        /// <summary>
        /// Konfiguriert die Entität
        /// </summary>
        /// <param name="modelBuilder">Entität wird anhand dieses ModelBuilders konfiguriert.</param>
        public static void Configure(ModelBuilder modelBuilder)
        {
            new ArticleSparePartConfig() { ModelBuilder = modelBuilder }.Configure();
        }

        protected override void ConfigureAdditional()
        {
            EntityBuilder.HasOne(part => part.Article).WithMany(a => a.ArticleSpareParts);
            EntityBuilder.HasOne(part => part.SparePartArticle).WithMany(d => d.AssignedAsSpareParts);
        }

    }
}
