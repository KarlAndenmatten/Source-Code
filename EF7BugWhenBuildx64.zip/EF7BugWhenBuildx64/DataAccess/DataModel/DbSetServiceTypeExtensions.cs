// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataAccess.DataModel
{
	using System.Linq;
	using Microsoft.Data.Entity;
	using Opacc.Mof.Client.Service.DataModel;

	public static class DbSetServiceTypeExtensions
	{
		#region ==================== Methods ====================
		public static ServiceType FindByExternalId(this DbSet<ServiceType> query, string externalId)
		{
			return query.FirstOrDefault(o => o.ExternalId.Equals(externalId));
		}
		#endregion
	}
}