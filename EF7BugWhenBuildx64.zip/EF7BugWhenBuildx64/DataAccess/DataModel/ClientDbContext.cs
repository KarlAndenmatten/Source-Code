﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataAccess.DataModel
{
    using System;
    using System.Collections.Generic;
    using System.Data.Common;
    using System.IO;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using Windows.Storage;
    using Microsoft.Data.Entity;
    using Microsoft.Data.Entity.ChangeTracking;
    using Opacc.Mof.Client.Service.DataAccess.Database;
    using Opacc.Mof.Client.Service.DataAccess.DataModel.ModelConfig;
    using Opacc.Mof.Client.Service.DataModel;

    public class ClientDbContext : DbContext
    {
        #region ==================== Constants, Enums ====================
        private static readonly Dictionary<Type, List<object>> sBusinessLogicListeners = new Dictionary<Type, List<object>>();
        #endregion


        #region ==================== Fields ====================
        private readonly DbConnection mDbConnection;
        private bool mSaveRunAlreadyValidated;
        #endregion


        #region ==================== Construction, Destruction ====================
        static ClientDbContext()
        {
            DatabaseName = "ServiceClientDB.sqlite";
        }

        public ClientDbContext(DbConnection dbConnection)
        {
            mDbConnection = dbConnection;
        }
        #endregion


        #region ==================== Properties ====================
        private static string DatabasePath => Path.Combine(ApplicationData.Current.LocalFolder.Path, DatabaseName);
        #endregion


        #region ==================== Methods ====================
        /// <summary>
        /// Registriert den Business-Logic-Listener für Notifikation von Änderungen an Instanzen vom Entitäts-Typ 'entityType'.
        /// </summary>
        /// <param name="entityType">Listener reagiert auf Änderungen von Instanzen dieser Entität</param>
        /// <param name="listener">Dieser Listener soll bei Änderungen benachrichtigt werden.</param>
        public static void RegisterBusinessLogicListener(Type entityType, IBusinessLogicNotification listener)
        {
            if (sBusinessLogicListeners.ContainsKey(entityType))
            {
                sBusinessLogicListeners[entityType].Add(listener);
            }
            else
            {
                sBusinessLogicListeners[entityType] = new List<object>()
                {
                    listener
                };
            }
        }

        /// <summary>
        /// Entfernt alle aktuellen Business-Logic-Listener aus der Benachrichtigungskette.
        /// Wird eigentlich nur für Tests benötigt, weil normalerweise einmal registrierte Listener immer registriert bleiben.
        /// </summary>
        public static void RemoveAllBusinessLogicListeners()
        {
            sBusinessLogicListeners.Clear();
        }

        private static void NotifyListeners(ClientDbContext dbContext, object entity, EntityState state)
        {
            Type entityType = entity.GetType();
            if (sBusinessLogicListeners.ContainsKey(entityType))
            {
                foreach (var entry in sBusinessLogicListeners[entityType])
                {
                    var listener = entry as IBusinessLogicNotification;
                    if (state == EntityState.Added)
                    {
                        listener?.BeforeAdding(dbContext, entity);
                    }
                    else if (state == EntityState.Modified)
                    {
                        listener?.BeforeUpdating(dbContext, entity);
                    }
                    else if (state == EntityState.Deleted)
                    {
                        listener?.BeforeDeleting(dbContext, entity);
                    }
                }
            }
        }
        #endregion


        #region Helper / Statics
        public static string DatabaseName { get; set; }

        public static ClientDbContext CreateDefaultContext()
        {
            return new ClientDbContext(new SqliteConnectionFactory(DatabasePath).CreateNewConnection());
        }

        public static void ClearDatabase()
        {
            if (File.Exists(DatabasePath))
            {
                File.Delete(DatabasePath);
            }
        }
        #endregion


        #region Entities
        public DbSet<ServiceObjectHistory> ServiceOrderObjectHistories { get; set; }
        public DbSet<TextTemplate> TextTemplates { get; set; }
        public DbSet<SyncObject> SyncObjects { get; set; }
        public DbSet<MsgLog> MsgLogs { get; set; }
        public DbSet<ClientSetting> ClientSettings { get; set; }
        public DbSet<DbMigrationHistory> DbMigrationHistories { get; set; }
        public DbSet<AddressType> AddressTypes { get; set; }
        public DbSet<Address> Addresses { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Article> Articles { get; set; }
        public DbSet<ArticleCategory> ArticleCategories { get; set; }
        public DbSet<ArticleConnectionType> ArticleConnectionTypes { get; set; }
        public DbSet<ArticleConnection> ArticleConnections { get; set; }
        public DbSet<ArticleCategoryAssignment> ArticleCategoryAssignments { get; set; }
        public DbSet<ArticleSparePart> ArticleSpareParts { get; set; }
        public DbSet<ProcessingState> ProcessingStates { get; set; }
        public DbSet<ServiceType> ServiceTypes { get; set; }
        public DbSet<ServiceOrder> ServiceOrders { get; set; }
        public DbSet<ServiceObject> ServiceObjects { get; set; }
        public DbSet<ServiceObjectAddress> ServiceObjectsAddresses { get; set; }
        public DbSet<OrderType> OrderTypes { get; set; }
        public DbSet<Project> Projects { get; set; }
        public DbSet<Contract> Contracts { get; set; }
        public DbSet<ServiceOrder> Orders { get; set; }
        public DbSet<ServiceOrderChangeLog> ServiceOrderChangeLogs { get; set; }
        public DbSet<ServiceOrderText> ServiceOrderTexts { get; set; }
        public DbSet<ServiceOrderPart> ServiceOrderParts { get; set; }
        public DbSet<ServiceOrderPlannedItem> ServiceOrderPlannedItems { get; set; }
        public DbSet<ServiceOrderActualItem> ServiceOrderActualItems { get; set; }
        public DbSet<DocumentCategory> DocumentCategories { get; set; }
        public DbSet<DocumentTemplate> DocumentTemplates { get; set; }
        public DbSet<Document> Documents { get; set; }
        public DbSet<DocumentFile> DocumentFiles { get; set; }
        public DbSet<DocumentFileContent> DocumentFileContents { get; set; }
        public DbSet<DocumentLinkedServiceOrder> DocumentsLinkedServiceOrders { get; set; }
        public DbSet<DocumentLinkedAddress> DocumentsLinkedAddresses { get; set; }
        public DbSet<DocumentLinkedCustomer> DocumentsLinkedCustomers { get; set; }
        public DbSet<DocumentLinkedArticle> DocumentsLinkedArticles { get; set; }
        public DbSet<DocumentLinkedServiceObject> DocumentsLinkedServiceObjects { get; set; }
        public DbSet<DocumentLinkedProject> DocumentsLinkedProjects { get; set; }
        public DbSet<DocumentLinkedContract> DocumentsLinkedContracts { get; set; }
        #endregion


        #region Saving data
        public override int SaveChanges()
        {
            // Achtung: SaveChanges(acceptAllChangesOnSuccess) wird offenbar innerhalb von SaveChanges() aufgerufen
            // => darum aus Performancegründen Validierung so bauen, dass diese innerhalb Speicherdurchgang nur einmal aufgerufen wird
            // => am Schluss der Validierung kann dies wieder zurückgesetzt werden
            // todo: nochmals genauer abklären, wie die geschachtelten Aufrufe erfogen
            if (!mSaveRunAlreadyValidated)
            {
                ValidateChangedEntities();
                mSaveRunAlreadyValidated = true;
            }

            var saved = base.SaveChanges();
            mSaveRunAlreadyValidated = false; // Kann hier in jedem Fall zurückgesetzt werden
            return saved;
        }

        public override int SaveChanges(bool acceptAllChangesOnSuccess)
        {
            // Achtung: SaveChanges(acceptAllChangesOnSuccess) wird offenbar innerhalb von SaveChanges() aufgerufen
            // => darum aus Performancegründen Validierung so bauen, dass diese innerhalb Speicherdurchgang nur einmal aufgerufen wird
            // => am Schluss der Validierung kann dies wieder zurückgesetzt werden
            // todo: nochmals genauer abklären, wie die geschachtelten Aufrufe erfogen
            if (!mSaveRunAlreadyValidated)
            {
                ValidateChangedEntities();
                mSaveRunAlreadyValidated = true;
            }
            var saved = base.SaveChanges(acceptAllChangesOnSuccess);
            mSaveRunAlreadyValidated = false; // Kann hier in jedem Fall zurückgesetzt werden, auch wenn etwas vorzeitig
            return saved;
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = new CancellationToken())
        {
            // todo: noch schauen, ob hier aus Performancegründen Mehrfach-Validierung auch abgefangen werden sollte
            ValidateChangedEntities();
            return base.SaveChangesAsync(cancellationToken);
        }

        public override Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess,
            CancellationToken cancellationToken = new CancellationToken())
        {
            // todo: noch schauen, ob hier aus Performancegründen Mehrfach-Validierung auch abgefangen werden sollte
            ValidateChangedEntities();
            return base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
        }

        private void ValidateChangedEntities()
        {
            // Achtung: während Notifikation können auch neue Instanzen erzeugt werden:
            // => auch diese benachrichtigen 
            // => Liste iterativ durchgehen, bis alle Instanzen validiert sind (leider in jedem Fall mind. zweimal)
            var notifiedEntries = new Dictionary<object, bool>(); // Achtung: Check-Liste auf Entity-Instanz führen 
            bool allNotified = false;
            while (!allNotified)
            {
                allNotified = true;
                var changedEntries = GetChangedEntries(); // Für Debuggingzwecke: Zuweisung besser
                foreach (var changedEntry in changedEntries)
                {
                    if (!notifiedEntries.ContainsKey(changedEntry.Entity))
                    {
                        ValidateNotifyEntity(changedEntry);
                        notifiedEntries[changedEntry.Entity] = true;
                        allNotified = false; // Steht sicher nochmals ein Durchgang an
                    }
                }
            }
        }

        private IEnumerable<EntityEntry> GetChangedEntries()
        {
            return ChangeTracker.Entries()
                .Where(
                    entry =>
                        entry.State == EntityState.Added || entry.State == EntityState.Modified ||
                        entry.State == EntityState.Deleted)
                .ToList();
        }

        private void ValidateNotifyEntity(EntityEntry changedEntry)
        {
            var validationEntity = changedEntry.Entity as IValidatingEntity;
            if (changedEntry.State == EntityState.Deleted)
            {
                validationEntity?.ValidateBeforeDelete();
            }
            else if (changedEntry.State == EntityState.Added)
            {
                validationEntity?.ValidateBeforeAdd();
            }
            else if (changedEntry.State == EntityState.Modified)
            {
                validationEntity?.ValidateBeforeUpdate();
            }
            NotifyListeners(this, changedEntry.Entity, changedEntry.State);
        }
        #endregion


        #region Configuration/Model
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite(mDbConnection);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // In EF7 habe ich  'ModelBuilder.Configurations' nicht gefunden. 
            // Anhand dieser Konfiguration konnte man fürher mit  modelBuilder.Configurations.Add(EntityTypeConfiguration)
            // die Entitäts-Konfiguratuions-Klassen hinzufügen, welche dann vom Framework aufgerufen wurden.
            // Die nachfolgende Implementation ist eine 'Nachbildung' dieses Mechanismus
            // => so kann Konfiguration sehr gut ûnd übersichtlich in Klassen gekapselt werden 
            // (obwohl aktuell eigentlich praktisch nirhends eine Konfiguration notwendig wäre, ist aber trotzdem schöner so)

            DbMigrationHistoryConfig.Configure(modelBuilder);
            AddressConfig.Configure(modelBuilder);
            CustomerConfig.Configure(modelBuilder);
            ProcessingStateConfig.Configure(modelBuilder);
            ServiceTypeConfig.Configure(modelBuilder);
            OrderTypeConfig.Configure(modelBuilder);
            AddressTypeConfig.Configure(modelBuilder);
            ProjectConfig.Configure(modelBuilder);
            ContractConfig.Configure(modelBuilder);
            ArticleConfig.Configure(modelBuilder);
            ArticleCategoryConfig.Configure(modelBuilder);
            ArticleConnectionTypeConfig.Configure(modelBuilder);
            ArticleCategoryAssignmentConfig.Configure(modelBuilder);
            ArticleConnectionConfig.Configure(modelBuilder);
            ArticleSparePartConfig.Configure(modelBuilder);
            ServiceObjectConfig.Configure(modelBuilder);
            ServiceObjectAddressConfig.Configure(modelBuilder);
            ServiceObjectHistoryConfig.Configure(modelBuilder);
            ServiceOrderConfig.Configure(modelBuilder);
            ServiceOrderChangeLogConfig.Configure(modelBuilder);
            ServiceOrderPartConfig.Configure(modelBuilder);
            ServiceOrderPlannedItemConfig.Configure(modelBuilder);
            ServiceOrderActualItemConfig.Configure(modelBuilder);
            ServiceOrderTextConfig.Configure(modelBuilder);
            TextTemplateConfig.Configure(modelBuilder);
            SyncObjectConfig.Configure(modelBuilder);
            MsgLogConfig.Configure(modelBuilder);
            ClientSettingConfig.Configure(modelBuilder);
            DocumentCategoryConfig.Configure(modelBuilder);
            DocumentTemplateConfig.Configure(modelBuilder);
            DocumentConfig.Configure(modelBuilder);
            DocumentFileConfig.Configure(modelBuilder);
            DocumentFileContentConfig.Configure(modelBuilder);
            DocumentLinkedAddressConfig.Configure(modelBuilder);
            DocumentLinkedCustomerConfig.Configure(modelBuilder);
            DocumentLinkedServiceOrderConfig.Configure(modelBuilder);
            DocumentLinkedArticleConfig.Configure(modelBuilder);
            DocumentLinkedServiceObjectConfig.Configure(modelBuilder);
            DocumentLinkedProjectConfig.Configure(modelBuilder);
            DocumentLinkedContractConfig.Configure(modelBuilder);
        }
        #endregion
    }
}