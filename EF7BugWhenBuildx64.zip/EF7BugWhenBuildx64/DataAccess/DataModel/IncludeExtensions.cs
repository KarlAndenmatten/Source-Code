﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataAccess.DataModel
{
	using System.Linq;
	using Microsoft.Data.Entity;
	using Opacc.Mof.Client.Service.DataModel;

	/// <summary>
	/// Stellt Abfrage-Hilfsmethoden zur Verfügung, welche Includes implementieren, so dass diese
	/// die Applikation nicht jeweils selber schreiben muss.
	/// Vor allem die Extension IncludeAllUpRef sollte auf allen Business-Objekten (welche Referenzen aufweisen) zur Verfügung stehen.
	/// </summary>
	public static class IncludeExtensions
	{
		#region ==================== Methods ====================
		public static IQueryable<ServiceOrder> IncludeAllUpRef(this IQueryable<ServiceOrder> query)
		{
			return query
				.Include(o => o.Project)
				.Include(o => o.Contract)
				.Include(o => o.OrderType)
				.Include(o => o.ProcessingState)
				.Include(o => o.Customer)
				.Include(o => o.DeliveryAddress)
				.Include(o => o.InvoiceAddress)
				.Include(o => o.ServiceOrderParts).ThenInclude(p => p.ServiceObject).ThenInclude(o => o.Article);
		}
		#endregion
	}
}