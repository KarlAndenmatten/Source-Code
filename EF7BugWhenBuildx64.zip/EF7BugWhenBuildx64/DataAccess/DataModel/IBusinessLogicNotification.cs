﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataAccess.DataModel
{
    /// <summary>
    /// Interface zum Validieren der Business-Logik auf den Model-Instanzen.
    /// Wird vom DB-Context vor dem Speichern aufgerufen, Validierungs-Methoden bekommen 
    /// unter anderem auch Context mitgeliefert, auf welchem sie auf weitere Daten zugreifen kann.
    /// Eigentlich wäre es schön, wenn das Notifikations-Interface 'IBusinessLogicNotification' generisch als 
    /// 'IBusinessLogicNotification<TEntity>' definiert würde:
    /// . => BeforeAdding(ClientDbContext dbContext, TEntity newEntity)
    /// . => void BeforeUpdating(ClientDbContext dbContext, TEntity updatedEntity)
    /// . => BeforeDeleting(ClientDbContext dbContext, TEntity entityToDelete)
    /// Das wäre auch möglich, nur hat man dann das Problem im Aufruf 'NotifyListeners', welcher die 'richtige' 
    /// generische Methode aufrufen müsste, was nur mit einem switch-Statement möglich wäre, wo alle bekannten 
    /// Business-Klassen bekannt sein müssten, was aber bei Erweiterungen leicht vergessen werden könnte. 
    /// Daher haben wir uns hier für ein nicht-generisches Interface entschieden und führen den Cast dann halt in der 
    /// jeweiligen Business-Methode durch. 
    /// </summary>
    public interface IBusinessLogicNotification
    {
        #region ==================== Methods ====================
        /// <summary>
        /// Wir aufgerufen, bevor die Instanz in Datenbank eingefügt wird.
        /// </summary>
        /// <param name="dbContext">Einfügen der Instanz in diesen Context:</param>
        /// <param name="newEntity">Diese Instanz soll eingefügt werden.</param>
        void BeforeAdding(ClientDbContext dbContext, object newEntity);

        /// <summary>
        /// Wir aufgerufen, bevor die Instanz in der Datenbank modifiziert wird.
        /// </summary>
        /// <param name="dbContext">Modifikation der Instanz in diesem Context:</param>
        /// <param name="updatedEntity">Diese Instanz soll modifiziert werden.</param>
        void BeforeUpdating(ClientDbContext dbContext, object updatedEntity);

        /// <summary>
        /// Wird aufgerufen, bevor die Instanz in der Datenbank gelöscht wird.
        /// </summary>
        /// <param name="dbContext">Löschen der Instanz in diesem Context:</param>
        /// <param name="entityToDelete">Diese Instanz soll gelöscht werden.</param>
        void BeforeDeleting(ClientDbContext dbContext, object entityToDelete);
        #endregion
    }
}