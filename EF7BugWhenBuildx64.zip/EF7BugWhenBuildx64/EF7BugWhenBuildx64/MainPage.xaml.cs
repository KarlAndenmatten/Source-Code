﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Opacc.Mof.Client.Service.DataAccess.Database;
using Opacc.Mof.Client.Service.DataAccess.DataModel;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace EF7BugWhenBuildx64
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            ClientDbContext.DatabaseName = "DemoDatabase.sqlite";
        }

        private void CreateDatabase_OnClick(object sender, RoutedEventArgs e)
        {
            TryCreateDatabase();
        }

        private async void TryCreateDatabase()
        {
            PrepareUIBeforeOpStart();
            try
            {
                ClientDbContext.ClearDatabase();
                CreateMigrateDatabase();
                TxbResultDatabaseCreation.Text = @"Database creation successfull.";
            }
            catch (Exception ex)
            {

                TxbResultDatabaseCreation.Text = "!!!Exception occured when trying to create database !!!\r\n\r\n" + ex.Message;
                TxbResultDatabaseCreation.Foreground = new SolidColorBrush(Colors.Red);
            }
            finally
            {
                ResetUIAfterOp();
            }
        }

        private void ResetUIAfterOp()
        {
            ProgressRing.IsActive = false;
            BtnCreateDatabase.IsEnabled = true;
        }

        private void PrepareUIBeforeOpStart()
        {
            ProgressRing.IsActive = true;
            BtnCreateDatabase.IsEnabled = false;
            TxbResultDatabaseCreation.Text = string.Empty;
            TxbResultDatabaseCreation.Foreground = new SolidColorBrush(Colors.Black);
        }

        private void CreateMigrateDatabase()
        {
            // Hint: Creation of context doesn't create new empty sqlite database but the first access (DoMigration) does it.
            using (var dbContext = ClientDbContext.CreateDefaultContext())
            {
                new ServiceDatabase(dbContext).DoMigration();
            }
        }

    }
}
