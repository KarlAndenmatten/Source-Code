﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System.Collections.Generic;

    /// <summary>
    /// Dokument-Kategorien, welche gemäss Service-Konfiguration und aufgrund der 
    /// verknüpften Dokumente von DMASübernommen werden.
    /// </summary>
    public class DocumentCategory : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private bool mIsActive;
        private int mNo;
        private string mName;
        private bool mDocumentsAreEditable;
        #endregion


        public DocumentCategory()
        {
            IsActive = true;

            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            Documents = new List<Document>();
        }

        /// <summary>
        /// Eindeutige Mof-Service-Id, welche die Kategorie auf der Mof-Service-Schnittstelle eindeutig identifiziert.
        /// Wird vom Mof-Service definiert/erzeugt.Für nicht im Client erzeugte Kategorien(aktuell also alle) immer ausgefüllt.
        /// Falls ausgefüllt, so muss diese eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Im Client können nur aktive Kategorien ausgewählt werden.
        /// Inaktive Kategorien werden in den Auswahlen ausgeblendet und 
        /// vom Cleanup-Job gelöscht, wenn diese nicht mehr referenziert werden.
        /// </summary>
        public bool IsActive
        {
            get { return mIsActive; }
            set { SetProperty(ref mIsActive, value); }
        }

        /// <summary>
        /// Numerische Kategorie-Nr.
        /// Identifiziert die Kategorie in der Opacc-Dokument-Verwaltung
        /// </summary>
        public int No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Kategorie-Bezeichnung.
        /// Wird von der Opacc-Dokument-Verwaltung übernommen.
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }

        /// <summary>
        /// Falls true, so dürfen die zu dieser Kategorie ausgelieferten DMAS-Dokumente 
        /// auf dem Client auch bearbeitet werden.
        /// Diese Vorgabe kann/muss in MOF-Service-Konfiguration hinterlegt werden. 
        /// </summary>
        public bool DocumentsAreEditable
        {
            get { return mDocumentsAreEditable; }
            set { SetProperty(ref mDocumentsAreEditable, value); }
        }

        /// <summary>
        /// Liste der mit der Kategorie verknüpften Dokumente.
        /// </summary>
        public virtual List<Document> Documents { get; set; }
    }
}