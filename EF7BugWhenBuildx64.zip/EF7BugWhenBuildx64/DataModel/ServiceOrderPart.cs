﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System.Collections.Generic;

    /// <summary>
    ///     Die übermittelten Zuteilungen eines Serviceauftrags.
    /// </summary>
    public class ServiceOrderPart : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private ServiceOrder mServiceOrder;
        private ServiceObject mServiceObject;
        private int? mNumericNo;
        private ServiceType mServiceType;
        private SyncState mSyncState;
        #endregion


        public ServiceOrderPart()
        {
            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            ServiceOrderPlannedItems = new List<ServiceOrderPlannedItem>();
            ServiceOrderActualItems = new List<ServiceOrderActualItem>();
        }

        /// <summary>
        ///     Eindeutige Mof-Service-Id der Zuteilung.
        ///     Falls ausgefüllt, so muss dieses eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        ///     Service-Auftrag, zu welchem die Zuteilung gehört
        ///     Muss zwingend ausgefüllt werden.
        /// </summary>
        public ServiceOrder ServiceOrder
        {
            get { return mServiceOrder; }
            set { SetProperty(ref mServiceOrder, value); }
        }

        /// <summary>
        ///     Verweis/Referenz auf das Parent-Objekt (Selbstreferenz).
        ///     Objekte lassen sich verschachteln(ein Objekt enthält ein anderes Objekt, …).
        ///     Dies kommt natürlich vor allem bei Anlagen und so zum Tragen.
        /// </summary>
        public ServiceObject ServiceObject
        {
            get { return mServiceObject; }
            set { SetProperty(ref mServiceObject, value); }
        }

        /// <summary>
        ///     Numerische Zuteilungs-Nr, welche z.B. zur Sortierung von Sollzeilen bei Auswahlen herangezogen werden kann (darum
        ///     numerisch).
        ///     Ist aber auch rein informativ nützlich.
        ///     Von OXAS wird hier AsstDocItem.AssignNo ausgelesen und abgefüllt.
        /// </summary>
        public int? NumericNo
        {
            get { return mNumericNo; }
            set { SetProperty(ref mNumericNo, value); }
        }

        /// <summary>
        ///    Referenz auf die Verrechnungsart/Leistungsart, in OXAS ist dies 'AsstDocItem.ServiceTypeNo'.
        ///    Auf der Zuteilung kann optional ein Service-Typ hinterlegt werden, welcher im Client beim Erzeugen von 
        ///    Istzeilen übernommen(vorgeschlagen) würde, wenn nicht auf eine Sollzeile gebucht wird.
        ///    Die möglichen/vorkommenden Leistungsarten werden von OXAS von der Tabelle 'ServiceType' gelesen und als
        ///    Stammdaten abgeglichen.
        /// </summary>
        public ServiceType ServiceType
        {
            get { return mServiceType; }
            set { SetProperty(ref mServiceType, value); }
        }

        /// <summary>
        ///     Synchronisations-Status der Zuteilung.
        ///     Der Zustand bezieht sich aber vor allem(eigentlich ausschliesslich) auf Custom-Properties, welche bearbeitet
        ///     und zurückgemeldet werden können.
        ///     Achtung: der Status ist überflüssig, wenn neu der Auftrag nur noch gesamthaft zurückgemeldet wird.
        ///     In diesem Fall würde der Synchronisations-Zustand ziemlich sicher nur noch auf dem Auftrag geführt.
        ///     Im Client als Enum 'SyncState' abgebildet, wobei hier davon folgende Stati zum Tragen kommen:
        ///     + 1 =  'Downloaded': Zuteilung von Mof-Service runtergeladen
        ///     + 20: Uploaded: Zuteilung vollständig an Mof-Service übermittelt
        ///     + 30: UploadedAndReadyForCleanup: Zuteilung vollständig übermittelt und zurücksynchronisiert
        /// </summary>
        public SyncState SyncState
        {
            get { return mSyncState; }
            set { SetProperty(ref mSyncState, value); }
        }

        /// <summary>
        /// Die mit der Zuteilung verknüpften Sollzeilen.
        /// </summary>
        public virtual List<ServiceOrderPlannedItem> ServiceOrderPlannedItems { get; set; }

        /// <summary>
        /// Die mit der Zuteilung verknüpften Istzeilen.
        /// </summary>
        public virtual List<ServiceOrderActualItem> ServiceOrderActualItems { get; set; }
    }
}