﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Mögliche Rapportarten, welche in OXAS-Businessdata in 'AsstDocType' hinterlegt werden. 
    /// </summary>
    public class OrderType : ModelBase
    {
        #region ==================== Fields ====================
        private bool mIsActive;
        private string mExternalId;
        private string mName;
        private OrderLevel mOrderLevel;
        private string mShortcut;
        #endregion


        #region ==================== Construction, Destruction ====================
        public OrderType()
        {
            // Per Default sind Rapportarten auch aktiv
            IsActive = true;
            OrderLevel = OrderLevel.Default; // Feld zumindest immer ausgefüllt
        }
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Ist Rapportart noch aktiviert? Im Client können inaktive Rapportarten gelöscht werden, wenn diese nicht mehr referenziert werden.
        /// Zudem müssen beim Filtern etc. nur aktive Rapportarten angezeigt werden.
        /// </summary>
        public bool IsActive
        {
            get { return mIsActive; }
            set { SetProperty(ref mIsActive, value); }
        }

        /// <summary>
        /// Eindeutige Identifikation der Stufe in Mof-Service.  Könnte z.B. Kombination Level+Shortcut sein.
        /// Diese Id muss auch auf den Aufträgen als Rapportart mitgeliefert werden.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Rapportart-Bezeichnung.
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }

        /// <summary>
        /// Rapportstufe: Montage, Unterhalt, Störfall, Shop-Order. 
        /// </summary>
        public OrderLevel OrderLevel
        {
            get { return mOrderLevel; }
            set { SetProperty(ref mOrderLevel, value); }
        }

        /// <summary>
        /// Shortcut der Rapportart.
        /// </summary>
        public string Shortcut
        {
            get { return mShortcut; }
            set { SetProperty(ref mShortcut, value); }
        }
        #endregion
    }
}