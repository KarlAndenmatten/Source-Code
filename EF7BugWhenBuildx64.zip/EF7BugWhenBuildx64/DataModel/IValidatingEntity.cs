﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Interface zum Validieren der DB-Instanzen, bevor diese in Datenbank geschrieben werden.
    /// </summary>
    public interface IValidatingEntity
    {
        #region ==================== Methods ====================
        /// <summary>
        /// Wir aufgerufen, bevor die Instanz in Datenbank eingefügt wird.
        /// </summary>
        void ValidateBeforeAdd();

        /// <summary>
        /// Wir aufgerufen, bevor die Instanz in der Datenbank modifiziert wird.
        /// </summary>
        void ValidateBeforeUpdate();

        /// <summary>
        /// Wir aufgerufen, bevor die Instanz in der Datenbank gelöscht wird.
        /// </summary>
        void ValidateBeforeDelete();
        #endregion
    }
}