﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Da auf dem Service-Client Texteingaben relativ aufwendig sind, wird an gewissen Stellen anstelle 
    /// oder zusätzlich der Eingabe eine Auswahlmöglichkeit zur Verfügung gestellt. 
    /// Dort werden dem Benutzer die hier abgelegten Text-Templates zur Auswahl angeboten.
    /// </summary>
    public class TextTemplate : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private bool mIsActive;
        private TextTemplateType mTemplateType;
        private string mShortName;
        private string mText;
        private int? mRankNo;
        private string mValue;
        #endregion


        #region ==================== Construction, Destruction ====================
        public TextTemplate()
        {
            // Per Default sind neue Leistungsarten auch aktiv
            IsActive = true;
        }
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Eindeutige Mof-Service-Id, welche den Text auf der Mof-Service-Schnittstelle eindeutig identifiziert.
        /// Wird vom Mof-Service definiert/erzeugt.Für nicht im Client erzeugte Texte(aktuell also alle) immer ausgefüllt.
        /// Falls ausgefüllt, so muss diese eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Text ist aktiv ja/nein.
        /// Inaktive Texte werden in den Auswahlen ausgeblendet und vom Cleanup-Job gelöscht, 
        /// wenn diese nicht mehr referenziert werden.
        /// Hinweis: Flag könnte aktuell auch weggelassen werden, weil Text-Konserven nie referenziert 
        /// werden und somit auch immer gleich gelöscht werden können(statt diese zu deaktivieren). 
        /// Im Sinne eines konsistenten Datenmodells macht Flag aber trotzdem Sinn.
        /// </summary>
        public bool IsActive
        {
            get { return mIsActive; }
            set { SetProperty(ref mIsActive, value); }
        }

        /// <summary>
        /// Template-Art, welche vom Mof-Service anhand der Konfiguration berechnet und als Code an den Client 
        /// ausgeliefert wird. Der Client steuert die Auswahl an den verschiedenen Stellen anhand dieses Codes.
        /// Auf dem Client sind die Codes im Enum 'TextTemplateType' codiert.
        /// </summary>
        public TextTemplateType TemplateType
        {
            get { return mTemplateType; }
            set { SetProperty(ref mTemplateType, value); }
        }

        /// <summary>
        /// Kurz-Bezeichnung des Textes, welche auf dem Client bei Auswahlen (anstelle des Textes) angezeigt wird.
        /// Von OXAS wird das Attribut "FreeTableItem.ShortName" gelesen und hier abgefüllt.
        /// Die Kurzbezeichnung kann/muss in OXAS sprachabhängig erfasst werden, auf den Client wird 
        /// die Bezeichnung in der auf dem Tablet-Benutzer hinterlegten Sprache ausgeliefert 
        /// (resp. in Defaultsprache = Deutsch, falls keine Übersetzung in OXAS voliegt)
        /// </summary>
        public string ShortName
        {
            get { return mShortName; }
            set { SetProperty(ref mShortName, value); }
        }

        /// <summary>
        /// Eigentliche Textkonserve, welche auf dem Client nach der Auswahl in das Ziel-Textfeld kopiert wird.
        /// Von OXAS wird das Attribut "FreeTableItem.Name" gelesen und hier abgefüllt.
        /// Der Text kann/muss in OXAS sprachabhängig erfasst werden, auf den Client wird die Bezeichnung 
        /// in der auf dem Tablet-Benutzer hinterlegten Sprache ausgeliefert (resp. in Defaultsprache = Deutsch, 
        /// falls keine Übersetzung in OXAS voliegt)
        /// </summary>
        public string Text
        {
            get { return mText; }
            set { SetProperty(ref mText, value); }
        }

        /// <summary>
        /// Numerische Sortier-Nr, welche weder ausgefüllt noch eindeutig sein muss.
        /// Von OXAS wird das Attribut "FreeTableItem.SortNo" gelesen und hier abgefüllt.
        /// Das Feld wird auch auf dem Client zur Sortierung der Text-Auswahl eingesetzt.
        /// </summary>
        public int? RankNo
        {
            get { return mRankNo; }
            set { SetProperty(ref mRankNo, value); }
        }

        /// <summary>
        /// Alphanumerischer Wert, welche der Textkonserve zugewiesen werden kann.
        /// In OXAS muss dieser Wert zwingend in  "FreeTableItem.Value" erfasst werden (und sogar eindeutig sein). 
        /// Auf dem Client hat dieser Wert aber eher keine Bedeutung (daher hier auch als nullable definiert). 
        /// Bei Bedarf könnte aber auf dem Client projektspezifisch auf diesen Wert codiert werden.
        /// </summary>
        public string Value
        {
            get { return mValue; }
            set { SetProperty(ref mValue, value); }
        }
        #endregion
    }
}