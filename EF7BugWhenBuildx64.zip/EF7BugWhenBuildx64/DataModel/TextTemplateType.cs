﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Legt die möglichen Typen von Text-Templates fest.
    /// Der Client schränkt an den verschiedenen Stellen die Auswahl auf diese Codes 
    /// ein (Interner Hinweis auf der Istzeile => nur Templates mit Code 'InternalTextActualItem', ...)
    /// </summary>
    public enum TextTemplateType
    {
        /// <summary>
        /// Interne Hinweise, welche auf den Istzeilen hinterlegt werden können.
        /// </summary>
        InternalTextActualItem = 1,

        /// <summary>
        /// Externe Hinweise, welche auf den Istzeilen hinterlegt werden können.
        /// </summary>
        ExternalTextActualItem = 2
    }
}