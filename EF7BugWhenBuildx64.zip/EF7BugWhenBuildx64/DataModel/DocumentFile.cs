﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Der eigentliche Inhalt der Dokumente bilden die Dokument-Files, das Dokument ist nur der 
    /// eigentliche Behälter für die Files. 
    /// </summary>
    public class DocumentFile : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private Document mDocument;
        private string mName;
        private string mFilePath;
        private DocumentFileContent mDocumentFileContent;
        private SyncState mSyncState;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Eindeutige Mof-Service-Id, welche das File auf der Mof-Service-Schnittstelle eindeutig identifiziert.
        /// Wird vom Mof-Service definiert/erzeugt (z.B. Dokument-Nr/File-Name). Bei Files, welche im Client erzeugt werden, 
        /// ist dieses Feld leer (null).
        /// Falls ausgefüllt, so muss diese eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Referenziert das Dokument, in welchem das File verwaltet wird..
        /// Die Referenz muss immer ausgefüllt sein, weil Files zwingend in Dokumenten verwaltet werden müssen.
        /// </summary>
        public Document Document
        {
            get { return mDocument; }
            set { SetProperty(ref mDocument, value); }
        }

        /// <summary>
        /// File-Name inkl. File-Name-Extension (aber kein Pfad, Content sowieso direkt in DB).        /// 
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }

        /// <summary>
        /// Eindeutiger File-Name (mit oder ohne Pfad, wird von Implementation festgelegt).
        /// Die Datei wird aus Handlings-Gründen vorderhand auf der Disk und nicht in der DB abgelegt.
        /// </summary>
        public string FilePath
        {
            get { return mFilePath; }
            set { SetProperty(ref mFilePath, value); }
        }

        /// <summary>
        /// Verweis auf den File-Inhalt, wenn der File-Inhalt auch in der DB abgelegt ist (vorderhand nicht der Fall).
        /// Die Referenz könnte natürlich auch umgekehrt sein, da es sich hier um eine 1-1-Beziehung handelt. 
        /// Das Handling ist aber mit dieser Referenz eher einfacher, auch Abfragen eher einfacher. 
        /// Insbesondere müsste beim Einfügen eines Contents trotzdem hier der Status nachgeführt werden 
        /// (wenn wir Status 'PartiallyDownloaded' unterstützen).
        /// </summary>
        public DocumentFileContent DocumentFileContent
        {
            get { return mDocumentFileContent; }
            set { SetProperty(ref mDocumentFileContent, value); }
        }

        /// <summary>
        /// Synchronisations-Status des Files.
        /// Im Client als Enum 'SyncState' abgebildet, wobei hier davon folgende Stati zum Tragen kommen:
        /// + 0 = 'Partially Downloaded': Die Meta-Informationen des Files vom Mof-Service heruntergeladen, aber 
        /// noch keinen Inhalt. In diesem Fall müsste auch 'FileContentId' null sein (Status könnte also auch 
        /// berechnet werden, so aber eher klarer)
        /// + 1 = 'Downloaded': File inkl. Inhalt vom Mof-Service heruntergeladen. 
        /// In diesem Fall müsste auch 'FileContentId' ausgefüllt sein.
        /// + 2 = 'CreatedOnClient': File in Client erzeugt
        /// + 10 = ReadyForUpload: Datei wurde lokal erstellt oder bearbeitet und ist bereit zum Hochladen auf den Server
        /// + 20 = Uploaded: die neu erstellte/geänderte Datei wurde zum Server hochgeladen.
        /// </summary>
        public SyncState SyncState
        {
            get { return mSyncState; }
            set { SetProperty(ref mSyncState, value); }
        }
        #endregion
    }
}