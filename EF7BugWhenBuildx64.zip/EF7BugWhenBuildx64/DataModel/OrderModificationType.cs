﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Legt die möglichen Service-Auftrags-Modifikationsarten fest, welche zu ChangeLog-Einträgen führen.
    /// </summary>
    public enum OrderModificationType
    {
        /// <summary>
        /// Statusänderung.
        /// </summary>
        Status = 1,

        /// <summary>
        /// Interner Hinweis an Innendienst erfasst/geändert
        /// </summary>
        InternalNote = 2,

        /// <summary>
        /// Externer Hinweis erfasst/geändert
        /// </summary>
        ExternalNote = 3,

        /// <summary>
        /// Auftragsdatum geändert
        /// </summary>
        OrderDate = 4,

        /// <summary>
        ///  Verabredungstermin geändert
        /// </summary>
        AppointmentDate = 5
    }
}