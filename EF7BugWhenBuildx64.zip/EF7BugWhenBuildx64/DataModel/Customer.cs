﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System.Collections.Generic;
    using System.IO;

    /// <summary>
    /// Alle Kunden, welche den Service-Aufträgen zugeordnet sind resp. zugewiesen werden können.
    /// Kunden sind in erster Linie natürlich vor allem spezielle Adressen, sie bestehen im Wesentlichen auch vor allem aus 
    /// den Adressdaten.
    /// </summary>
    public class Customer : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private bool mIsActive;
        private int mNo;
        private string mName;
        private Address mAddress;
        #endregion


        public Customer()
        {
            // Per Default sind neue Adressen auch aktiv
            IsActive = true;

            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            DocumentLinkedCustomers = new List<DocumentLinkedCustomer>();
        }

        /// <summary>
        /// Eindeutige Mof-Service-Id des Kunden.
        /// Falls ausgefüllt, so muss dieses eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Ist Kunde noch aktiviert? Im Client können nur aktive Kunden ausgewählt werden.
        /// </summary>
        public bool IsActive
        {
            get { return mIsActive; }
            set { SetProperty(ref mIsActive, value); }
        }

        /// <summary>
        /// Adress-Nummer, im Client nicht als unique definiert.
        /// </summary>
        public int No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Kunden-Name (entspricht eigentlich auch Name auf der Kundenadresse).
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }

        /// <summary>
        /// Referenz auf die Adressdaten des Kunden.
        /// Ist in OXAS eugentlich immer usgefüllt, hier auf dem Client aber doch als Nullable definiert.
        /// </summary>
        public Address Address
        {
            get { return mAddress; }
            set { SetProperty(ref mAddress, value); }
        }

        /// <summary>
        /// Liste der Dokument-Kunden-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedCustomer> DocumentLinkedCustomers { get; set; }

        public override void ValidateBeforeAdd()
        {
            CheckValidData();
            base.ValidateBeforeAdd();
        }

        public override void ValidateBeforeUpdate()
        {
            CheckValidData();
            base.ValidateBeforeUpdate();
        }

        private void CheckValidData()
        {
            // Gewisse Fehler hier selber abfangen, weil EF teils unverständliche Fehlermeldungen ausgibt.
            // Zum Beispiel bei ffehlender Adresse ""No mapping to a relational type can be found for the CLR type 'Address'""
            if (Address == null)
            {
                throw new InvalidDataException("Dem Kunden muss zwingend eine Adresse zugewiesen sein!");
            }
        }
    }
}