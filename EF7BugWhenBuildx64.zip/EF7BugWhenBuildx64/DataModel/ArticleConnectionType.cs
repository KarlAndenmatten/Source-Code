﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System.Collections.Generic;

    /// <summary>
    /// Mögliche Artikel-Verknüpfungstypen. 
    /// Die möglichen Verknüpfungstypen werden in OXAS in  ArtConnectType verwaltet und die in notwendigen 
    /// (gemäss Client-Artikel) von dort gelesen.
    /// </summary>
    public class ArticleConnectionType : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private bool mIsActive;
        private int mNo;
        private string mShortName;
        private string mName;
        #endregion


        public ArticleConnectionType()
        {
            IsActive = true;

            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            ArticleConnections = new List<ArticleConnection>();
        }

        /// <summary>
        /// Eindeutige Mof-Service-Id des Verknüpfungstyps.
        /// Falls ausgefüllt, so muss dieses eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Im Client können nur aktive Verknüpfungstypen ausgewählt werden.
        /// </summary>
        public bool IsActive
        {
            get { return mIsActive; }
            set { SetProperty(ref mIsActive, value); }
        }

        /// <summary>
        /// Verknüpfungstyp-Nr. 
        /// Muss ausgefüllt sein, aber nicht zwingend eindeutig. OXAS: ArtConnectType.Number gelesen.
        /// </summary>
        public int No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Verknüpfungstyp-Kurzbezeichnung. 
        /// OXAS: ArtConnectType.ShortName gelesen.
        /// </summary>
        public string ShortName
        {
            get { return mShortName; }
            set { SetProperty(ref mShortName, value); }
        }

        /// <summary>
        /// Verknüpfungstyp-Bezeichnung. 
        /// OXAS: ArtConnectType.Name gelesen.
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }

        /// <summary>
        /// Liste der unter dem Typ erfassten Artikel-Verknüpfungen.
        /// </summary>
        public virtual List<ArticleConnection> ArticleConnections { get; set; }
    }
}