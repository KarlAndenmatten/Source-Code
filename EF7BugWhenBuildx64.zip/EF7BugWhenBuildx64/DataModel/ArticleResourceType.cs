﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Service-Resourcen-Typ. 
    /// Legt fest, welche Art von Service-Resource der Artikel darstellt (Passiv, Arbeit, Weg, Spesen).
    /// Wird von OXAS von 'ArtSal.SimpleArtServeTypeCd' übernommen und auf dem Client interpretiert. 
    /// </summary>
    public enum ArticleResourceType
    {
        /// <summary>
        /// Unbekannter Typ. 
        /// Zum Beispiel werden auch Artikel ohne OXAS-Verkaufserweiterung (SimpleArtServeTypeCd nicht 
        /// verfügbar), auf diesen Wert abgebildet.
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// Arbeit, Leistung
        /// </summary>
        Labour = 1,

        /// <summary>
        /// Arbeitszeit
        /// </summary>
        TravelingTime = 2,

        /// <summary>
        /// Arbeitsweg
        /// </summary>
        TravelingDistance = 3,

        /// <summary>
        /// Lagerartikel
        /// </summary>
        Material = 4,

        /// <summary>
        /// Spesen
        /// </summary>
        Expense = 6
    }
}