﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System.Collections.Generic;

    /// <summary>
    /// Alle Adressen, welche den Service-Aufträgen zugeordnet sind resp. zugewiesen werden können. 
    /// Dies sind vor allem Kunden-, Service-Auftrag- und Objekt-Adressen.
    /// </summary>
    public class Address : ModelBase
    {
        #region ==================== Fields ====================
        private bool mIsActive;
        private string mExternalId;
        private int mNo;
        private string mFirstName;
        private string mLastName;
        private string mAddrLine1;
        private string mAdrLine2;
        private string mAdrLine3;
        private string mStreet;
        private string mZipCode;
        private string mCity;
        private string mPoBox;
        private string mPoBoxZipCode;
        private string mPoBoxCity;
        private string mPhone1;
        private string mPhone2;
        private string mFax;
        private string mEmail;
        private string mContactPersonFirstName;
        private string mContactPersonLastName;
        private string mContactPersonPhone1;
        private string mContactPersonPhone2;
        private string mContactPersonEmail;
        private string mOriginalValues;
        #endregion


        #region ==================== Construction, Destruction ====================
        public Address()
        {
            // Komplexe Property müssen immer erzeugt werden
            // Aktuell funktionieren diese aber nicht, daher nur normale Proerties
            // ContactPerson = new Contact();

            // Per Default sind neue Adressen auch aktiv
            IsActive = true;

            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            DocumentLinkedAddresses = new List<DocumentLinkedAddress>();
        }
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Ist Adresse noch aktiviert? Im Client können nur aktive Adressen ausgewählt werden.
        /// </summary>
        public bool IsActive
        {
            get { return mIsActive; }
            set { SetProperty(ref mIsActive, value); }
        }

        /// <summary>
        /// Eindeutige Mof-Service-Id der Adresse. Wird für Rückmeldungen verwendet.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Adress-Nummer, im Client nicht als unique definiert.
        /// </summary>
        public int No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Vorname.
        /// </summary>
        public string FirstName
        {
            get { return mFirstName; }
            set { SetProperty(ref mFirstName, value); }
        }

        /// <summary>
        /// Nachname / Firmenname.
        /// </summary>
        public string LastName
        {
            get { return mLastName; }
            set { SetProperty(ref mLastName, value); }
        }

        /// <summary>
        /// Erste Adresszeile nach dem Namen. Wird meistens für Namenszusätze verwendet.
        /// </summary>
        public string AddrLine1
        {
            get { return mAddrLine1; }
            set { SetProperty(ref mAddrLine1, value); }
        }

        /// <summary>
        /// Zweite Adresszeile nach dem Namen. Wird meistens für den Weg verwendet.
        /// </summary>
        public string AddrLine2
        {
            get { return mAdrLine2; }
            set { SetProperty(ref mAdrLine2, value); }
        }

        /// <summary>
        /// Dritte Adresszeile nach dem Namen.
        /// </summary>
        public string AddrLine3
        {
            get { return mAdrLine3; }
            set { SetProperty(ref mAdrLine3, value); }
        }

        /// <summary>
        /// Strasse inkl. Hausnummer-Info
        /// </summary>
        public string Street
        {
            get { return mStreet; }
            set { SetProperty(ref mStreet, value); }
        }

        /// <summary>
        /// Postleitzahl.
        /// </summary>
        public string ZipCode
        {
            get { return mZipCode; }
            set { SetProperty(ref mZipCode, value); }
        }

        /// <summary>
        /// Stadt/Ort.
        /// </summary>
        public string City
        {
            get { return mCity; }
            set { SetProperty(ref mCity, value); }
        }

        /// <summary>
        /// Postfach.
        /// </summary>
        // ReSharper disable once InconsistentNaming
        public string POBox
        {
            get { return mPoBox; }
            set { SetProperty(ref mPoBox, value); }
        }

        /// <summary>
        /// Postfach-Postleitzahl.
        /// </summary>
        // ReSharper disable once InconsistentNaming
        public string POBoxZipCode
        {
            get { return mPoBoxZipCode; }
            set { SetProperty(ref mPoBoxZipCode, value); }
        }

        /// <summary>
        /// Postfach-Ort.
        /// </summary>
        // ReSharper disable once InconsistentNaming
        public string POBoxCity
        {
            get { return mPoBoxCity; }
            set { SetProperty(ref mPoBoxCity, value); }
        }

        /// <summary>
        /// Haupt-Telefon-Nr.
        /// </summary>
        public string Phone1
        {
            get { return mPhone1; }
            set { SetProperty(ref mPhone1, value); }
        }

        /// <summary>
        /// Alternative Telefon-Nr.
        /// </summary>
        public string Phone2
        {
            get { return mPhone2; }
            set { SetProperty(ref mPhone2, value); }
        }

        /// <summary>
        /// Fax-Nr (OXAS => Fax1).
        /// </summary>
        public string Fax
        {
            get { return mFax; }
            set { SetProperty(ref mFax, value); }
        }

        /// <summary>
        /// E-Mail-Adresse.
        /// </summary>
        public string Email
        {
            get { return mEmail; }
            set { SetProperty(ref mEmail, value); }
        }

        ///// <summary>
        ///// Kontaktdaten, abgelegt als komplexes Proerty
        ///// </summary>
        //public Contact ContactPerson {get; set; }

        // Achtung: im aktuellen Pre-Release funktionieren die komplexen Properties einfach noch nicht, ich habs jedenfalls
        // nicht geschafft, diese korrekt zu konfigurieren. Auch die 'ComplexType'-Konfiguration im DBContext gibt es nicht.
        // Darum vorderhand die Kontaktdaten halt als normale Proerties im Adress-Objekt aufführen

        /// <summary>
        /// Vorname der Kontaktperson.
        /// </summary>
        public string ContactPersonFirstName
        {
            get { return mContactPersonFirstName; }
            set { SetProperty(ref mContactPersonFirstName, value); }
        }

        /// <summary>
        /// Nachname der Kontaktperson.
        /// </summary>
        public string ContactPersonLastName
        {
            get { return mContactPersonLastName; }
            set { SetProperty(ref mContactPersonLastName, value); }
        }

        /// <summary>
        /// Erste Telefon-Nr der der Kontaktperson.
        /// </summary>
        public string ContactPersonPhone1
        {
            get { return mContactPersonPhone1; }
            set { SetProperty(ref mContactPersonPhone1, value); }
        }

        /// <summary>
        /// Alternative Telefon-Nr der Kontaktperson.
        /// </summary>
        public string ContactPersonPhone2
        {
            get { return mContactPersonPhone2; }
            set { SetProperty(ref mContactPersonPhone2, value); }
        }

        /// <summary>
        /// Email-Adresse der Kontaktperson.
        /// </summary>
        public string ContactPersonEmail
        {
            get { return mContactPersonEmail; }
            set { SetProperty(ref mContactPersonEmail, value); }
        }

        /// <summary>
        /// Originalwerte des Records: Werte, wie sie ursprünglich von Mof-Service gelesen wurden.
        /// Falls ausgefüllt, so können die aktuellen Werte mit den Originalwerten verglichen werden; falls null, so wurden keine Änderungen an Adresse vorgenommen.
        /// </summary>
        public string OriginalValues
        {
            get { return mOriginalValues; }
            set { SetProperty(ref mOriginalValues, value); }
        }

        /// <summary>
        /// Verknüpfte Adressen
        /// </summary>
        public virtual ICollection<Customer> Customers { get; set; }

        /// <summary>
        /// Liste der Dokument-Adress-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedAddress> DocumentLinkedAddresses { get; set; }
        #endregion
    }
}