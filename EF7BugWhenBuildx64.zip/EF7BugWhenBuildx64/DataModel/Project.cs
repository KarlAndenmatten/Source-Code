﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System.Collections.Generic;

    /// <summary>
    /// Speichert Projekte, welche den Service-Aufträgen zugeordnet sind. 
    /// </summary>
    public class Project : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private int mNo;
        private string mName;
        private string mDescription;
        #endregion


        public Project()
        {
            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            DocumentLinkedProjects = new List<DocumentLinkedProject>();
        }

        /// <summary>
        /// Eindeutige Mof-Service-Id des Projekts.
        /// Falls ausgefüllt, so muss dieses eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Zwingende Projekt-Nummer, in OXAS (Proj.Number) eigentlich eindeutig (in Client aber nicht als unique definiert).
        /// </summary>
        public int No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Projekt-Name/-Bezeichnung.
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }

        /// <summary>
        /// Projekt-Zusatztext-Beschreibung (OXAS-Text1, Text2, Text3).
        /// </summary>
        public string Description
        {
            get { return mDescription; }
            set { SetProperty(ref mDescription, value); }
        }

        /// <summary>
        /// Liste der Dokument-Projekt-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedProject> DocumentLinkedProjects { get; set; }
    }
}