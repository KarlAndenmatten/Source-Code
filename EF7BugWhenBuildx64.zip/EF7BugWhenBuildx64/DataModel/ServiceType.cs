﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Mögliche Leistungsarten = Verrechnungsarten, welche in OXAS-Businessdata 'ServiceType' hinterlegt werden. 
    /// </summary>
    public class ServiceType : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private bool mIsActive;
        private int mNo;
        private string mShortName;
        private string mName;
        #endregion


        #region ==================== Construction, Destruction ====================
        public ServiceType()
        {
            // Per Default sind neue Leistungsarten auch aktiv
            IsActive = true;
        }
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Eindeutige Mof-Service-Id der Leistungsart.
        /// Falls ausgefüllt, so muss dieses eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Falls true, so ist Leistungsart aktiv, darf also noch ausgewählt/zugeteilt/gebucht werden.
        /// Flag kann bei Buchungen auf Sollzeilen interpretiert werden, wird aber vor allem vom Cleanup-Job interpretiert.
        /// </summary>
        public bool IsActive
        {
            get { return mIsActive; }
            set { SetProperty(ref mIsActive, value); }
        }

        /// <summary>
        /// Zwingende Leistungsart-Nr, eindeutig in OXAS.
        /// Diese Nummer identifiziert die Leistungsart auch in OXAS-Businessdata immer ausgefüllt(ServiceType.Number) 
        /// und eindeutig und muss auch im Client immer ausgefüllt sein, aber nicht zwingend eindeutig.
        /// Die Nummer wird auch auf dem Client als numerisch definiert, was Range-Filter erlauben 
        /// würde(für alphanumerische Nummern könnte allenfalls ShortName eingesetzt werden).
        /// </summary>
        public int No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Kurzbezeichnung der Leistungsart (in OXAS ServiceType.ShortName).
        /// Beispiele: Norm, Regie, ...
        /// </summary>
        public string ShortName
        {
            get { return mShortName; }
            set { SetProperty(ref mShortName, value); }
        }

        /// <summary>
        /// Bezeichnung der Leistungsart (in OXAS ServiceType.Name).
        /// Beispiele:   Normal, Regiearbeit, ...
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }
        #endregion
    }
}