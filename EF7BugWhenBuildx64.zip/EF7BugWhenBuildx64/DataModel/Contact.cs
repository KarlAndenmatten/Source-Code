﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Daten eines Kontakts, welche auf der Adresse abgelegt werden.
    /// Kontakte werden aktuell nicht in einer eigenen Tabelle, sondern als komplexes Property direkt auf der Adresse abgelegt
    /// Achtung: im aktuellen Pre-Release funktionieren die komplexen Properties einfach noch nicht, ich habs jedenfalls
    /// nicht geschafft, diese korrekt zu konfigurieren. Auch die 'ComplexType'-Konfiguration im DBContext gibt es nicht.
    /// </summary> 
    [ComplexType]
    public class Contact
    {
        /// <summary>
        /// Vorname der Kontaktperson.
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Nachname der Kontaktperson.
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Erste Telefon-Nr der der Kontaktperson.
        /// </summary>
        public string Phone1 { get; set; }

        /// <summary>
        /// Alternative Telefon-Nr der Kontaktperson.
        /// </summary>
        public string Phone2 { get; set; }

        /// <summary>
        /// Email-Adresse der Kontaktperson.
        /// </summary>
        public string Email { get; set; }

    }
}
