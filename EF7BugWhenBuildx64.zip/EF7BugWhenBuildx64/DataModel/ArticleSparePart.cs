﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// In "ArticleSparePart" können die Ersatzteile eines Artikels hinterlegt werden: Ersatzteile sind Artikel, welche vom Service-Techniker bei der Wartung eines Objekts (Anlage) ausgewechselt werden dürfen.
    /// Dies "Auswechslungen" werden auf dem Service-Auftrag als Ist-Zeilen(ServiceOrderActualItem) gespeichert.
    /// </summary>
    public class ArticleSparePart : ModelBase
    {
        #region ==================== Fields ====================
        private Article mArticle;
        private Article mSpareArticle;
        private string mDescription;
        private decimal? mQuantity;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Referenz auf Ausgangs-Artikel.
        /// Die Ersetzung bezieht sich auf diesen Ausgangs-Artikel.
        /// </summary>
        public Article Article
        {
            get { return mArticle; }
            set { SetProperty(ref mArticle, value); }
        }

        /// <summary>
        /// Referenz auf Ersatzartikel.
        /// Dies ist der Ersatzartikel.
        /// </summary>
        public Article SparePartArticle
        {
            get { return mSpareArticle; }
            set { SetProperty(ref mSpareArticle, value); }
        }

        /// <summary>
        /// Beschreibung des Ersetzung.
        /// Muss noch genauer abgeklärt werden, wie diese in OXAS abgelegt ist.
        /// </summary>
        public string Description
        {
            get { return mDescription; }
            set { SetProperty(ref mDescription, value); }
        }


        /// <summary>
        /// Vorgabe-Menge bei der Ersetzung.
        /// Muss noch genauer abgeklärt werden, wie diese in OXAS abgelegt ist.
        /// </summary>
        public decimal? Quantity
        {
            get { return mQuantity; }
            set { SetProperty(ref mQuantity, value); }
        }
        #endregion
    }
}