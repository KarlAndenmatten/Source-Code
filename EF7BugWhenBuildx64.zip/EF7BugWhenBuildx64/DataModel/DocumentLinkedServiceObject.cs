﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Speichert die mit den Dokumenten verknüpften Objekte.
    /// Die Tabelle implementiert die Many-To-Many-Beziehung zwischen Dokumenten und Objekt. 
    /// </summary>
    public class DocumentLinkedServiceObject : ModelBase
    {
        #region ==================== Fields ====================
        private Document mDocument;
        private ServiceObject mServiceObject;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Referenziert das verknüpfte Dokument.
        /// </summary>
        public Document Document
        {
            get { return mDocument; }
            set { SetProperty(ref mDocument, value); }
        }

        /// <summary>
        /// Referenziert das verknüpfte Objekt.
        /// </summary>
        public ServiceObject ServiceObject
        {
            get { return mServiceObject; }
            set { SetProperty(ref mServiceObject, value); }
        }
        #endregion
    }
}