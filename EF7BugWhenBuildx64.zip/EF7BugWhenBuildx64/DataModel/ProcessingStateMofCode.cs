﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Legt die möglichen Mof-Interpretation der Auftrags-Bearbeitungs-Stati fest.
    /// </summary>
    public enum ProcessingStateMofCode
    {
        /// <summary>
        /// Wird gesetzt, wenn von Mof-Service ein unbekannter Status gemeldet wird.
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// Aufträge in diesem Status werden nicht auf den Client synchronisiert, der Status kann im Client auch nicht gesetzt werden 
        /// => solche Aufträge dürfte es auf client eigentlich auch nicht geben, könnte aber bei Konfigurations-Änderungen trotzdem passieren.
        /// </summary>
        MofInvisible = 1,

        /// <summary>
        /// Der Auftrag wurde dem Service-Mitarbeiter zugeteilt; üblicherweise einer der Startzustände bei Übermittlung an Client
        /// </summary>
        MofAssigned = 3,

        /// <summary>
        /// Auftrag wurde vom Service-Techniker gestartet
        /// </summary>
        MofStarted = 5,

        /// <summary>
        /// Auftrag vom Service-Techniker abgearbeitet, wird bei nächstem Datentransfer zurück übermittelt (End-/Abschluss-Status)
        /// </summary>
        MofCompleted = 9
    }
}