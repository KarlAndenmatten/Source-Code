﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    ///     Hier werden alle aktuellen Client-Einstellungen/-Konfigurationen abgelegt.
    /// </summary>
    public class ClientSetting : ModelBase
    {
        #region ==================== Fields ====================
        private string mKey;
        private string mDescription;
        private string mValue;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        ///     Eindeutiger Name der Einstellung/Konfiguration, identifiziert die Einstellung/Konfiguration.
        /// </summary>
        public string Key
        {
            get { return mKey; }
            set { SetProperty(ref mKey, value); }
        }

        /// <summary>
        ///     Beschreibung der Einstellung/Konfiguration rein informativ.
        /// </summary>
        public string Description
        {
            get { return mDescription; }
            set { SetProperty(ref mDescription, value); }
        }

        /// <summary>
        ///     Konfigurationswert.
        ///     Alle Werte werden generisch in Textform(string) abgelegt, das Settings-Framework sorgt dafür, dass diese korrekt
        ///     interpretiert werden.
        ///     Der Client-Applikation werden die Settings via benannte Settings-Properties typisiert zur Verfügung gestellt.
        /// </summary>
        public string Value
        {
            get { return mValue; }
            set { SetProperty(ref mValue, value); }
        }
        #endregion
    }
}