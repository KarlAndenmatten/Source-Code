﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    ///     Legt die möglichen DB-Log-Level fest.
    ///     Zu überlegen: die Log-Level nur von Logging-Enum in Standard übernehmen statt heir eigene Level zu definieren
    /// </summary>
    public enum MsgLogLevel
    {
        /// <summary>
        ///     Debug-Level für Debugzwecke, Verfolgen Programmablauf, etc.
        ///     Aktuell von PDA-Client nich nicht eingesetzt
        /// </summary>
        Debug = 2,

        /// <summary>
        ///     Info-Level für wichtige Aktionen wie Programm-Start, Programm-Ende, etc.
        /// </summary>
        Info = 4,

        /// <summary>
        ///     Warnungen wie Änderungen an Einstellungen, Verbindungen etc.
        /// </summary>
        Warning = 6,

        /// <summary>
        ///     Fehlermeldungen wie Programm-Abstürze, Service-Fehlermeldungen, Exceptions.
        /// </summary>
        Error = 8
    }
}