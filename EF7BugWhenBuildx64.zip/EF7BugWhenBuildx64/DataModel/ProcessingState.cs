﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Mögliche Auftrags-Stati, welche in OXAS-Businessdata hinterlegt werden. 
    /// den Adressdaten.
    /// </summary>
    public class ProcessingState : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private bool mIsActive;
        private int mNo;
        private string mShortName;
        private string mName;
        private ProcessingStateMofCode mMofStateCode;
        #endregion


        #region ==================== Construction, Destruction ====================
        public ProcessingState()
        {
            // Per Default sind neue Stati auch aktiv
            IsActive = true;
            MofStateCode = ProcessingStateMofCode.Unknown; // Feld zumindest immer ausgefüllt
        }
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Eindeutige Mof-Service-Id des Bearbeitungsstatus.
        /// Falls ausgefüllt, so muss dieses eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Ist Status noch aktiviert? Im Client können nur aktive Stati ausgewählt/zugeteilt werden werden.
        /// </summary>
        public bool IsActive
        {
            get { return mIsActive; }
            set { SetProperty(ref mIsActive, value); }
        }

        /// <summary>
        /// Eindeutige Status-Nummer (im Client alphanumerisch).
        /// </summary>
        public int No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Status-Kurzbezeichnung.
        /// </summary>
        public string ShortName
        {
            get { return mShortName; }
            set { SetProperty(ref mShortName, value); }
        }

        /// <summary>
        /// Status-Bezeichnung.
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }

        public ProcessingStateMofCode MofStateCode
        {
            get { return mMofStateCode; }
            set { SetProperty(ref mMofStateCode, value); }
        }
        #endregion
    }
}