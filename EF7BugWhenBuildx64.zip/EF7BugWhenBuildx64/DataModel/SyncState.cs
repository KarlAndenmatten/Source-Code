﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Legt die möglichen Synchronisations-Stati fest. Nicht jedes Abgleichsobjekt unterstützt alle Stati.
    /// </summary>
    public enum SyncState
    {
        /// <summary>
        /// Von Mof-Service partiell runtergeladen, aber noch nicht vollständig.
        /// Kommt zum Beispiel bei Files zum Tragen, wo nur der File-Name, aber noch kein Inhalt 
        /// runtergeladen wurde.
        /// </summary>
        PartiallyDownloaded = 0,

        /// <summary>
        /// Von Mof-Service runtergeladen.
        /// </summary>
        Downloaded = 1,

        /// <summary>
        /// Auf Client erzeugt, aber noch nicht bereit für Übertragung
        /// </summary>
        CreatedOnClient = 2,

        /// <summary>
        /// Datensatz muss nicht übertragen werden (nur lokal von Bedeutung) -> z.B. einsetzbar in Change-Log
        /// </summary>
        NoSyncNecessary = 3,

        /// <summary>
        /// Datensatz ist bereit für Rückübertragung zu Mof-Service. Vor allem dieser Status ist für Upload Prozess wichtig.
        /// </summary>
        ReadyForUpload = 10,

        /// <summary>
        /// Datensatz verarbeitet, aber nicht zum Service übertragen. 
        /// Kann z.B. sein, wenn für eine Änderung bereits eine neuere Änderung vorliegt, welche stattdessen übertragen wurde.
        /// </summary>
        ConfirmedWithoutUpload = 11,

        /// <summary>
        /// Daten versucht zurückzumelden, aber auf Fehler gelaufen (Daten von Mof-Service nicht verarbeitet). 
        /// Kann teils von IUpload-Prozess weiter berücksichtigt werden (wie ReadyForUpload, aber mehrmalige Versuche)
        /// </summary>
        UploadError = 17,

        /// <summary>
        /// Daten teils an Mof-Service übertragen, aber noch nicht vollständig
        /// </summary>
        PartiallyUploaded = 18,

        /// <summary>
        /// Daten vollständig an Mof-Service übertragen
        /// </summary>
        Uploaded = 20,

        /// <summary>
        /// Daten an Mof-Service übertragen und auf Client nun bereit zum Löschen (z.B. Cleanup-Job)
        /// </summary>
        UploadedAndReadyForCleanup = 30
    }
}