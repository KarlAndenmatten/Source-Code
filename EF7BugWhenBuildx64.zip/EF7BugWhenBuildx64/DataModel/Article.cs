﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System.Collections.Generic;

    /// <summary>
    /// Artikel-Stammdaten, welche von OXAS aufgrund von Sollzeilen und konfigurierten Katalogen 
    /// übernommen werden. 
    /// </summary>
    public class Article : ModelBase
    {
        #region ==================== Fields ====================
        private string mNo;
        private bool mIsActive;
        private string mExternalId;
        private int? mNumericNo;
        private string mName;
        private string mDescription;
        private decimal? mPrice;
        private string mQuantityUnitName;
        private int? mAssortmentNo;
        private ArticleResourceType mResourceType;
        #endregion


        #region ==================== Construction, Destruction ====================
        public Article()
        {
            IsActive = true;
            ResourceType = ArticleResourceType.Unknown;

            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            ArticleCategoryAssignments = new List<ArticleCategoryAssignment>();
            ArticleConnections = new List<ArticleConnection>();
            ArticleRelations = new List<ArticleConnection>();
            ArticleSpareParts = new List<ArticleSparePart>();
            AssignedAsSpareParts = new List<ArticleSparePart>();
            ArticleLinkedDocuments = new List<DocumentLinkedArticle>();
        }
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Eindeutige Mof-Service-Id des Artikels.
        /// Falls ausgefüllt, so muss dieses eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Ist Artikel noch aktiviert? 
        /// Im Client können nur aktive Artikel ausgewählt/gebucht werden.
        /// </summary>
        public bool IsActive
        {
            get { return mIsActive; }
            set { SetProperty(ref mIsActive, value); }
        }

        /// <summary>
        /// (Meist eindeutige) alphanumerische Artikel-Nr. 
        /// Von OXAS wird in dieses Feld die eindeutige externe Artikel-Nummer 'Art.Number' übernommen.
        /// Beispiele:   S60.4.5 / K1040 / HA2-1
        /// </summary>
        public string No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Numerische Artikel-Nr.
        /// Von OXAS wird in dieses Feld die eindeutige interne 'Art.InternalNo' übernommen (wäre also 
        /// eigentlich immer abgefüllt).
        /// Eigentlich wird diese Nummer auf dem Client nicht wirklich benötigt, aber denkbar, 
        /// dass diese für Rückmeldungen oder so eingesetzt werden könnte.
        /// </summary>
        public int? NumericNo
        {
            get { return mNumericNo; }
            set { SetProperty(ref mNumericNo, value); }
        }

        /// <summary>
        /// Artikel-Bezeichnung.
        /// Von OXAS könnte hier das erste ausgefüllte Keyword oder gleich alle Keywords zusammengehängt übernommen werden 
        /// (ist noch abzuklären, was hier genau Sinn macht)
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }

        /// <summary>
        /// Zusätzliche Artikel-Beschreibung.
        /// Hier könnten von OXAS z.B. die erweiterten Artikel-Bezeichnungen zusammengehängt übernommen werden 
        /// (muss noch abgeklärt werden, wie diese in OXAS definiert sind, z.B. Martin Schild fragen)
        /// </summary>
        public string Description
        {
            get { return mDescription; }
            set { SetProperty(ref mDescription, value); }
        }

        /// <summary>
        /// Standardpreis.
        /// Wird aktuell auf dem Client rein informativ abgelegt, da zumindest zum Start kein Verkauf implementiert wird.
        /// </summary>
        public decimal? Price
        {
            get { return mPrice; }
            set { SetProperty(ref mPrice, value); }
        }

        /// <summary>
        /// Bezeichnung der Mengeneinheit.
        /// Aktuell rein informativ. 
        /// </summary>
        public string QuantityUnitName
        {
            get { return mQuantityUnitName; }
            set { SetProperty(ref mQuantityUnitName, value); }
        }

        /// <summary>
        /// Assortiments-Nr.
        /// Wird von OXAS aus 'Art.ArtAssortNo' gelesen und erlaubt das Gruppieren von Artikeln 
        /// (wahrscheinlich eher projektspezifisch).
        /// </summary>
        public int? AssortmentNo
        {
            get { return mAssortmentNo; }
            set { SetProperty(ref mAssortmentNo, value); }
        }

        /// <summary>
        /// Service-Resourcen-Typ. Legt fest, welche Art von Service-Resource der Artikel 
        /// darstellt (Passiv, Arbeit, Weg, Spesen).
        /// Wird von OXAS von 'ArtSal.SimpleArtServeTypeCd' übernommen und auf dem Client interpretiert.
        /// Auf Artikel vom Resource-Typ 'Passiv' wird bei der Übernahme im Client zusätzlich 
        /// das Flag 'IsActive' auf false gestellt, sollten so also nicht mehr gebucht werden können.
        /// </summary>
        public ArticleResourceType ResourceType
        {
            get { return mResourceType; }
            set { SetProperty(ref mResourceType, value); }
        }

        /// <summary>
        /// Die mit dem Artikel verknüpften Kategorie-Zuteilungen.
        /// </summary>
        public virtual List<ArticleCategoryAssignment> ArticleCategoryAssignments { get; set; }

        /// <summary>
        /// Die mit dem Artikel verknüpften Artikel, wo der Artikel als 'Article' definiert ist.
        /// Also Connections, wo der Artikel der Ausgangs-Artikel ist.
        /// </summary>
        public virtual List<ArticleConnection> ArticleConnections { get; set; }

        /// <summary>
        /// Die mit dem Artikel verknüpften Artikel, wo der Artikel als 'ConnectedArtikel' definiert ist.
        /// Also Connections, wo der Artikel der verknüpfte Artikel ist.
        /// </summary>
        public virtual List<ArticleConnection> ArticleRelations { get; set; }

        /// <summary>
        /// Die mit dem Artikel verknüpften Ersatzartikel: der aktuelle Artikel ist der Ausgangsartikel.
        /// </summary>
        public virtual List<ArticleSparePart> ArticleSpareParts { get; set; }

        /// <summary>
        /// Die mit dem Artikel als Ersatzartikel zugewiesenen Artikel: der aktuelle Artikel ist der Ersatzartikel.
        /// </summary>
        public virtual List<ArticleSparePart> AssignedAsSpareParts { get; set; }

        /// <summary>
        /// Liste der Dokument-Artikel-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedArticle> ArticleLinkedDocuments { get; set; }
        #endregion
    }
}