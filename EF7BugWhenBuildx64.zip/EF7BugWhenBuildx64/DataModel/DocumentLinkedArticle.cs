﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Speichert die mit den Dokumenten verknüpften Artikel.
    /// Die Tabelle implementiert die Many-To-Many-Beziehung zwischen Dokumenten und Artikel. 
    /// </summary>
    public class DocumentLinkedArticle : ModelBase
    {
        #region ==================== Fields ====================
        private Document mDocument;
        private Article mArticle;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Referenziert das verknüpfte Dokument.
        /// </summary>
        public Document Document
        {
            get { return mDocument; }
            set { SetProperty(ref mDocument, value); }
        }

        /// <summary>
        /// Referenziert den verknüpften Artikel.
        /// </summary>
        public Article Article
        {
            get { return mArticle; }
            set { SetProperty(ref mArticle, value); }
        }
        #endregion
    }
}