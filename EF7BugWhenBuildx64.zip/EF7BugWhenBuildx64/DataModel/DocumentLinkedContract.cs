﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Speichert die mit den Dokumenten verknüpften Vertrag.
    /// Die Tabelle implementiert die Many-To-Many-Beziehung zwischen Dokumenten und Verträge. 
    /// </summary>
    public class DocumentLinkedContract : ModelBase
    {
        #region ==================== Fields ====================
        private Document mDocument;
        private Contract mContract;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Referenziert das verknüpfte Dokument.
        /// </summary>
        public Document Document
        {
            get { return mDocument; }
            set { SetProperty(ref mDocument, value); }
        }

        /// <summary>
        /// Referenziert den verknüpften Vertrag.
        /// </summary>
        public Contract Contract
        {
            get { return mContract; }
            set { SetProperty(ref mContract, value); }
        }
        #endregion
    }
}