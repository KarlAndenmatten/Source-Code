﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// In der Tabelle 'Document' werden sowohl die von der Opacc-Dokumentverwaltung ausgelieferten Dokumente 
    /// wie auch die auf dem Client erstellten Dokumente gespeichert. 
    /// Ein Dokument hat also eher die Bedeutung einer Dokumentmappe als die eines einzelnen Dokuments.
    /// </summary>
    public class Document : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private bool mIsActive;
        private DocumentCategory mDocumentCategory;
        private DocumentTemplate mDocumentTemplate;
        private string mNo;
        private string mName;
        private bool mIsVisibleInDocumentOverview;
        private DateTime? mDocumentDate;
        #endregion


        public Document()
        {
            IsActive = true;

            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            DocumentLinkedServiceOrders = new List<DocumentLinkedServiceOrder>();
            DocumentLinkedAddresses = new List<DocumentLinkedAddress>();
            DocumentLinkedCustomers = new List<DocumentLinkedCustomer>();
            DocumentLinkedArticles = new List<DocumentLinkedArticle>();
            DocumentLinkedServiceObjects = new List<DocumentLinkedServiceObject>();
            DocumentLinkedProjects = new List<DocumentLinkedProject>();
            DocumentLinkedContracts = new List<DocumentLinkedContract>();
            DocumentFiles = new List<DocumentFile>();
        }

        /// <summary>
        /// Eindeutige Mof-Service-Id, welche das Dokument auf der Mof-Service-Schnittstelle eindeutig identifiziert.        
        /// Wird vom Mof-Service definiert/erzeugt.Bei Dokumenten, welche im Client erzeugt werden, 
        /// ist dieses Feld leer(null). Falls ausgefüllt, so muss diese eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Document ist aktiv ja/nein.
        /// Das Dokument wird inaktiv gesetzt, wenn für dieses vom Mof-Service eine Löschanweisung bekommt 
        /// (eventuell wird dies in diesem Fall aber auch direkt gelöscht).
        /// </summary>
        public bool IsActive
        {
            get { return mIsActive; }
            set { SetProperty(ref mIsActive, value); }
        }

        /// <summary>
        /// Referenziert die Dokument-Kategorie, welcher das Dokument zugeordnet ist.
        /// Müsste bei vom Mof-Service empfangenen Dokumenten eigentlich immer ausgefüllt sein, 
        /// bei im Client erstellten Dokumenten muss die Kategorie aber nicht zwingend ausgefüllt werden.
        /// </summary>
        public DocumentCategory DocumentCategory
        {
            get { return mDocumentCategory; }
            set { SetProperty(ref mDocumentCategory, value); }
        }

        /// <summary>
        /// Referenziert das Template, welches bei neuen Dokumenten angewendet werden soll.
        /// Dieses muss nur bei auf dem Client erstellten Dokumenten ausgefüllt werden und wird verwendet, 
        /// um im DMAS ein neues Dokument anzulegen. Falls bei neuen Dokumenten kein Template ausgefüllt wird, 
        /// kommt das in der Service-Konfiguration hinterlegte Default-Dokument zum Tragen.
        /// </summary>
        public DocumentTemplate DocumentTemplate
        {
            get { return mDocumentTemplate; }
            set { SetProperty(ref mDocumentTemplate, value); }
        }

        /// <summary>
        /// Dokument-Nr.
        /// Identifiziert die Kategorie in der Opacc-Dokument-Verwaltung
        /// </summary>
        public string No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Dokument-Bezeichnung.
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }

        /// <summary>
        /// Nur falls true (Default) wird das Dokument auf dem Client in der Dokument-Übersicht angezeigt.
        /// Falls false, so wird das Dokument auf dem Client in der Dokumentverwaltung nicht angezeigt, 
        /// aber zum MOF-Server hochgeladen. Die ist z.B. bei der Unterschriftsdatei der Fall, 
        /// welche in der Dokument-Übersicht nicht angezeigt wird (Anzeige würde aber eigentlich auch nicht stören oder?).
        /// 
        /// </summary>
        public bool IsVisibleInDocumentOverview
        {
            get { return mIsVisibleInDocumentOverview; }
            set { SetProperty(ref mIsVisibleInDocumentOverview, value); }
        }

        /// <summary>
        /// Dokument-Datum, im Normalfall Erstelldatum.
        /// Wird vom MOF-Server ausgeliefert resp. wird bei auf dem Client erzeugten Dokumenten automatisch das aktuelle 
        /// Datum eingefüllt (müsste also eigentlich immer ausgefüllt sein).
        /// </summary>
        public DateTime? DocumentDate
        {
            get { return mDocumentDate; }
            set { SetProperty(ref mDocumentDate, value); }
        }

        /// <summary>
        /// Liste der im Dokument abgelegten Files.
        /// </summary>
        public virtual List<DocumentFile> DocumentFiles { get; set; }

        /// <summary>
        /// Liste der Dokument-Serviceauftrags-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedServiceOrder> DocumentLinkedServiceOrders { get; set; }

        /// <summary>
        /// Liste der Dokument-Adress-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedAddress> DocumentLinkedAddresses { get; set; }

        /// <summary>
        /// Liste der Dokument-Kunden-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedCustomer> DocumentLinkedCustomers { get; set; }

        /// <summary>
        /// Liste der Dokument-Artikel-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedArticle> DocumentLinkedArticles { get; set; }

        /// <summary>
        /// Liste der Dokument-Objekt-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedServiceObject> DocumentLinkedServiceObjects { get; set; }

        /// <summary>
        /// Liste der Dokument-Projekt-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedProject> DocumentLinkedProjects { get; set; }

        /// <summary>
        /// Liste der Dokument-Vertrag-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedContract> DocumentLinkedContracts { get; set; }
    }
}