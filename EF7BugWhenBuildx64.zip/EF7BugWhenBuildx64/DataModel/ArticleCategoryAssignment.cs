﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Artikel-Kategorie-Zuordnungen, welche von OXAS-Katalogen übernommen werden
    /// </summary>
    public class ArticleCategoryAssignment : ModelBase
    {
        #region ==================== Fields ====================
        private Article mArticle;
        private ArticleCategory mArticleCategory;
        private int? mRank;
        #endregion


        #region ==================== Construction, Destruction ====================
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Referenz auf Artikel.
        /// Die Zuordnung betrifft diesen Artikel.
        /// </summary>
        public Article Article
        {
            get { return mArticle; }
            set { SetProperty(ref mArticle, value); }
        }

        /// <summary>
        /// Referenz auf Artikel-Kategorie.
        /// Die Zuordnung betrifft diese Artikel-Kategory.
        /// </summary>
        public ArticleCategory ArticleCategory
        {
            get { return mArticleCategory; }
            set { SetProperty(ref mArticleCategory, value); }
        }

        /// <summary>
        /// Sortier-Nr: legt Reihenfolge bei Auswahlen innerhalb der Kategorie fest.
        /// Von OXAS wird das Attribut "CatItem.SortNo" gelesen und hier abgefüllt.
        /// </summary>
        public int? Rank
        {
            get { return mRank; }
            set { SetProperty(ref mRank, value); }
        }
        #endregion
    }
}