﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System;

    /// <summary>
    ///     Die übermittelten Istzeilen eines Serviceauftrags.
    /// </summary>
    public class ServiceOrderActualItem : ModelBase
    {
        #region ==================== Fields ====================
        private ServiceOrder mServiceOrder;
        private ServiceOrderPart mServiceOrderPart;
        private ServiceOrderPlannedItem mServiceOrderPlannedItem;
        private Article mArticle;
        private ServiceType mServiceType;
        private ServiceObject mServiceObject;
        private DateTime mBookingDate;
        private decimal mQtyEffective;
        private decimal mQtyChargeable;
        private decimal mPrice;
        private bool mHasBeenCreatedAutomatically;
        private string mExternalNote;
        private string mInternalNote;
        private SyncState mSyncState;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        ///     Referenz auf Service-Auftrag, zu welchem die Istzeile gehört.
        ///     Diese Referenz muss immer ausgefüllt sein, auch wenn die Istzeile zusätzlich mit einer
        ///     Sollzeile oder einer Zuteilung verknüpft ist.In diesem Fall muss dann natürlich der
        ///     dort zugewiesene Auftrag mit dem hier verknüpften Auftrag übereinstimmen.
        /// </summary>
        public ServiceOrder ServiceOrder
        {
            get { return mServiceOrder; }
            set { SetProperty(ref mServiceOrder, value); }
        }

        /// <summary>
        ///     Referenz auf die Zuteilung, mit welchem die Istzeile optional verknüpft sein kann.
        ///     Diese Referenz muss auch ausgefüllt sein, auch wenn die Istzeile zusätzlich mit einer Sollzeile verknüpft ist.
        ///     In diesem Fall muss dann natürlich die dort zugewiesene Zuteilung mit der hier verknüpften Zuteilung
        ///     übereinstimmen.
        ///     Zum Start müsste diese Referenz eigentlich immer ausgefüllt sein, weil nur die
        ///     Struktur 'Auftrag -> Zuteilung -> Sollzeile' unterstützt wird, auf dem Client trotzdem optional.
        /// </summary>
        public ServiceOrderPart ServiceOrderPart
        {
            get { return mServiceOrderPart; }
            set { SetProperty(ref mServiceOrderPart, value); }
        }

        /// <summary>
        ///     Referenz auf die Sollzeile, mit welcher die Istzeile optional verknüpft sein kann.
        /// </summary>
        public ServiceOrderPlannedItem ServiceOrderPlannedItem
        {
            get { return mServiceOrderPlannedItem; }
            set { SetProperty(ref mServiceOrderPlannedItem, value); }
        }

        /// <summary>
        ///     Referenz auf Artikel: Artikel.
        ///     Auf der Istzeile muss der Artikel zwingend ausgefüllt sein, auch wenn diese mit einer Sollzeile verknüpft
        ///     ist (in diesem Fall ist der Artikel dann halt identisch).
        /// </summary>
        public Article Article
        {
            get { return mArticle; }
            set { SetProperty(ref mArticle, value); }
        }

        /// <summary>
        ///     Referenz auf die Verrechnungsart/Leistungsart, in OXAS ist dies 'AsstDocItem.ServiceTypeNo'.
        ///     Auf der Istzeile muss zwingend ein Service-Typ ausgefüllt werden, dieser kann/darf sich auch von einer auf der
        ///     Sollzeile ausgefüllten Vorgabe unterscheiden.
        ///     Die möglichen/vorkommenden Leistungsarten werden von OXAS von der Tabelle 'ServiceType' gelesen und als
        ///     Stammdaten abgeglichen.
        /// </summary>
        public ServiceType ServiceType
        {
            get { return mServiceType; }
            set { SetProperty(ref mServiceType, value); }
        }

        /// <summary>
        ///     Referenz auf das mit der Istzeile verknüpfte Objekt, falls die Istzeile mit der Objektverwaltung verknüpft ist.
        ///     In vielen Fällen beziehen sich Istwerte nicht auf Objekte, ist diese Referenz also null.
        /// </summary>
        public ServiceObject ServiceObject
        {
            get { return mServiceObject; }
            set { SetProperty(ref mServiceObject, value); }
        }

        /// <summary>
        ///     Buchungsdatum/Zeit: dieses Datum wird auch in OXAS verbucht.
        /// </summary>
        public DateTime BookingDate
        {
            get { return mBookingDate; }
            set { SetProperty(ref mBookingDate, value); }
        }

        /// <summary>
        ///     Effektive gebuchte Istmenge.
        ///     Muss im Unterschied zur Sollzeile hier immer ausgefüllt werden.
        /// </summary>
        public decimal QtyEffective
        {
            get { return mQtyEffective; }
            set { SetProperty(ref mQtyEffective, value); }
        }

        /// <summary>
        ///     Istmenge, welche auch belastet/fakturiert werden darf.
        ///     Muss im Unterschied zur Sollzeile hier immer ausgefüllt werden.
        /// </summary>
        public decimal QtyChargeable
        {
            get { return mQtyChargeable; }
            set { SetProperty(ref mQtyChargeable, value); }
        }

        /// <summary>
        ///     Preis/Kosten, welcher belastet werden kann/soll.
        /// </summary>
        public decimal Price
        {
            get { return mPrice; }
            set { SetProperty(ref mPrice, value); }
        }

        /// <summary>
        ///     True, falls Istwert/Istzeile automatisch erzeugt, also nicht durch den Benutzer manuell erfasst wurde.
        /// </summary>
        public bool HasBeenCreatedAutomatically
        {
            get { return mHasBeenCreatedAutomatically; }
            set { SetProperty(ref mHasBeenCreatedAutomatically, value); }
        }

        /// <summary>
        ///     Vom Benutzer zum Istwert erfasster Hinweis/Mitteilung/Bemerkung, welcher auch für den Kunden gedacht ist.
        /// </summary>
        public string ExternalNote
        {
            get { return mExternalNote; }
            set { SetProperty(ref mExternalNote, value); }
        }

        /// <summary>
        ///     Vom Benutzer zum Istwert erfasster Hinweis/Mitteilung/Bemerkung, welcher nur für den Innendienst bestimmt ist.
        /// </summary>
        public string InternalNote
        {
            get { return mInternalNote; }
            set { SetProperty(ref mInternalNote, value); }
        }

        /// <summary>
        ///     Synchronisations-Status der Istzeile.
        ///     Achtung: der Status ist eher überflüssig, wenn neu der Auftrag nur noch gesamthaft zurückgemeldet würde.
        ///     In diesem Fall würde der Synchronisations-Zustand ziemlich sicher nur noch auf dem Auftrag geführt.
        ///     Im Client als Enum 'SyncState' abgebildet, wobei hier davon folgende Stati zum Tragen kommen:
        ///     2 = 'CreatedOnClient': Istwert in Client erzeugt
        ///     (17='UploadError'): Istwert konnte nicht erfolgreich an Mof-Service übermittelt werden
        ///     => kommt aber wahrscheinlich nicht zum Tragen
        ///     20 = 'Uploaded': Istwert erfolgreich an Mof-Service übermittelt
        /// </summary>
        public SyncState SyncState
        {
            get { return mSyncState; }
            set { SetProperty(ref mSyncState, value); }
        }
        #endregion
    }
}