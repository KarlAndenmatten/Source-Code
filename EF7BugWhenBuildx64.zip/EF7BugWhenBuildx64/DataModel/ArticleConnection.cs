﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Artikel-Verknüpfungen, welche für die abgeglichenen Artikel von OXAS-Tabelle 'ConnectedArt' 
    /// inkl. Verknüpfungstyp übernommen werden.
    /// Artikel können untereinander beliebig Many-To-Many verknüpft werden.
    /// Die verknüpften Artikel eines Artikels können aus dieser Tabelle eruiert werden:
    /// + Der Artikel ist als Ausgangs-Artikel erfasst => alle Connected-Artikel
    /// + Der Artikel ist als Connected-Artikel erfasst => alle Ausgangs-Artikel
    /// </summary>
    public class ArticleConnection : ModelBase
    {
        #region ==================== Fields ====================
        private Article mArticle;
        private Article mConnectedArticle;
        private ArticleConnectionType mArticleConnectionType;
        private int? mSeqNo;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Referenz auf Ausgangs-Artikel.
        /// Die Zuordnung betrifft diesen Artikel.
        /// </summary>
        public Article Article
        {
            get { return mArticle; }
            set { SetProperty(ref mArticle, value); }
        }

        /// <summary>
        /// Referenz auf verknüpften Artikel.
        /// Der Ausgangs-Artikel ist mit diesem Artikel verknüpft, wobei die Bedeutung 
        /// aus 'ArticleConnectionType' herausgelesen werden kann.
        /// </summary>
        public Article ConnectedArticle
        {
            get { return mConnectedArticle; }
            set { SetProperty(ref mConnectedArticle, value); }
        }

        /// <summary>
        /// Referenz auf den Verknüpfungs-Typ.
        /// Legt die Art der Verknüpfung fest, wie der Ausgangsartikel mit dem Ziel-Artikel verknüpft ist.
        /// </summary>
        public ArticleConnectionType ArticleConnectionType
        {
            get { return mArticleConnectionType; }
            set { SetProperty(ref mArticleConnectionType, value); }
        }

        /// <summary>
        /// Lauf-Nr.
        /// Könnte im Client auch als Sortier-Nr interpretiert werden(Attribut 'Rank' wäre auch nicht schlecht): legt Reihenfolge innerhalb der Verknüpfungen fest.Könnte aber auch für weitere Zwecke eingesetzt werden.
        /// Von OXAS wird das Attribut "ConnectedArt.SeqNo" gelesen und hier abgefüllt.
        /// Die Lauf-Nr wird im ERP automatisch ausgefüllt, falls vom Benutzer nicht explizit eingegeben.
        /// </summary>
        public int? SeqNo
        {
            get { return mSeqNo; }
            set { SetProperty(ref mSeqNo, value); }
        }
        #endregion
    }
}