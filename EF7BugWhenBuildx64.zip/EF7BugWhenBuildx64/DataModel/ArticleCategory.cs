﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System.Collections.Generic;

    /// <summary>
    /// Artikel-Kategorien, welche aufgrund der Service-Konfiguration von OXAS-Katalogen übernommen werden
    /// </summary>
    public class ArticleCategory : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private bool mIsActive;
        private int mNo;
        private string mName;
        #endregion


        public ArticleCategory()
        {
            IsActive = true;

            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            ArticleCategoryAssignments = new List<ArticleCategoryAssignment>();
        }

        /// <summary>
        /// Eindeutige Mof-Service-Id der Kategorie.
        /// Falls ausgefüllt, so muss dieses eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Im Client können nur aktive Kategorien ausgewählt werden.
        /// </summary>
        public bool IsActive
        {
            get { return mIsActive; }
            set { SetProperty(ref mIsActive, value); }
        }

        /// <summary>
        /// Numerische Kategorie-Nr. Muss im Client ausgefüllt aber nicht zwingend eindeutig sein.
        /// Von OXAS wird das Attribut "CatStruct.Number" gelesen und hier abgefüllt.
        /// Wird im Normalfall automatisch vergeben. Katalog kann aber auch so eingestellt werden, 
        /// dass die Nummer manuell vergeben werden kann.
        /// </summary>
        public int No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Kategorie-Bezeichnung.
        /// Von OXAS wird das Attribut "CatStruct.Name" gelesen und hier abgefüllt.
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }

        /// <summary>
        /// Die mit der Artikel-Kategorie verknüpften Artikel-Zuteilungen.
        /// </summary>
        public virtual List<ArticleCategoryAssignment> ArticleCategoryAssignments { get; set; }
    }
}