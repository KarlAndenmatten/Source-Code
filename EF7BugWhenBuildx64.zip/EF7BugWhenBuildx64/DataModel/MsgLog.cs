﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    ///     Hier werden alle vom Client geloggten Meldungen abgelegt.
    /// </summary>
    public class MsgLog : ModelBase
    {
        #region ==================== Fields ====================
        private MsgLogLevel mLevel;
        private string mMsg;
        private string mMsgDetail;
        #endregion


        #region ==================== Construction, Destruction ====================
        public MsgLog()
        {
            Level = MsgLogLevel.Info;
        }
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        ///     Definiert den Schweregrad der Meldung.
        ///     Auf dem Client als enum mit folgenden Werten verfügbar:
        ///     2 = 'Debug': Debug-Level für Debugzwecke, Verfolgen Programmablauf, etc.
        ///     4 = 'Info': Info-Level für wichtige Aktionen wie Programm-Start, Programm-Ende, etc.
        ///     6 = 'Warning': Warnungen wie Änderungen an Einstellungen, Verbindungen etc.
        ///     8 = 'Error': Fehlermeldungen wie Programm-Abstürze, Service-Fehlermeldungen, Exceptions.
        /// </summary>
        public MsgLogLevel Level
        {
            get { return mLevel; }
            set { SetProperty(ref mLevel, value); }
        }

        /// <summary>
        ///     Meldung, welche von der Applikation geloggt wurde.
        ///     Bei Fehlern ist dies die Fehlermeldung, aber ohne verschachtelte(innere) Fehermeldungen.
        /// </summary>
        public string Msg
        {
            get { return mMsg; }
            set { SetProperty(ref mMsg, value); }
        }

        /// <summary>
        ///     Details zur Fehlermeldung, welche Zusatzinformationen liefern.
        ///     Beispiele: von Applikation geschriebene Zusatz-Information, Stacktrace bei Exceptions(innere Fehlermeldungen) etc.
        ///     Im UI sollten diese zusätzlich eingesehen werden können(auch z.B.bereits bei der Meldungsanzeige, nicht nur im
        ///     Log-UI).
        /// </summary>
        public string MsgDetail
        {
            get { return mMsgDetail; }
            set { SetProperty(ref mMsgDetail, value); }
        }
        #endregion
    }
}