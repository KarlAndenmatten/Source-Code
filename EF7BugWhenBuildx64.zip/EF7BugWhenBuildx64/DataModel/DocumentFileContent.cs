﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Der eigentliche File-Inhalt wird aus Perfomancegründen von den File-Metainformationen separiert in der Tabelle 
    /// 'FileContent' abgelegt, als 1-1-Beziehung. 
    /// Der File-Inhalt wird vom File referenziert, die umgekehrte Referenz wäre aber natürlich auch möglich gewesen.
    /// </summary>
    public class DocumentFileContent : ModelBase
    {
        #region ==================== Fields ====================
        private byte[] mContent;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// File-Inhalt als Blob abgespeichert.        
        /// Darf null sein, damit z.B. auch leere Inhalte abgespeichert werden könnten. 
        /// In diesem Fall könnte alternativ auch der Link auf File null gesetzt werden, ist aber so schon klarer, da File 
        /// ja runtergeladen/erstellt wurde, aber halt einfach leer ist.
        /// </summary>
        public byte[] Content
        {
            get { return mContent; }
            set { SetProperty(ref mContent, value); }
        }
        #endregion
    }
}