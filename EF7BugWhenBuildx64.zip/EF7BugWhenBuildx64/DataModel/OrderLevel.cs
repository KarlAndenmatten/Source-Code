﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Legt die möglichen Rapportstufen fest.
    /// </summary>
    public enum OrderLevel
    {
        /// <summary>
        /// Default-Level. Kann im Client auch als 'Unknown' interpretiert werden.
        /// </summary>
        Default = 0,

        /// <summary>
        /// Montage
        /// </summary>
        Assemblage = 1,

        /// <summary>
        /// Unterhalt
        /// </summary>
        Maintenance = 2,

        /// <summary>
        /// Störung
        /// </summary>
        Trouble = 3,

        /// <summary>
        /// Shop Order
        /// </summary>
        Sundries = 1
    }
}