﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Speichert die mit den Dokumenten verknüpften Service-Aufträge.
    /// Die Tabelle implementiert die Many-To-Many-Beziehung zwischen Dokumenten und Service-Aufträgen. 
    /// </summary>
    public class DocumentLinkedServiceOrder : ModelBase
    {
        #region ==================== Fields ====================
        private Document mDocument;
        private ServiceOrder mServiceOrder;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Referenziert das verknüpfte Dokument.
        /// </summary>
        public Document Document
        {
            get { return mDocument; }
            set { SetProperty(ref mDocument, value); }
        }

        /// <summary>
        /// Referenziert den verknüpften Service-Auftrag.
        /// </summary>
        public ServiceOrder ServiceOrder
        {
            get { return mServiceOrder; }
            set { SetProperty(ref mServiceOrder, value); }
        }
        #endregion
    }
}