﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System;

    /// <summary>
    /// In dieser Log-Tabelle werden alle wichtige Änderungen am Service-Auftrag (inkl. Zeitstempel) festgehalten, 
    /// welche zum Teil auch vor dem Auftragsabschluss separat an den Mof-Service zurückgemeldet werden.
    /// </summary>
    public class ServiceOrderChangeLog : ModelBase
    {
        #region ==================== Fields ====================
        private ServiceOrder mServiceOrder;
        private OrderModificationType mModificationType;
        private ProcessingState mOldProcessingState;
        private ProcessingState mNewProcessingState;
        private string mOldTextData;
        private string mNewTextData;
        private DateTime? mOldDateData;
        private DateTime? mNewDateData;
        private SyncState mSyncState;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Service-Auftrag, welcher verändert wurde (für welchen Log geschrieben wurde).
        /// </summary>
        public ServiceOrder ServiceOrder
        {
            get { return mServiceOrder; }
            set { SetProperty(ref mServiceOrder, value); }
        }

        /// <summary>
        /// Definiert die Art der Änderung. Gewisse Änderungen könnten aus den Daten eruiert werden (z.B. Statuswechsel), bei anderen Änderungen werden aber 
        /// generische Felder eingesetzt (z.B. Notizen). Folgende Modifikationen werden unterstützt:
        /// + 1 = "Status": Statuswechsel
        /// + 2 = "InternalNote": Interner Hinweis an Innendienst erfasst/geändert
        /// + 3 = "ExternalNote": Externer Hinweis erfasst/geändert
        /// + 4 = "OrderDate": Auftragsdatum geändert
        /// + 5 = "AppointmentDate": Verabredungstermin geändert
        /// </summary>
        public OrderModificationType ModificationType
        {
            get { return mModificationType; }
            set { SetProperty(ref mModificationType, value); }
        }

        /// <summary>
        /// Alter Bearbeitungs-Status, falls ein Statuswechsel vorgenommen wurde.
        /// Referenziert ProcessingState und ist nur bei Statuswechseln ausgefüllt.
        /// </summary>
        public ProcessingState OldProcessingState
        {
            get { return mOldProcessingState; }
            set { SetProperty(ref mOldProcessingState, value); }
        }

        /// <summary>
        /// Neuer Bearbeitungs-Status, falls ein Statuswechsel vorgenommen wurde.
        /// Referenziert ProcessingState und ist nur bei Statuswechseln ausgefüllt.
        /// </summary>
        public ProcessingState NewProcessingState
        {
            get { return mNewProcessingState; }
            set { SetProperty(ref mNewProcessingState, value); }
        }

        /// <summary>
        /// Bisherige Textdaten, Bedeutung aus ModificationType ersichtlich.
        /// </summary>
        public string OldTextData
        {
            get { return mOldTextData; }
            set { SetProperty(ref mOldTextData, value); }
        }

        /// <summary>
        /// Neue/Geänderte Textdaten, Bedeutung aus ModificationType ersichtlich.
        /// </summary>
        public string NewTextData
        {
            get { return mNewTextData; }
            set { SetProperty(ref mNewTextData, value); }
        }

        /// <summary>
        /// Bisherige Datumsdaten, Bedeutung aus ModificationType ersichtlich.
        /// </summary>
        public DateTime? OldDateData
        {
            get { return mOldDateData; }
            set { SetProperty(ref mOldDateData, value); }
        }

        /// <summary>
        /// Neue/Geänderte Datumsdaten, Bedeutung aus ModificationType ersichtlich.
        /// </summary>
        public DateTime? NewDateData
        {
            get { return mNewDateData; }
            set { SetProperty(ref mNewDateData, value); }
        }

        /// <summary>
        /// Synchronisations-Status gegenüber dem Mof-Service.
        /// Im Client als Enum 'SyncState' abgebildet, wobei hier davon folgende Stati zum Tragen kommen:
        /// + 3 = 'NoSyncNecessary': Änderung muss nicht an Mof-Service übermittelt werden
        /// + 10 = 'ReadyForUpload': Änderung bereit zur Übermittlung, noch nicht übermittelt
        /// + 11 = 'ConfirmedWithoutUpload': Änderung muss nicht übermittelt werden, weil bereits neuere Änderung vorlag
        /// + 17 = UploadError: Änderung konnte nicht zurückgemeldet werden, eventuell weiter versuchen
        /// + 19 = 'Uploaded': Änderung an Mof-Service übermittelt
        /// </summary>
        public SyncState SyncState
        {
            get { return mSyncState; }
            set { SetProperty(ref mSyncState, value); }
        }
        #endregion
    }
}