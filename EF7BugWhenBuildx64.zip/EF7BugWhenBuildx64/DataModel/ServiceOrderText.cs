﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// An dem Client werden die OXAS-Serviceauftrags-Konditions-Texte ('AsstDocCondText')
    /// als Auftrags-Texte in 'ServiceOrderText' abgelegt
    /// </summary>
    public class ServiceOrderText : ModelBase
    {
        #region ==================== Fields ====================
        private ServiceOrder mServiceOrder;
        private int mNo;
        private string mTitle;
        private string mText;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Service-Auftrag, für welchen der Text erfasst wurde.
        /// </summary>
        public ServiceOrder ServiceOrder
        {
            get { return mServiceOrder; }
            set { SetProperty(ref mServiceOrder, value); }
        }

        /// <summary>
        /// Text-Nr (OXAS: 'AsstDocCondText.Number').
        /// Die Nummer kann in OXAS frei vergeben werden, auf dem Client können die Texte auch gleich nach 
        /// dieser Nummer sortiert werden(alternativ hätte man das Attribut auch 'RankNo' benennen können, 
        /// 'No' ist aber näher bei der OXAS-Namensgebung).
        /// </summary>
        public int No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Text-Titel (OXAS: 'AsstDocCondText.Name').
        /// </summary>
        public string Title
        {
            get { return mTitle; }
            set { SetProperty(ref mTitle, value); }
        }

        /// <summary>
        /// Eigentlicher Text, welcher angezeigt werden soll (OXAS: 'AsstDocCondText.Text').
        /// </summary>
        public string Text
        {
            get { return mText; }
            set { SetProperty(ref mText, value); }
        }
        #endregion
    }
}