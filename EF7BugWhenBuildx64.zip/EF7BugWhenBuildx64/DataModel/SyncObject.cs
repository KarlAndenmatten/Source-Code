﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Hier werden Informationen zum aktuellen Stand der Datensynchronisation Mof-Service <=> Mof-Client abgelegt.
    /// </summary>
    public class SyncObject : ModelBase
    {
        #region ==================== Fields ====================
        private string mKey;
        private string mDescription;
        private string mSyncToken;
        private string mLastSyncError;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Eindeutiger Name des Synchronisations-Objekts, identifiziert das Synchronisations-Objekt.
        /// Dieser Key wird vom Abgleichstask vergeben(könnte z.B. enum-Bezeichner sein) und dient als 
        /// Stellvertreter für die Daten, welche mit dieser Replikation abgeglichen werden.
        /// Das kann Daten einer einzigen Tabelle oder aber mehrerer Tabellen betreffen.
        /// </summary>
        public string Key
        {
            get { return mKey; }
            set { SetProperty(ref mKey, value); }
        }

        /// <summary>
        /// Beschreibung des Synchronisationsobjekts, rein informativ.
        /// Hier können z.B.die mit dem Synchronisationsobjekt verknüpften Tabellen aufgelistet werden.
        /// </summary>
        public string Description
        {
            get { return mDescription; }
            set { SetProperty(ref mDescription, value); }
        }

        /// <summary>
        /// Beinhaltet Informationen zum letzten Abgleich des Objekts.
        /// Das Token wird vom Mof-Service generiert und enthält objektabhängig die entsprechende Information, welche der Mof-Service benötigt, 
        /// um den inkrementellen Datenabgleich zu realisieren.
        /// Im Token kann, muss aber nicht Zeit-Information abgelegt werden, das Token sollte vom Client auch überhaupt nicht interpretiert, sondern nur abgespeichert 
        /// und beim nächsten Abgleich an den Mof-Service ausgeliefert werden.
        /// Einzige Ausnahme: Null-Setzen des Tokens ist erlaubt und hat Bedeutung eines Neuabgleichs(Gesamtabgleichs) der mit dem Objekt 
        /// verknüpften Daten(=> Mechanismus erlaubt User-UI mit Anstossen eines Totalabgleichs).
        /// </summary>
        public string SyncToken
        {
            get { return mSyncToken; }
            set { SetProperty(ref mSyncToken, value); }
        }

        /// <summary>
        /// Alle Fehler, welche bei der letzten Synchronisation der Objektdaten aufgetreten sind.
        /// Das Feld sollte vom Abgleichstask mit jedem Abgleich jeweils neu geschrieben werden, also immer nur Info zum letzten Abgleich beinhalten.
        /// Falls leer(null), so ist kein Fehler aufgetreten(Abgleich der Objektdaten 100% erfolgreich) => erlaubt auch Filter in User-UI.
        /// </summary>
        public string LastSyncError
        {
            get { return mLastSyncError; }
            set { SetProperty(ref mLastSyncError, value); }
        }
        #endregion
    }
}