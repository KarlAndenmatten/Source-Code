﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Speichert die mit den Dokumenten verknüpften Projekte.
    /// Die Tabelle implementiert die Many-To-Many-Beziehung zwischen Dokumenten und Projekt. 
    /// </summary>
    public class DocumentLinkedProject : ModelBase
    {
        #region ==================== Fields ====================
        private Document mDocument;
        private Project mProject;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Referenziert das verknüpfte Dokument.
        /// </summary>
        public Document Document
        {
            get { return mDocument; }
            set { SetProperty(ref mDocument, value); }
        }

        /// <summary>
        /// Referenziert das verknüpfte Projekt.
        /// </summary>
        public Project Project
        {
            get { return mProject; }
            set { SetProperty(ref mProject, value); }
        }
        #endregion
    }
}