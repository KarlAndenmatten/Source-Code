﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System.Collections.Generic;

    /// <summary>
    /// Artikel-Stammdaten, welche von OXAS aufgrund von Sollzeilen und konfigurierten Katalogen 
    /// übernommen werden. 
    /// </summary>
    public class ServiceObject : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private ServiceObject mParentServiceObject;
        private ServiceObject mReplacedServiceObject;
        private Article mArticle;
        private Address mAddress;
        private string mDescription;
        private string mSubType;
        private string mRemark;
        private SyncState mSyncState;
        private string mOriginalValues;
        #endregion


        #region ==================== Construction, Destruction ====================
        public ServiceObject()
        {
            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            ServiceObjectAddresses = new List<ServiceObjectAddress>();
            ServiceObjectHistories = new List<ServiceObjectHistory>();
            DocumentLinkedServiceObjects = new List<DocumentLinkedServiceObject>();
        }
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Eindeutige Mof-Service-Id des Objekts.
        /// Falls ausgefüllt, so muss dieses eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Verweis/Referenz auf das Parent-Objekt (Selbstreferenz).
        /// Objekte lassen sich verschachteln(ein Objekt enthält ein anderes Objekt, …). 
        /// Dies kommt natürlich vor allem bei Anlagen und so zum Tragen.
        /// </summary>
        public ServiceObject ParentServiceObject
        {
            get { return mParentServiceObject; }
            set { SetProperty(ref mParentServiceObject, value); }
        }

        /// <summary>
        /// Verweis/Referenz auf das Objekt, welches durch dieses Objekt ersetzt wurde (Selbstreferenz).
        /// Manchmal werden Objekte durch andere ersetzt(z.B.Feuerlöscher), in solchen Fällen verweist 
        /// das neue Objekt via diesem Verweis auf das ursprüngliche Objekt, welches ersetzt wurde.
        /// </summary>
        public ServiceObject ReplacedServiceObject
        {
            get { return mReplacedServiceObject; }
            set { SetProperty(ref mReplacedServiceObject, value); }
        }

        /// <summary>
        /// Referenz auf Artikel.
        /// Objekte selber sind praktisch immer mit einem Artikel verknüpft: das Objekt ist 
        /// sozusagen eine spezielle Artikel-Instanz(=> so z.B.auch Artikel-Mengenberechnung 
        /// via verknüpfte Objekte möglich). 
        /// </summary>
        public Article Article
        {
            get { return mArticle; }
            set { SetProperty(ref mArticle, value); }
        }

        /// <summary>
        /// Referenz auf die Haupt-Adresse des Objekts, wird in OXAS von 'ObjItem.AddrNo' gelesen.
        /// Wird auf Schnittstelle wahrscheinlich mit Objektadressen ausgeliefert (aber mit 
        /// speziellem Code) und von Client-Sync-Komponente hier abgefüllt.
        /// Muss auch in OXAS nicht immer ausgefüllt sein. 
        /// </summary>
        public Address Address
        {
            get { return mAddress; }
            set { SetProperty(ref mAddress, value); }
        }

        /// <summary>
        /// Objektbeschreibung.
        /// </summary>
        public string Description
        {
            get { return mDescription; }
            set { SetProperty(ref mDescription, value); }
        }

        /// <summary>
        /// Objekt-Subtyp: dient der Einteilung von Objekten in gewisse Untertypen (kann z.B. auch für Auswahl 
        /// und Filter eingesetzt werden).
        /// Der Wert wird von OXAS gelesen und könnte auch in projektspezifischen Clients interpretiert werden.
        /// </summary>
        public string SubType
        {
            get { return mSubType; }
            set { SetProperty(ref mSubType, value); }
        }

        /// <summary>
        /// Bemerkungen/Hinweise/Mitteilungen zum Objekt.
        /// Diese Bemerkungen können im Client auch neu erfasst oder verändert werden
        /// (Änderungen via 'OriginalValues' eruierbar).
        /// </summary>
        public string Remark
        {
            get { return mRemark; }
            set { SetProperty(ref mRemark, value); }
        }

        /// <summary>
        /// Synchronisations-Status des Objekts.
        /// Der Zustand bezieht sich aber vor allem(eigentlich ausschliesslich) auf Custom-Properties, welche bearbeitet und 
        /// zurückgemeldet werden können.
        /// Achtung: der Status ist überflüssig, wenn neu der Auftrag nur noch gesamthaft zurückgemeldet würde.
        /// In diesem Fall würde der Synchronisations-Zustand ziemlich sicher nur noch auf dem Auftrag geführt.
        /// Im Client als Enum 'SyncState' abgebildet, wobei hier davon folgende Stati zum Tragen kommen:
        /// + 1 =  'Downloaded': Zuteilung von Mof-Service runtergeladen
        /// + 2 = 'CreatedOnClient': in Client erzeugt
        /// + 20 = 'Uploaded': Geändertes Objekt vollständig an Mof-Service übermittelt
        /// </summary>
        public SyncState SyncState
        {
            get { return mSyncState; }
            set { SetProperty(ref mSyncState, value); }
        }

        /// <summary>
        /// Originalwerte des Objekts: Werte, wie sie ursprünglich von Mof-Service gelesen wurden.
        /// Falls ausgefüllt, so können die aktuellen Werte mit den Originalwerten verglichen werden; 
        /// falls null, so wurden keine Änderungen an Adresse vorgenommen.
        /// Aktuell kann auf dem Objekt nur die Bemerkung bearbeitet werden, somit dient OriginalValues vor 
        /// allem zum Speichern dieser Mutation.Zukünftig aber weitere Mutationen direkt auf dem Objekt denkbar. 
        /// </summary>
        public string OriginalValues
        {
            get { return mOriginalValues; }
            set { SetProperty(ref mOriginalValues, value); }
        }

        /// <summary>
        /// Die dem Service-Objekt zugeteilten Adressen.
        /// </summary>
        public virtual List<ServiceObjectAddress> ServiceObjectAddresses { get; set; }

        /// <summary>
        /// Die dem Service-Objekt zugeteilten Historydaten.
        /// </summary>
        public virtual List<ServiceObjectHistory> ServiceObjectHistories { get; set; }

        /// <summary>
        /// Liste der Dokument-Objekt-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedServiceObject> DocumentLinkedServiceObjects { get; set; }
        #endregion
    }
}