﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Die mit Objekten verlinkten Adressen haben eine bestimmte Bedeutung/Typ, welcher in dieser 
    /// Tabelle abgelegt ist.
    /// </summary>
    public class AddressType : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private bool mIsActive;
        private string mNo;
        private string mName;
        #endregion


        #region ==================== Construction, Destruction ====================
        public AddressType()
        {
            IsActive = true;
        }
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Eindeutige Mof-Service-Id des Adress-Typs.
        /// Falls ausgefüllt, so muss dieses eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Inaktive Adresstypen können vom Cleanup-Job gelöscht werden, falls diese nicht mehr referenziert werden.
        /// Ansonsten hat dieses Flag im Client keine Bedeutung, da die Adresstypen eigentlich 
        /// nirgends ausgewählt werden können und Referenzen immer angezeigt werden
        /// </summary>
        public bool IsActive
        {
            get { return mIsActive; }
            set { SetProperty(ref mIsActive, value); }
        }

        /// <summary>
        /// Adresstyp-Nr, auf welchen projektspezifisch codiert werden könnte. 
        /// Muss ausgefüllt sein, aber nicht zwingend eindeutig.
        /// Hier kann der Mof-Service den Feld-Namen der BO-Redefinition einfüllen..
        /// </summary>
        public string No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Adresstyp-Bezeichnung. 
        /// Hier legt der Mof-Service den Titel der BO-Redefinition ab.
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }
        #endregion
    }
}