﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    /// <summary>
    /// Aktuell werden alle Addressen in 'ServiceObjectAddress' verwaltet, also auch die Hauptadresse. 
    /// </summary>
    public class ServiceObjectAddress : ModelBase
    {
        #region ==================== Fields ====================
        private ServiceObject mServiceObject;
        private Address mAddress;
        private AddressType mAddressType;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Verweis/Referenz auf das Objekt, für welches die Adresse erfasst wurde.
        /// </summary>
        public ServiceObject ServiceObject
        {
            get { return mServiceObject; }
            set { SetProperty(ref mServiceObject, value); }
        }

        /// <summary>
        /// Verweis/Referenz auf die Adresse, um welche es sich hier handelt. 
        /// </summary>
        public Address Address
        {
            get { return mAddress; }
            set { SetProperty(ref mAddress, value); }
        }

        /// <summary>
        /// Referenz auf den Adress-Typ.
        /// Die hier hinterlegte Adresse hat diese Bedeutung. 
        /// </summary>
        public AddressType AddressType
        {
            get { return mAddressType; }
            set { SetProperty(ref mAddressType, value); }
        }
        #endregion
    }
}