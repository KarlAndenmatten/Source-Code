﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System;

    /// <summary>
    /// In OXAS BusinessData werden auf Objekten History-Daten archiviert ("AsstHistory"), welche Informationen über alle dem Objekt zugewiesenen Service-Istzeilen liefern.
    /// Für einen Service-Techniker sind diese Daten sicher wichtig, da diese Informationen zu vergangenen Arbeiten etc.liefern.Dies ist z.B.für Anlagen, an welchen periodisch Arbeiten ausgeführt werden, eine sehr wichtige Information.
    /// Auf dem Client werden diese Daten in der Tabelle 'ServiceObjectHistory' abgelegt und können auf dem Client als Objekt-Details eingesehen werden.
    /// </summary>
    public class ServiceObjectHistory : ModelBase
    {
        #region ==================== Fields ====================
        private ServiceObject mServiceObject;
        private string mServiceOrderNo;
        private DateTime mBookingDate;
        private string mArticleNo;
        private string mArticleName;
        private decimal mQtyEffective;
        private decimal? mQtyChargeable;
        private int mServiceTypeNo;
        private string mServiceTypeName;
        private int? mEmplNo;
        private string mEmplName;
        private string mInternalNote;
        private string mExternalNote;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Verweis/Referenz auf das Objekt, auf welches sich die History-Daten beziehen.
        /// Hier wird natürlich(im Gegensatz zu anderen Referenzen) direkt die Referenz gespeichert, 
        /// da die Historydaten auf dem Client immer nur im Kontext eines Objekts eingesehen 
        /// werden können (z.B. in Detailansicht).
        /// </summary>
        public ServiceObject ServiceObject
        {
            get { return mServiceObject; }
            set { SetProperty(ref mServiceObject, value); }
        }

        /// <summary>
        /// Sprechende Service-Auftrags-Nummer.
        /// Diese Nummer entspricht in OXAS in etwa 'Stufe/Shortcut Nr', z.B. 'MON/K 1961'
        /// </summary>
        public string ServiceOrderNo
        {
            get { return mServiceOrderNo; }
            set { SetProperty(ref mServiceOrderNo, value); }
        }

        /// <summary>
        /// Buchungsdatum der Istzeile.
        /// </summary>
        public DateTime BookingDate
        {
            get { return mBookingDate; }
            set { SetProperty(ref mBookingDate, value); }
        }

        /// <summary>
        /// Alphanumerische Artikel-Nr.
        /// Wir speichern hier die wichtigsten Artikeldaten direkt, so dass nur wegen der Historydaten keine Artikel-Stammdaten abgeglichen werden müssen.
        /// Von OXAS wird in dieses Feld die eindeutige externe Artikel-Nummer 'Art.Number' übernommen.
        /// Beispiele:   S60.4.5 / K1040 / HA2-1
        /// </summary>
        public string ArticleNo
        {
            get { return mArticleNo; }
            set { SetProperty(ref mArticleNo, value); }
        }

        /// <summary>
        /// Artikel-Bezeichnung.
        /// Wir speichern hier die wichtigsten Artikeldaten direkt, so dass nur wegen der Historydaten keine Artikel-Stammdaten abgeglichen werden müssen.
        /// Von OXAS könnte hier das erste ausgefüllte Keyword oder gleich alle Keywords zusammengehängt übernommen werden(ist noch abzuklären, was hier genau Sinn macht)
        /// </summary>
        public string ArticleName
        {
            get { return mArticleName; }
            set { SetProperty(ref mArticleName, value); }
        }

        /// <summary>
        /// Gebuchte Menge.
        /// </summary>
        public decimal QtyEffective
        {
            get { return mQtyEffective; }
            set { SetProperty(ref mQtyEffective, value); }
        }

        /// <summary>
        /// Belastete/Fakturierte Menge
        /// </summary>
        public decimal? QtyChargeable
        {
            get { return mQtyChargeable; }
            set { SetProperty(ref mQtyChargeable, value); }
        }

        /// <summary>
        ///Leistungsart-Nr, eindeutig in OXAS.
        /// Wir speichern hier die wichtigsten Leistungsdaten direkt, so dass nur wegen der Historydaten keine Artikel-Stammdaten abgeglichen werden müssen
        /// Diese Nummer identifiziert die Leistungsart und ist in OXAS-Businessdata immer ausgefüllt(ServiceType.Number).
        /// </summary>
        public int ServiceTypeNo
        {
            get { return mServiceTypeNo; }
            set { SetProperty(ref mServiceTypeNo, value); }
        }

        /// <summary>
        /// Leistungsart-Bezeichnung.
        /// Wir speichern hier die wichtigsten Leistungsdaten direkt, so dass nur wegen der Historydaten keine Artikel-Stammdaten abgeglichen werden müssen
        /// Wird(redundant) zur Nummer abgespeichert, damit nur für die Historydaten keine Stammdaten notwendig sind.
        /// </summary>
        public string ServiceTypeName
        {
            get { return mServiceTypeName; }
            set { SetProperty(ref mServiceTypeName, value); }
        }

        /// <summary>
        /// Nummer (numerisch) des zugeteilten Mitarbeiters.
        /// Mitarbeiter werden im Client nicht in einer separaten Tabelle verwaltet,
        /// darum werden die Mitarbeiterdaten hier direkt auf der Sollzeile abgelegt.
        /// </summary>
        public int? EmplNo
        {
            get { return mEmplNo; }
            set { SetProperty(ref mEmplNo, value); }
        }

        /// <summary>
        /// Name des zugeteilten Mitarbeiters.
        /// Mitarbeiter werden im Client nicht in einer separaten Tabelle verwaltet, darum werden die
        /// Mitarbeiterdaten hier direkt auf der Sollzeile abgelegt.
        /// </summary>
        public string EmplName
        {
            get { return mEmplName; }
            set { SetProperty(ref mEmplName, value); }
        }

        /// <summary>
        /// Auf der Buchung erfasste interne Mitteilung.
        /// </summary>
        public string InternalNote
        {
            get { return mInternalNote; }
            set { SetProperty(ref mInternalNote, value); }
        }

        /// <summary>
        ///  Auf der Buchung erfasste externe Mitteilung.
        /// </summary>
        public string ExternalNote
        {
            get { return mExternalNote; }
            set { SetProperty(ref mExternalNote, value); }
        }
        #endregion
    }
}