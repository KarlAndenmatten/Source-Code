﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System.Collections.Generic;

    /// <summary>
    /// Dokument-Kategorien, welche gemäss Service-Konfiguration und aufgrund der 
    /// verknüpften Dokumente von DMASübernommen werden.
    /// </summary>
    public class DocumentTemplate : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private bool mIsActive;
        private string mNo;
        private string mName;
        private bool mIsVisible;
        #endregion


        public DocumentTemplate()
        {
            IsActive = true;

            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            Documents = new List<Document>();
        }

        /// <summary>
        /// Eindeutige Mof-Service-Id, welche das Template auf der Mof-Service-Schnittstelle eindeutig 
        /// identifiziert. Mof-Service kann hier z.B.gleich die konfigurierte Client-Id 
        /// ausfüllen (welche auch in 'No' ausgeliefert wird).
        /// Ist eigentlich immer ausgefüllt, da auf dem Client keine Templates erzeugt werden.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Template ist aktiv ja/nein.
        /// Inaktive Templates werden in den Auswahlen ausgeblendet und vom Cleanup-Job gelöscht, wenn 
        /// diese nicht mehr referenziert werden.
        /// </summary>
        public bool IsActive
        {
            get { return mIsActive; }
            set { SetProperty(ref mIsActive, value); }
        }

        /// <summary>
        /// Alphanumerische Kategorie-Nr.
        /// Der Mof-Service liefert hier die in der Konfiguration hinterlegte Client-Template-Id aus, 
        /// auf welche im Client bei Bedarf auch codiert werden könnte.
        /// Eventuell werden sogar im Standard gewisse Id's = No fixiert (z.B. Unterschrifts-Template), 
        /// auf welche im Client auch im Standard codiert wird (=> falls Template mit der fixierten 
        /// No dann nicht ausgeliefert wurde, so kann das Template auf dem Client auch nicht erstellt werden).
        /// </summary>
        public string No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Template-Bezeichnung.
        /// Kann in Service-Konfiguration (sprachabhängig) hinterlegt werden. 
        /// Diese Bezeichnung wird in der optionalen Auswahl beim Erstellen neuer Dokumente angezeigt.
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }

        /// <summary>
        /// Falls true, so kann das Template beim Erstellen neuer Dokumente im Client ausgewählt werden. 
        /// Zum Beispiel könnten so die fixierten Templates (z.B. Unterschrifts-Template) ausgeblendet werden.
        /// Diese Vorgabe kann/muss in MOF-Service-Konfiguration hinterlegt werden. 
        /// </summary>
        public bool IsVisible
        {
            get { return mIsVisible; }
            set { SetProperty(ref mIsVisible, value); }
        }

        /// <summary>
        /// Liste der mit der Kategorie verknüpften Dokumente.
        /// </summary>
        public virtual List<Document> Documents { get; set; }
    }
}