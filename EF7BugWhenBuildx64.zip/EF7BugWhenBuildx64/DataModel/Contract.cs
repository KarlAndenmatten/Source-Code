﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System.Collections.Generic;

    /// <summary>
    /// Speichert Verträge, welche den Service-Aufträgen zugeordnet sind. 
    /// </summary>
    public class Contract : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private string mName;
        private string mDescription;
        private int mNo;
        #endregion


        public Contract()
        {
            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            DocumentLinkedContracts = new List<DocumentLinkedContract>();
        }

        /// <summary>
        /// Eindeutige Mof-Service-Id des Projekts.
        /// Falls ausgefüllt, so muss dieses eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Zwingende Vertrags-Nummer, in OXAS (Contract.Number) eigentlich eindeutig (in Client aber nicht als unique definiert).
        /// </summary>
        public int No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Vertrag-Name/-Bezeichnung.
        /// </summary>
        public string Name
        {
            get { return mName; }
            set { SetProperty(ref mName, value); }
        }

        /// <summary>
        /// Vertrag-Zusatztext-Beschreibung (OXAS-Text1, Text2, Text3).
        /// </summary>
        public string Description
        {
            get { return mDescription; }
            set { SetProperty(ref mDescription, value); }
        }

        /// <summary>
        /// Liste der Dokument-Vertrag-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedContract> DocumentLinkedContracts { get; set; }
    }
}