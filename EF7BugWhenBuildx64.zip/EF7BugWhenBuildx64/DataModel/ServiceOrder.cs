﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Eigentlich die zentrale Ausgangs-Tabelle, um welche sich das gesamte Service-Modul dreht: 
    /// hier werden alle Serviceauftrags-Kopfdaten abgelegt.
    /// </summary>
    public class ServiceOrder : ModelBase
    {
        #region ==================== Fields ====================
        private string mNo;
        private int? mNumericNo;
        private string mExternalId;
        private Project mProject;
        private Contract mContract;
        private DateTime mOrderDate;
        private DateTime? mAppointmentDate;
        private DateTime? mCompletedDate;
        private OrderType mOrderType;
        private ProcessingState mProcessingState;
        private Customer mCustomer;
        private Address mDeliveryAddress;
        private Address mInvoiceAddress;
        private bool mIsReadOnly;
        private int mPriority;
        private string mNameOfSignee;
        private string mInternalNoteToOfficeWork;
        private string mExternalNote;
        private string mInternalNoteFromOfficeWork;
        private SyncState mSyncState;
        private string mSyncErrorMsg;
        private string mOriginalValues;
        private bool mIsMarkedAsImportant;
        #endregion


        #region ==================== Construction, Destruction ====================
        public ServiceOrder()
        {
            Priority = 0;
            SyncState = SyncState.CreatedOnClient;

            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            ServiceOrderChangeLogs = new List<ServiceOrderChangeLog>();
            ServiceOrderParts = new List<ServiceOrderPart>();
            ServiceOrderPlannedItems = new List<ServiceOrderPlannedItem>();
            ServiceOrderActualItems = new List<ServiceOrderActualItem>();
            ServiceOrderTexts = new List<ServiceOrderText>();
            DocumentLinkedServiceOrders = new List<DocumentLinkedServiceOrder>();
        }
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Eindeutige Auftrags-Nummer (im Client alphanumerisch).
        /// Diese Nummer entspricht in OXAS in etwa 'Stufe/Shortcut/Nr', z.B. 'MON/K 1961'
        /// </summary>
        public string No
        {
            get { return mNo; }
            set { SetProperty(ref mNo, value); }
        }

        /// <summary>
        /// Nur der numerische Teil von 'No', welcher gut für Eingaben und Sortierungen eingesetzt werden kann.
        /// Dies wäre z.B.von obiger No = ''MON/K 1961' die Nummer 1961.
        /// Die Nummer muss nicht unbedingt eindeutig sein!
        /// </summary>
        public int? NumericNo
        {
            get { return mNumericNo; }
            set { SetProperty(ref mNumericNo, value); }
        }

        /// <summary>
        /// Eindeutige Mof-Service-Id, welche den Auftrag auf der Mof-Service-Schnittstelle eindeutig identifiziert.
        /// Wird vom Mof-Service definiert/erzeugt.Da Service-Aufträge nicht im Client erzeugt werden, muss diese immer ausgefüllt sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        /// Referenziert das mit dem Service-Auftrag verknüpfte Projekt, falls ausgefüllt.
        /// </summary>
        public Project Project
        {
            get { return mProject; }
            set { SetProperty(ref mProject, value); }
        }

        /// <summary>
        /// Referenziert den mit dem Service-Auftrag verknüpften Vertrag, falls ausgefüllt.
        /// </summary>
        public Contract Contract
        {
            get { return mContract; }
            set { SetProperty(ref mContract, value); }
        }

        /// <summary>
        /// Geplantes Auftragsdatum. Im Client inkl. Zeitanteil, obwohl auf Serverseite als Vorgabe nur das reine Datum runtergemeldet wird. 
        /// Im Client könnte aber eine feinere Planung inkl. Zeitanteil unterstützt werden.
        /// Änderungen am Auftragsdatum werden in das Change-Log geschrieben.
        /// </summary>
        public DateTime OrderDate
        {
            get { return mOrderDate; }
            set { SetProperty(ref mOrderDate, value); }
        }

        /// <summary>
        /// Verabredungs-Termin.
        /// Änderungen am Verabredungstermin werden in das Change-Log geschrieben.
        /// </summary>
        public DateTime? AppointmentDate
        {
            get { return mAppointmentDate; }
            set { SetProperty(ref mAppointmentDate, value); }
        }

        /// <summary>
        /// Verabredungs-Termin.
        /// Änderungen am Verabredungstermin werden in das Change-Log geschrieben.
        /// </summary>
        public DateTime? CompletedDate
        {
            get { return mCompletedDate; }
            set { SetProperty(ref mCompletedDate, value); }
        }

        /// <summary>
        /// Rapportart des Auftrags.
        /// </summary>
        public OrderType OrderType
        {
            get { return mOrderType; }
            set { SetProperty(ref mOrderType, value); }
        }

        /// <summary>
        /// Aktueller Bearbeitungsstatus des Auftrags.
        /// Status-Änderungen werden in OrderChangeLog festgehalten.
        /// </summary>
        public ProcessingState ProcessingState
        {
            get { return mProcessingState; }
            set { SetProperty(ref mProcessingState, value); }
        }

        /// <summary>
        /// Kunde, für welchen der Auftrag erfasst wurde.
        /// </summary>
        public Customer Customer
        {
            get { return mCustomer; }
            set { SetProperty(ref mCustomer, value); }
        }

        /// <summary>
        /// Referenziert die Hauptadresse des Rapportauftrags.
        /// </summary>
        public Address DeliveryAddress
        {
            get { return mDeliveryAddress; }
            set { SetProperty(ref mDeliveryAddress, value); }
        }

        /// <summary>
        /// Referenziert die Rechnungsadresse des Rapportauftrags.
        /// </summary>
        public Address InvoiceAddress
        {
            get { return mInvoiceAddress; }
            set { SetProperty(ref mInvoiceAddress, value); }
        }

        /// <summary>
        /// Falls true, so darf der Auftrag auf dem Client weder bearbeitet werden, noch darf dieser Istwerte zurückliefern.
        /// Readonly-Aufträge werden in OXAS via speziellen Mitarbeiter-Pool evaluiert: dort aufgeführte Aufträge werden 
        /// als Readonly-Aufträge an Client übermittelt, falls auf dem Auftragskopf nicht der Tablet-Mitarbeiter eingetragen ist.
        /// </summary>
        public bool IsReadOnly
        {
            get { return mIsReadOnly; }
            set { SetProperty(ref mIsReadOnly, value); }
        }

        /// <summary>
        /// Priorität des Auftrags:
        /// + 0: Normaler Auftrag, keine spezielle Priorisierung 
        /// > 0: Priorisierter Auftrag, je höher der Wert, desto höhere Priorität, aktuell Prio-Werte zwischen 1 - 9 möglich.
        /// </summary>
        public int Priority
        {
            get { return mPriority; }
            set { SetProperty(ref mPriority, value); }
        }

        /// <summary>
        /// Name der Person, welche den Service-Auftrag unterschrieben hat (die Unterschrift selber wird als Bitmap in DMAS gespeichert)
        /// </summary>
        public string NameOfSignee
        {
            get { return mNameOfSignee; }
            set { SetProperty(ref mNameOfSignee, value); }
        }

        /// <summary>
        /// Interne Mitteilung von Service-Techniker an Innendienst.
        /// Änderungen werden fortlaufend in das Change-Log geschrieben und bei jeder Synchronisation an den Mof-Service übermittelt.
        /// </summary>
        public string InternalNoteToOfficeWork
        {
            get { return mInternalNoteToOfficeWork; }
            set { SetProperty(ref mInternalNoteToOfficeWork, value); }
        }

        /// <summary>
        /// Externe Mitteilung von Service-Techniker, welche auch für den Kunden bestimmt sind. Könnten z.B. auf Rechnung angedruckt werden.
        /// Änderungen werden fortlaufend in das Change-Log geschrieben und bei jeder Synchronisation an den Mof-Service übermittelt.
        /// </summary>
        public string ExternalNote
        {
            get { return mExternalNote; }
            set { SetProperty(ref mExternalNote, value); }
        }

        /// <summary>
        /// Interne Mitteilung vom Innendienst, nur bestimmt für den Service-Techniker.
        /// </summary>
        public string InternalNoteFromOfficeWork
        {
            get { return mInternalNoteFromOfficeWork; }
            set { SetProperty(ref mInternalNoteFromOfficeWork, value); }
        }

        /// <summary>
        /// True, falls der Service-Auftrag vom Service-Techniker als "Wichtig" markiert wurde.
        /// Reine Client-Einstellung: im UI kann der Techniker seine ihm wichtigen Aufträge als "Wichtig" markieren, 
        /// sich seine ihm aktuell wichtigen Aufträge beliebig zusammenstellen.
        /// </summary>
        public bool IsMarkedAsImportant
        {
            get { return mIsMarkedAsImportant; }
            set { SetProperty(ref mIsMarkedAsImportant, value); }
        }

        /// <summary>
        /// Synchronisations-Status des Auftrags.
        /// Im Client als Enum 'SyncState' abgebildet, wobei hier davon folgende Stati zum Tragen kommen:
        /// + 1 =  'Downloaded': Auftrag von Mof-Service runtergeladen(vorderhand wird im Client keine Adhoc-Auftragserzeugung implementiert)
        /// (+ 18 = 'PartiallyUploaded'): Teile des Auftrags raufgeladen, aber noch nicht vollständig => neu wird dieser Status wahrscheinlich nicht mehr benötigt
        /// + 20: Uploaded: Auftrag vollständig an Mof-Service zurückübermittelt 
        /// + 30: UploadedAndReadyForCleanup: falls Auftrag nicht vollständig übermittelt werden konnte, im Client aber weggelöscht werden möchte => mal schauen, ob dieser Status auch weiterhin notwendig ist
        /// </summary>
        public SyncState SyncState
        {
            get { return mSyncState; }
            set { SetProperty(ref mSyncState, value); }
        }

        /// <summary>
        /// Fehlermeldung, welcher von Mof-Service zurückgeliefert wird.
        /// </summary>
        public string SyncErrorMsg
        {
            get { return mSyncErrorMsg; }
            set { SetProperty(ref mSyncErrorMsg, value); }
        }

        /// <summary>
        /// Originalwerte des Records: Werte, wie sie ursprünglich von Mof-Service gelesen wurden.
        /// Falls ausgefüllt, so können die aktuellen Werte mit den Originalwerten verglichen werden; falls null, 
        /// so wurden keine Änderungen an Adresse vorgenommen.
        /// </summary>
        public string OriginalValues
        {
            get { return mOriginalValues; }
            set { SetProperty(ref mOriginalValues, value); }
        }

        /// <summary>
        /// Die mit dem Serviceauftrag verknüpften Zuteilungen.
        /// </summary>
        public virtual List<ServiceOrderChangeLog> ServiceOrderChangeLogs { get; set; }

        /// <summary>
        /// Die mit dem Serviceauftrag verknüpften Zuteilungen.
        /// </summary>
        public virtual List<ServiceOrderPart> ServiceOrderParts { get; set; }

        /// <summary>
        /// Die mit dem Serviceauftrag verknüpften Sollzeilen.
        /// </summary>
        public virtual List<ServiceOrderPlannedItem> ServiceOrderPlannedItems { get; set; }

        /// <summary>
        /// Die mit dem Serviceauftrag verknüpften Istzeilen.
        /// </summary>
        public virtual List<ServiceOrderActualItem> ServiceOrderActualItems { get; set; }

        /// <summary>
        /// Die mit dem Serviceauftrag verknüpften Auftrags-Texte.
        /// </summary>
        public virtual List<ServiceOrderText> ServiceOrderTexts { get; set; }

        /// <summary>
        /// Liste der Dokument-Serviceauftrags-Verknüpfungen.
        /// </summary>
        public virtual List<DocumentLinkedServiceOrder> DocumentLinkedServiceOrders { get; set; }
        #endregion
    }
}