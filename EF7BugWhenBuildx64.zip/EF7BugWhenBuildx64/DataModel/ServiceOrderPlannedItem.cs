﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    using System.Collections.Generic;

    /// <summary>
    ///     Die übermittelten Sollzeilen eines Serviceauftrags.
    /// </summary>
    public class ServiceOrderPlannedItem : ModelBase
    {
        #region ==================== Fields ====================
        private string mExternalId;
        private ServiceOrder mServiceOrder;
        private ServiceOrderPart mServiceOrderPart;
        private Article mArticle;
        private ServiceType mServiceType;
        private decimal? mQtyEffective;
        private decimal? mQtyChargeable;
        private int? mRefereeNo;
        private string mRefereeName;
        #endregion


        public ServiceOrderPlannedItem()
        {
            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            // --> Die Collections müssen wegen EF-Lazy-Loading-Feature als virtuell deklariert werden. Eventuell kann aber 
            //     später (wenn Lazy-Loading wirklich funktioniert) die Erzeugung hier wieder eliminiert werden.
            ServiceOrderActualItems = new List<ServiceOrderActualItem>();
        }

        /// <summary>
        ///     Eindeutige Mof-Service-Id, welche die Sollzeile auf der Mof-Service-Schnittstelle eindeutig identifiziert.
        ///     Wird vom Mof-Service definiert/erzeugt und an den Client übermittelt.Da(aktuell) im Client
        ///     keine Sollzeilen erzeugt werden, müsste dieses Feld eigentlich immer ausgefüllt sein.
        ///     Falls ausgefüllt, so muss diese externe Id auch eindeutig sein.
        /// </summary>
        public string ExternalId
        {
            get { return mExternalId; }
            set { SetProperty(ref mExternalId, value); }
        }

        /// <summary>
        ///     Referenz auf Service-Auftrag, zu welchem die Sollzeile gehört.
        ///     Diese Referenz muss immer ausgefüllt sein, auch wenn die Sollzeile zusätzlich mit einer Zuteilung verknüpft ist.
        ///     In diesem Fall muss dann natürlich der Zuteilungsauftrag mit dem hier verknüpften Auftrag übereinstimmen.
        /// </summary>
        public ServiceOrder ServiceOrder
        {
            get { return mServiceOrder; }
            set { SetProperty(ref mServiceOrder, value); }
        }

        /// <summary>
        ///     Referenz auf die Zuteilung, mit welcher die Sollzeile optional verknüpft sein kann.
        ///     Zum Start müsste diese Referenz eigentlich immer ausgefüllt sein, weil nur die Struktur
        ///     'Auftrag -> Zuteilung -> Sollzeile' unterstützt wird, auf dem Client trotzdem optional.
        /// </summary>
        public ServiceOrderPart ServiceOrderPart
        {
            get { return mServiceOrderPart; }
            set { SetProperty(ref mServiceOrderPart, value); }
        }

        /// <summary>
        ///     Referenz auf Artikel: Artikelvorgabe.
        ///     Auf der Sollzeile muss der Artikel zwingend ausgefüllt sein, also immer ein Artikel vorgegeben werden.
        /// </summary>
        public Article Article
        {
            get { return mArticle; }
            set { SetProperty(ref mArticle, value); }
        }

        /// <summary>
        ///     Referenz auf die Verrechnungsart/Leistungsart, in OXAS ist dies 'AsstDocItem.ServiceTypeNo'.
        ///     Auf der Sollzeile muss zwingend ein Service-Typ vorgegeben werden.
        ///     Die möglichen/vorkommenden Leistungsarten werden von OXAS von der Tabelle 'ServiceType' gelesen
        ///     und als als Stammdaten abgeglichen.
        /// </summary>
        public ServiceType ServiceType
        {
            get { return mServiceType; }
            set { SetProperty(ref mServiceType, value); }
        }

        /// <summary>
        ///     Effektive Sollmenge.
        ///     Wird hier als nullable geführt: falls keine Sollmenge oder Sollmenge = 0, so sollte hier null abgefüllt werden
        /// </summary>
        public decimal? QtyEffective
        {
            get { return mQtyEffective; }
            set { SetProperty(ref mQtyEffective, value); }
        }

        /// <summary>
        ///     Sollmenge, welche auch belastet/fakturiert werden darf.
        ///     Wird hier als nullable geführt: falls keine Sollmenge oder Sollmenge = 0, so sollte hier null abgefüllt werden
        /// </summary>
        public decimal? QtyChargeable
        {
            get { return mQtyChargeable; }
            set { SetProperty(ref mQtyChargeable, value); }
        }

        /// <summary>
        ///     Nummer (numerisch) des zugeteilten Mitarbeiters.
        ///     Mitarbeiter werden im Client nicht in einer separaten Tabelle verwaltet,
        ///     darum werden die Mitarbeiterdaten hier direkt auf der Sollzeile abgelegt.
        /// </summary>
        public int? RefereeNo
        {
            get { return mRefereeNo; }
            set { SetProperty(ref mRefereeNo, value); }
        }

        /// <summary>
        ///     Name des zugeteilten Mitarbeiters.
        ///     Mitarbeiter werden im Client nicht in einer separaten Tabelle verwaltet, darum werden die
        ///     Mitarbeiterdaten hier direkt auf der Sollzeile abgelegt.
        /// </summary>
        public string RefereeName
        {
            get { return mRefereeName; }
            set { SetProperty(ref mRefereeName, value); }
        }

        /// <summary>
        /// Die mit der Sollzeile verknüpften Istzeilen.
        /// </summary>
        public virtual List<ServiceOrderActualItem> ServiceOrderActualItems { get; set; }
    }
}