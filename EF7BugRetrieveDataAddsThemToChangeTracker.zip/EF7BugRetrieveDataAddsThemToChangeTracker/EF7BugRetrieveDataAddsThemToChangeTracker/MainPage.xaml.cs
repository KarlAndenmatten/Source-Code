﻿using System;
using System.Linq;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Microsoft.Data.Entity;
using Opacc.Mof.Client.Service.DataAccess.Database;
using Opacc.Mof.Client.Service.DataAccess.DataModel;
using Opacc.Mof.Client.Service.DataModel;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace EF7BugRetrieveDataAddsThemToChangeTracker
{
	/// <summary>
	///     An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public sealed partial class MainPage : Page
	{
		private const string ORDER_NO = "1234";
		private const int CUSTOMER_NO = 5678;

		public MainPage()
		{
			InitializeComponent();
			ClientDbContext.DatabaseName = "DemoDatabase.sqlite";
			ShowHideButtons();
		}

		private ClientDbContext DbContext { get; set; }

		private void ShowHideButtons()
		{
			if (DbContext == null)
			{
				BtnCreateData.Visibility = Visibility.Visible;
				BtnRetrieveDataWithoutInclude.Visibility = Visibility.Collapsed;
				BtnRetrieveDataWithInclude.Visibility = Visibility.Collapsed;
			}
			else
			{
				BtnCreateData.Visibility = Visibility.Collapsed;
				BtnRetrieveDataWithoutInclude.Visibility = Visibility.Visible;
				BtnRetrieveDataWithInclude.Visibility = Visibility.Visible;
			}
		}

		public void CreateData_OnClick(object sender, RoutedEventArgs e)
		{
			if (CreateDatabase())
			{
				CreateContextAndData();
			}
		}

		public void RetrieveDataWithoutInclude_OnClick(object sender, RoutedEventArgs e)
		{
			RetrieveAddressFromDatabase(false);
		}

		public void RetrieveDataWithInclude_OnClick(object sender, RoutedEventArgs e)
		{
			RetrieveAddressFromDatabase(true);
		}


		private void CreateContextAndData()
		{
			try
			{
				PrepareUIBeforeOpStart();

				DbContext = ClientDbContext.CreateDefaultContext();
				var currentDate = DateTime.Now;

				var customerAddress = new Address
				{
					No = 1,
					LastName = "Customer",
					CreatedAt = currentDate, 
					ModifiedAt = currentDate
				};
				DbContext.Addresses.Add(customerAddress);

				var deliveryAddress = new Address
				{
					No = 2,
					LastName = "Delivery",
					CreatedAt = currentDate,
					ModifiedAt = currentDate
				};
				DbContext.Addresses.Add(deliveryAddress);

				var customer = new Customer()
				{
					No = CUSTOMER_NO,
                    Address = customerAddress,
					CreatedAt = currentDate,
					ModifiedAt = currentDate
				};
				DbContext.Customers.Add(customer);

				var serviceOrder = new ServiceOrder
				{
					No = ORDER_NO,
					Customer = customer,
					DeliveryAddress = deliveryAddress
				};
				DbContext.ServiceOrders.Add(serviceOrder);

				DbContext.SaveChanges();
				
				TxbOpResult.Text = @"Data successful created.";
			}
			catch (Exception ex)
			{
				TxbOpResult.Text = "!!!Exception occured when creating data !!!\r\n\r\n" + GetExceptionMsg(ex);
				TxbOpResult.Foreground = new SolidColorBrush(Colors.Red);
			}
			finally
			{
				ResetUIAfterOp();
				ShowChangeTrackerInfo();
			}
		}

		private void RetrieveAddressFromDatabase(bool withIncludeCustomerAddress)
		{
			try
			{
				PrepareUIBeforeOpStart();

				DbContext = ClientDbContext.CreateDefaultContext(); // ! Necessary to create here a new empty context
				ServiceOrder retrievedOrder = null;
				if (withIncludeCustomerAddress)
				{
					retrievedOrder = DbContext.ServiceOrders
						.Include(o => o.Customer).ThenInclude(c => c.Address)
						.Include(o => o.DeliveryAddress)
						.SingleOrDefault(order => order.No.Equals(ORDER_NO));
				}
				else
				{
					retrievedOrder = DbContext.ServiceOrders
						.Include(o => o.Customer)
						.Include(o => o.DeliveryAddress)
						.SingleOrDefault(order => order.No.Equals(ORDER_NO));
				}
				if (retrievedOrder != null)
				{
					// The following separate retrieving of the customer with including address-data leads to change-tracker 'Added'-status
					var customer = DbContext.Customers
						.Include(c => c.Address)
						.SingleOrDefault(o => o.No.Equals(CUSTOMER_NO));
					if (DbContext.ChangedEntries.Count() != 0)
					{
						TxbOpResult.Text = "!!! Retrieving data marks them in change-tracker as 'changed' !!!"; ;
						TxbOpResult.Foreground = new SolidColorBrush(Colors.Red);
					}
					else
					{
						TxbOpResult.Text = "Retrieving data ok: reading has no effect to change-tracker changed-info"; ;
					}

					// SaveChanges would generate here an exception because of unique constraint on address
					// DbContext.SaveChanges();
				}
				else
				{
					TxbOpResult.Text = "!!! Order not saved in database !!!"; ;
					TxbOpResult.Foreground = new SolidColorBrush(Colors.Red);
				}

			}
			catch (Exception ex)
			{
				TxbOpResult.Text = "!!!Exception occured when retrieving data !!!\r\n\r\n" + GetExceptionMsg(ex);
                TxbOpResult.Foreground = new SolidColorBrush(Colors.Red);
			}
			finally
			{
				ResetUIAfterOp();
				ShowChangeTrackerInfo();
			}
		}

		private string GetExceptionMsg(Exception ex)
		{
			return ex.Message + (ex.InnerException != null ? "\r\n" + ex.InnerException.Message : string.Empty);
		}

		private void ShowChangeTrackerInfo()
		{
			if (DbContext != null)
			{
				TxbChangedEntriesCount.Text = DbContext.ChangedEntries.Count().ToString();
				TxbChangedEntries.Text = string.Empty;
				DbContext.ChangedEntries.ToList().ForEach(entry =>
				{
					TxbChangedEntries.Text += ((string.IsNullOrEmpty(TxbChangedEntries.Text) ? string.Empty : ", ") + entry.Entity.ToString());
				});
			}
		}

		private bool CreateDatabase()
		{
			var dbCreated = false;
			try
			{
				ClientDbContext.ClearDatabase();
				CreateMigrateDatabase();
				TxbOpResult.Text = @"Database creation successfull.";
				dbCreated = true;
			}
			catch (Exception ex)
			{
				TxbOpResult.Text = "!!!Exception occured when trying to create database !!!\r\n\r\n" + GetExceptionMsg(ex);
				TxbOpResult.Foreground = new SolidColorBrush(Colors.Red);
			}
			return dbCreated;
		}

		private void ResetUIAfterOp()
		{
			ProgressRing.IsActive = false;
			BtnCreateData.IsEnabled = true;
			BtnRetrieveDataWithoutInclude.IsEnabled = true;
			BtnRetrieveDataWithInclude.IsEnabled = true;

			ShowHideButtons();
		}

		private void PrepareUIBeforeOpStart()
		{
			ProgressRing.IsActive = true;
			BtnCreateData.IsEnabled = false;
			BtnRetrieveDataWithoutInclude.IsEnabled = false;
			BtnRetrieveDataWithInclude.IsEnabled = false;
			TxbOpResult.Text = string.Empty;
			TxbOpResult.Foreground = new SolidColorBrush(Colors.Black);
		}

		private void CreateMigrateDatabase()
		{
			// Hint: Creation of context doesn't create new empty sqlite database but the first access (DoMigration) does it.
			using (var dbContext = ClientDbContext.CreateDefaultContext())
			{
				new ServiceDatabase(dbContext).DoMigration();
			}
		}
	}
}