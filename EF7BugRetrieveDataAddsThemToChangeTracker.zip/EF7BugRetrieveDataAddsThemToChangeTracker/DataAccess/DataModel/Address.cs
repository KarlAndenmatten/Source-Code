﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
	using System;
	using System.Collections.Generic;

	/// <summary>
	/// Alle Adressen, welche den Service-Aufträgen zugeordnet sind resp. zugewiesen werden können. 
	/// Dies sind vor allem Kunden-, Service-Auftrag- und Objekt-Adressen.
	/// </summary>
	public class Address : ModelBase
	{
		#region ==================== Fields ====================
		private int mNo;
		private string mFirstName;
		private string mLastName;
		#endregion


		#region ==================== Properties ====================

		/// <summary>
		/// Adress-Nummer, im Client nicht als unique definiert.
		/// </summary>
		public int No
		{
			get { return mNo; }
			set { SetProperty(ref mNo, value); }
		}

		/// <summary>
		/// Vorname.
		/// </summary>
		public string FirstName
		{
			get { return mFirstName; }
			set { SetProperty(ref mFirstName, value); }
		}

		/// <summary>
		/// Nachname / Firmenname.
		/// </summary>
		public string LastName
		{
			get { return mLastName; }
			set { SetProperty(ref mLastName, value); }
		}

		///// <summary>
		///// Assigned Customers => not necessary here
		///// </summary>
		//public virtual ICollection<Customer> Customers { get; set; }

		public override string ToString()
		{
			return base.ToString() + " (No: " + this.No + ")";
		}
		#endregion

	}
}