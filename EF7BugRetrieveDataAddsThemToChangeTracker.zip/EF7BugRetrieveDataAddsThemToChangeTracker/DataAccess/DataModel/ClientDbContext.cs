﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

using System;
using System.Collections.Generic;
using System.Data.Common;
using System.IO;
using System.Linq;
using Windows.Storage;
using Microsoft.Data.Entity;
using Microsoft.Data.Entity.ChangeTracking;
using Opacc.Mof.Client.Service.DataAccess.Database;
using Opacc.Mof.Client.Service.DataAccess.DataModel.ModelConfig;
using Opacc.Mof.Client.Service.DataModel;

namespace Opacc.Mof.Client.Service.DataAccess.DataModel
{
	public class ClientDbContext : DbContext
	{
		#region ==================== Constants, Enums ====================

		private static readonly Dictionary<Type, List<object>> sBusinessLogicListeners = new Dictionary<Type, List<object>>();

		#endregion

		#region ==================== Fields ====================

		private readonly DbConnection mDbConnection;

		#endregion

		#region ==================== Properties ====================

		private static string DatabasePath => Path.Combine(ApplicationData.Current.LocalFolder.Path, DatabaseName);

		#endregion

		#region ==================== Construction, Destruction ====================

		static ClientDbContext()
		{
			DatabaseName = "ServiceClientDB.sqlite";
		}

		public ClientDbContext(DbConnection dbConnection)
		{
			mDbConnection = dbConnection;
		}

		#endregion

		#region Helper / Statics

		public IEnumerable<EntityEntry> ChangedEntries
		{
			get
			{
				return ChangeTracker.Entries()
					.Where(
						entry =>
							entry.State == EntityState.Added || entry.State == EntityState.Modified ||
							entry.State == EntityState.Deleted)
					.ToList();
			}
		}

		public static string DatabaseName { get; set; }

		public static ClientDbContext CreateDefaultContext()
		{
			return new ClientDbContext(new SqliteConnectionFactory(DatabasePath).CreateNewConnection());
		}

		public static void ClearDatabase()
		{
			if (File.Exists(DatabasePath))
			{
				File.Delete(DatabasePath);
			}
		}

		#endregion

		#region Entities

		public DbSet<DbMigrationHistory> DbMigrationHistories { get; set; }
		public DbSet<Address> Addresses { get; set; }

		public DbSet<Customer> Customers { get; set; }
		public DbSet<ServiceOrder> ServiceOrders { get; set; }

		#endregion

		#region Configuration/Model

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			optionsBuilder.UseSqlite(mDbConnection);
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			// In EF7 habe ich  'ModelBuilder.Configurations' nicht gefunden. 
			// Anhand dieser Konfiguration konnte man fürher mit  modelBuilder.Configurations.Add(EntityTypeConfiguration)
			// die Entitäts-Konfiguratuions-Klassen hinzufügen, welche dann vom Framework aufgerufen wurden.
			// Die nachfolgende Implementation ist eine 'Nachbildung' dieses Mechanismus
			// => so kann Konfiguration sehr gut ûnd übersichtlich in Klassen gekapselt werden 
			// (obwohl aktuell eigentlich praktisch nirhends eine Konfiguration notwendig wäre, ist aber trotzdem schöner so)

			DbMigrationHistoryConfig.Configure(modelBuilder);
			AddressConfig.Configure(modelBuilder);
		}

		#endregion
	}
}