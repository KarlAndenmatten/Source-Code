﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
	/// <summary>
	///     Alle Kunden, welche den Service-Aufträgen zugeordnet sind resp. zugewiesen werden können.
	///     Kunden sind in erster Linie natürlich vor allem spezielle Adressen, sie bestehen im Wesentlichen auch vor allem aus
	///     den Adressdaten.
	/// </summary>
	public class Customer : ModelBase
	{
		#region ==================== Methods ====================

		public override string ToString()
		{
			return base.ToString() + " (No: " + No + ", Name: " + Name + ")";
		}

		#endregion

		#region ==================== Fields ====================

		private int mNo;
		private string mName;
		private Address mAddress;

		#endregion

		#region ==================== Properties ====================

		/// <summary>
		///     Adress-Nummer, im Client nicht als unique definiert.
		/// </summary>
		public int No
		{
			get { return mNo; }
			set { SetProperty(ref mNo, value); }
		}

		/// <summary>
		///     Kunden-Name (entspricht eigentlich auch Name auf der Kundenadresse).
		/// </summary>
		public string Name
		{
			get { return mName; }
			set { SetProperty(ref mName, value); }
		}

		/// <summary>
		///     Referenz auf die Adressdaten des Kunden.
		///     Ist in OXAS eugentlich immer usgefüllt, hier auf dem Client aber doch als Nullable definiert.
		/// </summary>
		public Address Address
		{
			get { return mAddress; }
			set { SetProperty(ref mAddress, value); }
		}

		#endregion
	}
}