﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
	/// <summary>
	///     Eigentlich die zentrale Ausgangs-Tabelle, um welche sich das gesamte Service-Modul dreht:
	///     hier werden alle Serviceauftrags-Kopfdaten abgelegt.
	/// </summary>
	public class ServiceOrder : ModelBase
	{
		#region ==================== Methods ====================

		public override string ToString()
		{
			return base.ToString() + " (No: " + No + ")";
		}

		#endregion

		#region ==================== Fields ====================

		private string mNo;
		private Customer mCustomer;
		private Address mDeliveryAddress;

		#endregion

		#region ==================== Properties ====================

		/// <summary>
		///     Eindeutige Auftrags-Nummer (im Client alphanumerisch).
		///     Diese Nummer entspricht in OXAS in etwa 'Stufe/Shortcut/Nr', z.B. 'MON/K 1961'
		/// </summary>
		public string No
		{
			get { return mNo; }
			set { SetProperty(ref mNo, value); }
		}


		/// <summary>
		///     Kunde, für welchen der Auftrag erfasst wurde.
		/// </summary>
		public Customer Customer
		{
			get { return mCustomer; }
			set { SetProperty(ref mCustomer, value); }
		}

		/// <summary>
		///     Referenziert die Hauptadresse des Rapportauftrags.
		/// </summary>
		public Address DeliveryAddress
		{
			get { return mDeliveryAddress; }
			set { SetProperty(ref mDeliveryAddress, value); }
		}


		#endregion
	}
}