﻿// Copyright (c) 2007-2015 by Opacc Laboratory AG. All rights reserved

namespace Opacc.Mof.Client.Service.DataModel
{
    public class DbMigrationHistory : ModelBase
    {
        #region ==================== Fields ====================
        private int mVersion;
        private string mDescription;
        #endregion


        #region ==================== Properties ====================
        /// <summary>
        /// Datenbank-Version: wird von jedem Migrations-Schritt gesetzt.
        /// </summary>
        public virtual int Version
        {
            get { return mVersion; }
            set { SetProperty(ref mVersion, value); }
        }

        /// <summary>
        /// Beschreibung des Migrationsschritts, rein informativ.
        /// </summary>
        public virtual string Description
        {
            get { return mDescription; }
            set { SetProperty(ref mDescription, value); }
        }
        #endregion
    }
}