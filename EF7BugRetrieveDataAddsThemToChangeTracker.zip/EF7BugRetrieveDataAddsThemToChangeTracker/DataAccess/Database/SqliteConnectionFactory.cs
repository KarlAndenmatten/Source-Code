﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;

namespace Opacc.Mof.Client.Service.DataAccess.Database
{
    public class SqliteConnectionFactory
    {
        private readonly string mDbPath;

        public SqliteConnectionFactory(string dbPath)
        {
            mDbPath = dbPath;
        }

        public SqliteConnection CreateNewConnection()
        {

            var connStringBuilder = new SqliteConnectionStringBuilder()
            {
                DataSource = mDbPath
            };
            //connStringBuilder["Version"] = 3;
            //connStringBuilder["DefaultIsolationLevel"] = IsolationLevel.ReadCommitted;
            //connStringBuilder["DateTimeFormat"] = 0;
            //connStringBuilder["DateTimeKind"] = DateTimeKind.Unspecified;
            //connStringBuilder["FailIfMissing"] = true;

            var sqliteConnection = new SqliteConnection(connStringBuilder.ConnectionString);
            return sqliteConnection;
        }

    }
}
